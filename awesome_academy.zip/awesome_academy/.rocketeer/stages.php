<?php

return [

    // Stages
    //
    // The multiples stages of your application
    // if you don't know what this does, then you don't need it
    //////////////////////////////////////////////////////////////////////

    // Adding entries to this array will split the remote folder in stages
    // Like /var/www/yourapp/staging and /var/www/yourapp/production
    'stages'  => ['testing', 'staging'],

    // The default stage to execute tasks on when --stage is not provided
    // Falsey means all of them
    'default' => 'testing',

];
