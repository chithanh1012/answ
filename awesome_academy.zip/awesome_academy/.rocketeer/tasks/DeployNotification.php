<?php
namespace MyTasks;

class DeployNotification extends \Rocketeer\Abstracts\AbstractTask
{
    protected $local = true;
    /**
    * Description of the Task
    *
    * @var string
    */
    protected $description = 'Sending Deploy notification to Chatwork';

    /**
    * Executes the Task
    *
    * @return void
    */
    public function execute()
    {
        $this->explainer->line('Sending Deploy notification to Chatwork');
        $stage = $this->connections->getStage();
        return $this->run("php artisan notify:deployment --status=Completed --environment={$stage} --mode=Deploy");
    }
}