<?php
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Models\Teacher;

class TeacherBaseTest extends TestCase
{
    protected $accounts = [
        [
            'email' => 'teacher@gmail.com',
            'password' => '12345678',
        ]
    ];
    protected $teacher;

    protected function createTeacher()
    {
        if (!isset($this->teacher)) {
            $this->teacher = factory(Teacher::class)->create();
        }

        return $this->teacher;
    }

    public function testCreateTeacher()
    {
        $this->assertInstanceOf(Teacher::class, $this->createTeacher());
    }
}
