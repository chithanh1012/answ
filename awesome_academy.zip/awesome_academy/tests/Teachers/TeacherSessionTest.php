<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Models\Teacher;

class TeacherSessionTest extends TeacherBaseTest
{
    public function testLoginAndLogout()
    {
        $account = $this->accounts[0];
        $this->visit('/teacher/login')
            ->see('Teacher Login')
            ->type($account['email'], 'email')
            ->type($account['password'], 'password')
            ->press('Login')
            ->seePageIs('/')
            ->click('Logout')
            ->seePageIs('/teacher/login');
    }

    public function testSession()
    {
        $teacher = $this->createTeacher();
        $this->actingAs($teacher)
            ->visit('/')
            ->see($teacher->name);
    }
}
