<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Models\Student;

class StudentSessionTest extends StudentBaseTest
{
    public function testLoginAndLogout()
    {
        $account = $this->accounts[0];
        $this->visit('/login')
            ->see('Student Login')
            ->type($account['email'], 'email')
            ->type($account['password'], 'password')
            ->press('Login')
            ->seePageIs('/')
            ->click('Logout')
            ->seePageIs('/login');
    }

    public function testCreateAccount()
    {
        $studentData = $this->generateStudentData();
        $this->visit('/signup')
            ->see('Signup')
            ->press('Signup')
            ->seePageIs('/signup')
            ->type($studentData['email'], 'email')
            ->type($studentData['full_name'], 'full_name')
            ->type($studentData['password'], 'password')
            ->type($studentData['password'], 'password_confirmation')
            ->press('Signup')
            ->see($studentData['full_name'])
            ->see('Logout');
    }

    public function testSession()
    {
        $student = $this->createStudent();
        $this->actingAs($student)
            ->visit('/')
            ->see($student->full_name);
    }
}
