<?php
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Repositories\StudentRepository;
use App\Models\Student;

class StudentBaseTest extends TestCase
{
    protected $accounts = [
        [
            'email' => 'student1@gmail.com',
            'password' => '12345678',
        ]
    ];
    protected $student;

    protected function createStudent()
    {
        if (!isset($this->student)) {
            $this->student = factory(Student::class)->create();
        }

        return $this->student;
    }

    protected function generateStudentData()
    {
        $faker = Faker\Factory::create();
        return [
            'full_name' => $faker->name,
            'email' => $faker->email,
            'password' => str_random(10),
        ];
    }

    public function testCreateStudent()
    {
        $this->assertInstanceOf(Student::class, $this->createStudent());
    }
}
