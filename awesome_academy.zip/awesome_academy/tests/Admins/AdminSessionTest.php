<?php

use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Models\Admin;

class AdminSessionTest extends AdminBaseTest
{
    public function testLoginAndLogout()
    {
        $account = $this->accounts[0];
        $this->visit('/admin/login')
            ->see('Admin Login')
            ->type($account['email'], 'email')
            ->type($account['password'], 'password')
            ->press('Login')
            ->seePageIs('/')
            ->click('Logout')
            ->seePageIs('/admin/login');
    }

    public function testSession()
    {
        $admin = $this->createAdmin();
        $this->actingAs($admin)
            ->visit('/')
            ->see($admin->name);
    }
}
