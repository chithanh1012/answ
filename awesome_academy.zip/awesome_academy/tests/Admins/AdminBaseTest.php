<?php
use Illuminate\Foundation\Testing\WithoutMiddleware;
use Illuminate\Foundation\Testing\DatabaseMigrations;
use Illuminate\Foundation\Testing\DatabaseTransactions;
use App\Models\Admin;

class AdminBaseTest extends TestCase
{
    protected $accounts = [
        [
            'email' => 'admin@gmail.com',
            'password' => '12345678',
        ]
    ];

    protected function createAdmin()
    {
        if (!isset($this->admin)) {
            $this->admin = factory(Admin::class)->create();
        }

        return $this->admin;
    }

    public function testCreateStudent()
    {
        $this->assertInstanceOf(Admin::class, $this->createAdmin());
    }
}
