var elixir = require('laravel-elixir');

/*
 |--------------------------------------------------------------------------
 | Elixir Asset Management
 |--------------------------------------------------------------------------
 |
 | Elixir provides a clean, fluent API for defining some basic Gulp tasks
 | for your Laravel application. By default, we are compiling the Sass
 | file for our application, as well as publishing vendor resources.
 |
 */

var paths = {
    "jquery": "./bower_components/jquery/",
    "material": "./bower_components/bootstrap-material-design/",
    "material_datetimepicker": "./bower_components/bootstrap-material-datetimepicker/",
    "momentjs": "./bower_components/momentjs/",
    "bootstrap": "./bower_components/bootstrap/dist/",
    "snackbarjs": "./bower_components/snackbarjs/dist/",
    "clndr": "./bower_components/clndr/",
    "filedrop": "./bower_components/filedrop/",
    "underscore": "./bower_components/underscore/"
}

elixir(function(mix) {
    mix.sass(["app.sass", "**/*.sass"], "public/css/bundle.css")
        .styles([
            paths.bootstrap + "css/bootstrap.css",
            paths.material + "dist/css/ripples.css",
            paths.material + "dist/css/material.css",
            paths.material_datetimepicker + "css/bootstrap-material-datetimepicker.css",
            paths.snackbarjs + "snackbar.min.css",
            "./public/css/bundle.css",
        ], "public/css/all.css")
        .babel(["app.js", "**/*.js"], "./public/js/bundle.js")
        .scripts([
            paths.jquery + "dist/jquery.js",
            paths.bootstrap + "js/bootstrap.js",
            paths.material + "scripts/material.js",
            paths.material + "scripts/ripples.js",
            paths.momentjs + "min/moment.min.js",
            paths.material_datetimepicker + "js/bootstrap-material-datetimepicker.js",
            paths.snackbarjs + "snackbar.min.js",
            paths.underscore + "underscore.js",
            paths.filedrop + "filedrop.js",
            paths.clndr + "clndr.min.js",
            "./public/js/bundle.js",
        ], "public/js/all.js")
        .copy(paths.material + "dist/fonts/**", "public/build/fonts/")
        .version(["public/js/all.js", "public/css/all.css"]);
});
