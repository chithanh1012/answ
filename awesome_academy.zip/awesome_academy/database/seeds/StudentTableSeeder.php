<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\Student;

class StudentTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('students')->truncate();

        Student::create([
            'full_name' => 'Student 1',
            'email' => 'student1@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
    }
}
