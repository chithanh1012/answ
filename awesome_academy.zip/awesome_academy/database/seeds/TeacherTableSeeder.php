<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\Teacher;

class TeacherTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('teachers')->truncate();

        Teacher::create([
            'full_name' => 'teacher',
            'email' => 'teacher@gmail.com',
            'password' => bcrypt('12345678'),
        ]);
    }
}
