<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\Message;

class MessageTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('messages')->truncate();
        $messages = [
            [
                'student_id' => 1,
                'teacher_id' => 1,
                'course_id'  => 1,
                'lesson_id'  => 0,
                'content'    => 'Student 1 send Teacher1 a message from Course1',
                'reply_to'   => '',
            ],
            [
                'student_id' => 1,
                'teacher_id' => 1,
                'course_id'  => 1,
                'lesson_id'  => 0,
                'content'    => 'Teacher1 reply Student1 a message from Course1',
                'reply_to'   => 1,
            ],
            [
                'student_id' => 1,
                'teacher_id' => 1,
                'course_id'  => 1,
                'lesson_id'  => 0,
                'content'    => 'Student2 send teacher1 a message from course1',
                'reply_to'   => '',
            ],
            [
                'student_id' => 1,
                'teacher_id' => 1,
                'course_id'  => 1,
                'lesson_id'  => 0,
                'content'    => 'Student3 send teacher1 a message from course1',
                'reply_to'   => '',
            ],
            [
                'student_id' => 1,
                'teacher_id' => 1,
                'course_id'  => 1,
                'lesson_id'  => 0,
                'content'    => 'Teacher1 reply Student3 a message from Course1',
                'reply_to'   => 3,
            ],
            [
                'student_id' => 1,
                'teacher_id' => 1,
                'course_id'  => 1,
                'lesson_id'  => 1,
                'content'    => 'Student 1 send Teacher1 a message from Lesson1 of Course1',
                'reply_to'   => '',
            ]
        ];

        DB::table('messages')->insert($messages);
    }
}
