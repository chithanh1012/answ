<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;
use App\Models\Course;

class CourseTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('courses')->truncate();
        $timeTable = [

        ];
        $courses = [
            [
                'name'               => 'Data Structures and Algorithms',
                'desc'               => 'Data Structures and Algorithms',
                'location'           => 'Hanoi University of Science and Technology',
                'max_students'       => 20,
                'time_table'         => json_encode([
                                            ['day'=>'Mon', 'start_time' => '08:00', 'end_time' => '09:45'],
                                            ['day'=>'Wed', 'start_time' => '09:00', 'end_time' => '10:45']
                                        ]),
                'publish_started_at' => '2015/08/20',
                'publish_ended_at'   => '2016/01/30',
                'teacher_id'         => '1'
            ],
            [
                'name'               => 'Database Management System',
                'desc'               => 'Database Management System',
                'location'           => 'Hanoi University of Science and Technology',
                'max_students'       => 30,
                'time_table'         => json_encode([
                                            ['day'=>'Tue', 'start_time' => '10:00', 'end_time' => '11:45'],
                                            ['day'=>'Wed', 'start_time' => '13:00', 'end_time' => '14:45']
                                        ]),
                'publish_started_at' => '2015/08/20',
                'publish_ended_at'   => '2016/01/30',
                'teacher_id'         => '1'
            ],
            [
                'name'               => 'PHP Program Language',
                'desc'               => 'PHP Program Language',
                'location'           => 'Hanoi University of Science and Technology',
                'max_students'       => 40,
                'time_table'         => json_encode([['day'=>'Thu', 'start_time' => '08:00', 'end_time' => '09:45']]),
                'publish_started_at' => '2015/08/20',
                'publish_ended_at'   => '2016/01/30',
                'teacher_id'         => '1'
            ],
        ];
        DB::table('courses')->insert($courses);
    }
}
