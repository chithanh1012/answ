<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class UpdateReportsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('reports', function (Blueprint $table) {
            $table->dropColumn('student_id');
            $table->string('name')->before('lesson_id');
            $table->integer('format')->after('lesson_id')->default(1);
            $table->text('desc')->after('format');
            $table->timestamp('due_date')->after('desc');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('reports', function (Blueprint $table) {
            $table->integer('student_id')->after('lesson_id')->index();
            $table->dropColumn(['name', 'format', 'desc', 'due_date']);
        });
    }
}
