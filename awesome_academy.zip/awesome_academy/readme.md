# AWESOME ACADEMY

## Enviroment
- PHP 5.6 or HHVM ~3.9
- Mysql ~5.5
- Laravel ~5.1.11
- ECMAScript 6, Jquery, Material Design

## Build Docker
- If you have an enviroment with PHP 5.6 already installed and do not want to use HHVM, you can skip this step.
- Base image: https://hub.docker.com/r/thangtd90/hhvm/
```sh
// Pull image
docker pull thangtd90/hhvm
// Run a container with specified port binded
docker run -p 8080:80 thangtd90/hhvm
docker run -p 8080:80 -v /path/to/project:/usr/share/nginx/html -v /path/to/mysql_data:/var/lib/mysql thangtd90/hhvm
```
- Some usefull commands
```sh
// Remove container
docker rm
// Remove image
docker rmi
// List container
docker ps -a
// List images
docker images
// Stop a container
docker stop
// Stop all container
docker stop $(docker ps -aq)
// Remove all container
docker rm $(docker ps -aq)
// Run a container
docker run
// Commit a container
docker commit -m "Commit description" container_id image_name
// Push an image
docker push image_name
```

## Setup project
- Clone project
- Install Laravel framework and dependencies by `Composer`
```
composer install
```
- Change mode `storage` and `cache` folder
```
chmod -R 777 storage
chmod -R 777 bootstrap/cache
```
- Install `nodejs`, `npm`, `gulp` and `bower`
- Install frontend dependencies
```
npm install
bower install
```
- Build javascript and css files by using `gulp` command.
```
gulp
```
- Create `.env` file
```
cp .env.example .env
php artisan key:generate
```
- Awesome Academy use [Awesome Authenticate](https://github.com/framgia/awesome_authenticate/tree/auth) to login. So you have to deploy Awesome Authenticate too. Create a client in Awesome Authenticate then update the client information in `.env` file
```
// Update the following information in .env file
AA_SERVER_URL=http://awesome-authenticate.localhost/
AA_API_VERSION=v1
AA_CLIENT_ID=leJzkqebukIjZwco
AA_CLIENT_SECRET=z079hwKueBfjZanrJkWX50a0cUPktvTqb9GtDozn
AA_REDIRECT_URI=http://awesome-academy.localhost/
```

## Migration
- You have to create two databases. One is for running our project, and one is for unit test.
- Migrate DB for real enviroment (local, develop, product)
```php
php artisan migrate --seed
```
- Migrate DB for testing purpose
```php
php artisan --env=testing migrate
```

## Coding Standard
- [English](https://github.com/framgia/coding-standards/blob/master/eng/README.md#php)
- [Vietnamese](https://github.com/framgia/coding-standards/blob/master/vn/README.md#php)