<?php

return [
    'record_per_page' => 20,
];
