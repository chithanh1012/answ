<?php

return [
    'main_color_admin'          => 'warning',
    'main_color_teacher'        => 'inverse',
    'main_color_student'        => 'primary',
    'max_media_upload_size'     => 30000000,
    'string_length_limit'       => 200,
    'main_color_admin_code'     => '#ff5722',
    'main_color_teacher_code'   => '#3f51b5',
    'main_color_student_code'   => '#009688',
    'teacher_per_page'		=> '24',
];
