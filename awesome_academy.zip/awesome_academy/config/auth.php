<?php

return [
    'multi-auth' => [
        'admin' => [
            'driver' => 'eloquent',
            'model' => App\Models\Admin::class,
        ],
        'teacher' =>
        [
            'driver' => 'eloquent',
            'model' => App\Models\Teacher::class,
        ],
        'student' =>
        [
            'driver' => 'eloquent',
            'model' => App\Models\Student::class,
        ]
    ],

    'password' => [
        'email' => 'emails.password',
        'table' => 'password_resets',
        'expire' => 60,
    ],
];
