<?php

return [
    'auth_server_url' => env('AA_SERVER_URL', 'http://api.awesome.com/'),
    'api_version' => env('AA_API_VERSION', 'v1'),
    'client_id' => env('AA_CLIENT_ID'),
    'client_secret' => env('AA_CLIENT_SECRET'),
    'default_redirect_uri' => env('AA_REDIRECT_URI'),
];
