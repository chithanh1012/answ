<?php

return [
    'upload'   => storage_path() . '/upload/',
];
