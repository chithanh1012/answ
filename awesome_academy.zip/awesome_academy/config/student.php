<?php

return [
    'course_per_page'  => 12,
    'message_per_page' => 20,
    'dashboard_per_page' => 20,
];
