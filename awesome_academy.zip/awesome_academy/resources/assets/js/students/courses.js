$(document).ready(function() {
    if (isPage("js-student-course-view")) {
        var message = new Message();
        var tabBar = new TabBar();
        var calendar = new LessonCalendar();
        registerToggleDoneLessons();
    }

    if (isPage("js-student-create-report")) {
        var dropMedia = new DropMedia();
    }
});

function registerToggleDoneLessons() {
    $("body").on("click", "label#show-lessons-done", (e) => {
        if ($("label#show-lessons-done input:checked").length) {
            $("#lessons .common-lessons-list .lesson-item.lesson-status-done").show();
        } else {
            $("#lessons .common-lessons-list .lesson-item.lesson-status-done").hide();
        }
    });
}
