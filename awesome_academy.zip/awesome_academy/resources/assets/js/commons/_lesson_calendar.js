class LessonCalendar
{
    constructor() {
        this.events = [];
        this.baseUrl = baseUrl;
        this.selectedDate = (typeof selectedDate === "undefined") ? moment() : selectedDate;
        this.listLessons = listLessons;
        this.makeData();
        this.initCalendar();
    }

    makeData() {
        $.each(this.listLessons, (index, value) => {
            this.events.push({
                date: index
            });
        });
    }

    initCalendar() {
        this.calendar = $("#calendar").clndr({
            template: $('#mini-clndr-template').html(),
            forceSixRows: true,
            daysOfTheWeek: ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'],
            weekOffset: 1,
            events: this.events,
            clickEvents: {
                click: (target) => {
                    if (target.events.length) {
                        var date = target.events[0]['date'];
                        var link = this.baseUrl + "/" + this.listLessons[date];
                        window.location.href = link;
                    }
                }
            },
            doneRendering: () => {
                $("#calendar .days-container .event[class*=" + this.selectedDate + "]").addClass("selected");
            },
        });
        this.calendar.setMonth(moment(this.selectedDate, "YYYY-MM-DD").month());
    }
}
