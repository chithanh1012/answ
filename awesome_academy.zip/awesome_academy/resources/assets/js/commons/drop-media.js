class DropMedia
{
    constructor() {
        this.registerFileDropEvent();
        this.registerMediaDeleteEvent();
        this.registerOldMediaDeleteEvent();
    }

    registerFileDropEvent() {
        window.fd.logging = false;
        var dropZone = new FileDrop("drop-zone", {input: false});

        dropZone.event("send", (files) => {
            files.each((file) => {
                $(".teacher .teacher #drop-zone").before(`
                    <div id="upload-loading">
                        <div class="progress">
                            <div style="width: 100%" aria-valuemax="100"
                                aria-valuemin="0" aria-valuenow="100" role="progressbar"
                                class="progress-bar progress-bar-striped active">
                                <span class="sr-only">100% Complete</span>
                            </div>
                        </div>
                    </div>
                `);
                file.event("xhrSetup", (xhr, opt) => {
                    xhr.setRequestHeader("X-CSRF-TOKEN", $("meta[name='_token']").attr("content"));
                });
                file.event("done", (xhr) => {
                    var response = JSON.parse(xhr.response);
                    this.addMediaToList(response.id, "new", response.fileName);
                    registerDateTimePickers();
                    $(".teacher .teacher #create-lesson #upload-loading").remove();
                });
                file.event("error", (e, xhr) => {
                    $(".teacher .teacher #create-lesson #upload-loading").remove();
                    var response = JSON.parse(xhr.response);
                    if (!response) {
                        alert('Unknown error or file is too big');
                    } else {
                        alert(response.message);
                    }
                });
                file.sendTo("/media/upload");
            });
        });
    }

    registerMediaDeleteEvent() {
        $("#media-list").on("click", ".media-delete", (e) => {
            this.deleteMedia(e.currentTarget);
        });
    }

    registerOldMediaDeleteEvent() {
        $("#old-media-list").on("click", ".media-delete", (e) => {
            this.deleteMedia(e.currentTarget);
        });
    }

    deleteMedia(target) {
        var $mediaItem = $(target).closest(".media-item");
        var $mediaStatus = $("input[name='media_status[]']", $mediaItem);
        if ($mediaStatus.val() === "new") {
            $mediaItem.remove();
        } else {
            $mediaItem.hide();
            $mediaStatus.val("removed");
        }
        return false;
    }

    addMediaToList(id, status, fileName) {
        var $template = $("#media-item-template");
        $("input[name='media_id[]']", $template).val(id);
        $("input[name='media_status[]']", $template).val(status);
        $("input[name='media_name[]']", $template).val(fileName);
        $(".media-link", $template).text(fileName);
        $(".media-link", $template).attr("title", fileName)
        $(".media-link", $template).attr("href", `/media/download/${id}`)

        $("#media-list").append($template.html());
    }
}
