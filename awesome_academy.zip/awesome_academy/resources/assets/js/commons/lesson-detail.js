$(document).ready(function() {
    if (isPage("js-lesson-detail")) {
        var message = new Message();
        var tabBar = new TabBar();
        var fileList = new FileList();
    }
});
