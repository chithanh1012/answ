class Message
{
    constructor() {
        this.registerReplyEvent();
        this.hideRepliedMessage();
        this.readmoreText();
    }

    registerReplyEvent() {
        $(".btn-reply").on("click", (e) => {
            btnId = $(e.target).attr("id");

            $(`#show-${btnId}`).show();
            $(`#${btnId}`).hide();
        });
    }

    hideRepliedMessage() {
        $("#hide-replied-message").on("click", (e) => {
            value = $(e.target).prop("checked");

            if (value) {
                $(`.message-replied`).hide();	
        	} else {
                $(`.message-replied`).show();
            }
        });
    }

    readmoreText() {
        $(".morelink").click( (e) => {
            $(e.target).parent().hide();
            $(e.target).parent().next().show();
        });
        $(".lesslink").click( (e) => {
        	$(e.target).parent().hide();
            $(e.target).parent().prev().show();
        });
    }
}
