class FileList
{
    constructor() {
        this.registerDeleteButtonEvent();
    }

    registerDeleteButtonEvent() {
        $(".files-list .btn-delete").click((e) => {
            e.preventDefault();
            if (!confirm('Are you sure ?')) return;

            $.ajax({
                url: $(e.currentTarget).attr("href"),
                type: "DELETE",
            }).done(() => {
                var fileItem = $(e.currentTarget).closest(".file-item");
                fileItem.hide();
            }).error(() => {
                alert("Something went wrong");
            });
        });
    }
}
