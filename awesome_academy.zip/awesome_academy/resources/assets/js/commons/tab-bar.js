class TabBar
{
    constructor() {
        this.registerTabButtonEvent();
    }

    registerTabButtonEvent() {
        $(".tab-bar .tab-button").on("click", (e) => {
            var url = $(e.target).data("url");
            window.history.pushState(null, null, url);
        });
    }
}
