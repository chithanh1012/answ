$(document).ready(function() {
    if (isPage("js-teacher-create-lesson")) {
        var teacherLessonReport = new TeacherLessonReport();
        var dropMedia = new DropMedia();
    }
});
