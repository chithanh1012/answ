$(document).ready(function() {
    if (isPage("js-teacher-course-view")) {
        var teacherCourse = new TeacherCourse();
        var message = new Message();
        var tabBar = new TabBar();
        var calendar = new LessonCalendar();
    }

    if (isPage("js-teacher-course")) {
        var searchTeacher = new SearchTeacher();
        var teacherCourse = new TeacherCourse();
    }
});


class TeacherCourse
{
    constructor() {
        this.registerSearchButtonEvent();
        this.registerStudentButtonEvent();
        this.registerReloadEvent();
        this.registerEnterKeyEvent();
        this.registerCourseStudentMemoEvent();
        this.needReload = false;
        this.registerToggleDoneCourses();
        this.registerToggleStudentCourses();
    }

    registerSearchButtonEvent() {
        $("#btnSearch").on("click", (e) => {
            this.searchStudentToInvite($(e.target).data("form-id"), $(e.target).data("result-table"));
        });
        $("#btnAddList").on("click", (e) => {
            this.addStudentListToInvite($(e.target).data("form-id"));
        });
    }

    registerStudentButtonEvent() {
        $("body").on("click", ".btn-action", (e) => {
            button = $(e.target);
            studentId = button.data("student-id");
            action = button.data("action");
            this.needReload = true;

            $.ajax({
                url: currentUrl + "/" + action,
                method: "post",
                data: {
                    student_id: studentId,
                    action: action
                }
            }).done((result) => {
                showToast(result["message"], "snackbar-" + result["code"], 5000);
                if (result["code"] == "success") {
                    if (action == "invite") {
                        button.replaceWith(this.getPopupJoinedLabel());
                    }
                }
            });
        });
    }

    registerReloadEvent() {
        $(".modal#search-student").on("hidden.bs.modal", (e) => {
            if (this.needReload) {
                location.reload();
            }
        });
    }

    searchStudentToInvite(formId, tableId) {
        $("tbody", tableId).empty();
        text = $("input[type=text]", $(formId)).val();

        $.ajax({
            url: $(formId).data("action"),
            method: $(formId).data("method"),
            data: $(formId).serialize()
        }).done((result) => {
            if (result["status"] === "success") {
                var students = result["students"];
                $("div.alert-warning", formId).addClass("hidden")
                resultTable = $("tbody", tableId);

                for (var i = 0; i < students.length; i++) {
                    resultTable.append(this.getSearchStudentAppendText(i + 1, students[i]));
                };
            } else if (result["status"] == "not_found") {
                $("div.alert-warning", formId).removeClass("hidden").text(result["message"]);
            }
        }).error((data) => {
            error = data["responseJSON"];
            if (typeof error !== "undefined") {
                $("div.alert-warning", formId).removeClass("hidden").text(error["name"]);
            } else {
                this.needReload = true;
                $("div.alert-warning", formId).removeClass("hidden")
                                              .text("Something was wrong, please reload this page to continue");
            }
        });
    }

    addStudentListToInvite(formId) {
        $.ajax({
            url: $(formId).data("action"),
            method: $(formId).data("method"),
            data: $(formId).serialize()
        }).done((result) => {
            if (result["code"] != "stop") {
                this.needReload = true;
            }
            showToast(result["message"], "snackbar-" + result["code"], 5000);
        });
    }

    registerEnterKeyEvent() {
        $("#popup-search-form").on("keypress", "input[name='name']", (e) => {
            if (e.which ===  13) {
                e.preventDefault();
                $("#search-student #btnSearch").click();
            }
        });
    }

    getSearchStudentAppendText(no, student) {
        text = `
            <tr>
                <td>${no}</td>
                <td>${student["identity_number"]}</td>
                <td>${student["full_name"]}</td>`;
        if (student["isJoinedCourse"]){
            text = text + `
                <td>${this.getPopupJoinedLabel()}</td>
            </tr>`;
        } else {
            text = text + `
                <td>${this.getPopupInviteButton(student["id"])}</td>
            </tr>`;
        }
        return text;
    }

    getPopupInviteButton(studentId) {
        return `<button type="button" class="btn btn-primary btn-sm btn-action" data-action="invite" data-student-id="${studentId}">Invite</button>`;
    }

    getPopupCancelButton(studentId) {
        return `<button type="button" class="btn btn-danger btn-sm btn-action" data-action="cancel" data-student-id="${studentId}">Cancel</button>`;
    }

    getPopupJoinedLabel() {
        return `<span class="label label-success">Joined</span>`;
    }

    registerCourseStudentMemoEvent() {
        $(".student-show-memo").on("click", (e) => {
            id = $(e.target).attr("id");
            $("#student-memo-id").val(id);
            memo = $(`#content-${id}`).html();
            $("#student-memo-content").val(memo);
            $("#student-memo").show();
        });
    }

    registerToggleDoneCourses() {
        $("body").on("click", "label#show-courses-done", (e) => {
            if ($("label#show-courses-done input:checked").length) {
                $(".course-index .course-list .course-item.course-status-finished").show();
            } else {
                $(".course-index .course-list .course-item.course-status-finished").hide();
            }
        });
    }

    registerToggleStudentCourses() {
        $(".course-student-active").on("click", (e) => {
            var isActive = 0;
            if ($(e.target).is(":checked")) {
                isActive = 1;
            }
            var url = $(e.target).attr("url");
            var courseStudentId = $(e.target).attr("course-student-id");
            $.ajax({
                url: url,
                method: "PUT",
                data: {
                    id: courseStudentId,
                    is_active: isActive
                }
            }).done((result) => {
                showToast(result["message"], "snackbar-" + result["code"], 5000);
            });
        });
    }
}
