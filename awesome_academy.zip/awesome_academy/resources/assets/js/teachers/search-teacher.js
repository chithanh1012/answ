class SearchTeacher
{
    constructor() {
        teacherIds = [];
        needClearData = false;
        this.registerSearchTeacherBtn();
        this.registerInviteTeacherBtn();
        this.registerRemoveTeacherBtn();
        this.registerShowModalEvent();
        this.registerEnterKeyEvent();
        this.loadOldTeacher();
    }

    registerSearchTeacherBtn() {
        $("#btnSearch").on("click", (e) => {
            this.ajaxSearchTeacher($(e.target).data("form-id"), $(e.target).data("result-table"));
            needClearData = false;
        });
    }

    registerInviteTeacherBtn() {
        $("#result-table").on("click", "button[data-action=invite]", (e) => {
            this.inviteTeacher(e.target);
            needClearData = true;
        });
    }

    registerRemoveTeacherBtn() {
        $(".assistant-list").on("click", ".btn-remove", (e) => {
            e.preventDefault();
            this.removeTeacher(e.target);
            needClearData = true;
        });
    }

    registerEnterKeyEvent() {
        $("#popup-search-form").on("keypress", "input[name='name']", (e) => {
            if (e.which ===  13) {
                e.preventDefault();
                $("#popup-search-form #btnSearch").click();
            }
        });
    }

    registerShowModalEvent() {
        $("#search-teacher").on("show.bs.modal", (e) => {
            if (needClearData) {
                $("input[name='name']", $(e.target)).val("");
                $("table tbody", $(e.target)).empty();
            }
        })
    }

    loadOldTeacher() {
        $(".assistant-list input[name='teacher_ids[]']").each((index, ele) => {
            teacherIds.push(parseInt($(ele).val()));
        });
    }

    ajaxSearchTeacher(formId, tableId) {
        $(`${tableId} tbody`).empty();
        $.ajax({
            url: $(formId).data("action"),
            method: $(formId).data("method"),
            data: $(formId).serialize()
        }).done((result) => {
            if (result["status"] === "success") {
                var teachers = result["teachers"];
                $("div.alert-warning", formId).addClass("hidden")
                resultTable = $("tbody", tableId);

                for (var i = 0; i < teachers.length; i++) {
                    resultTable.append(this.getAppendText(i + 1, teachers[i]));
                };
            } else if (result["status"] == "not_found") {
                $("div.alert-warning", formId).removeClass("hidden").text(result["message"]);
            }
        }).error((data) => {
            error = data["responseJSON"];
            if (typeof error !== "undefined") {
                $("div.alert-warning", formId).removeClass("hidden").text(error["name"]);
            } else {
                $("div.alert-warning", formId).removeClass("hidden")
                                              .text("Something was wrong, please reload this page to continue");
            }
        });
    }

    getAppendText(no, teacher) {
        text = `
            <tr>
                <td>${no}</td>
                <td>${teacher["full_name"]}</td>`;
        if (teacherIds.indexOf(parseInt(teacher["id"])) === -1) {
            text = `${text}
                <td>${this.getInviteButton(teacher)}</td>
            </tr>`;
        } else {
            text = `${text}
                <td>${this.getInvitedLabel()}</td>
            </tr>`;
        }
        return text;
    }

    getInviteButton(teacher) {
        return `<button type="button" class="btn btn-primary btn-sm" data-action="invite" data-teacher-id="${teacher['id']}" data-teacher-name="${teacher['full_name']}">Invite</button>`;
    }

    getInvitedLabel() {
        return `<span class="label label-success">Invited</span>`;
    }

    inviteTeacher(target) {
        teacherId = $(target).data("teacher-id");
        teacherName = $(target).data("teacher-name");

        template = $("#assistant-template");
        $("input[name='teacher_ids[]']", template).val(teacherId);
        $("input[name='status[]']", template).val("new");
        $("input[name='teacherNames[]']", template).val(teacherName);
        $("span.teacher_name", template).text(teacherName);

        $(".assistant-list ol").append(template.html());

        $(target).replaceWith(this.getInvitedLabel());
        teacherIds.push(teacherId);
    }

    removeTeacher(target) {
        teacher = $(target).closest("li");
        $status = $("input[name='status[]']", teacher);
        if ($status.val() === "new") {
            teacher.remove();
        } else if ($status.val() === "old") {
            $status.val("remove");
            teacher.hide();
        }
        teacherIds.splice(teacherIds.indexOf(teacher.data("teacher-id")), 1);
    }
}
