class TeacherLessonReport
{
    constructor() {
        this.count = 0;
        this.reports = [];
        this.currentAction = "add";
        this.currentReport = 0;
        this.isEditPage = isEditPage;
        this.loadOldReports();
        this.registerDoneButtonEvent();
        this.registerSaveButtonEvent();
        this.registerDeleteButtonEvent();
        this.registerUpdateButtonEvent();
        this.registerAddButtonEvent();
        this.registerLessonStartDateChangeEvent();
        $("#create-report-modal input.date-picker").bootstrapMaterialDatePicker("setMinDate", minDate);
    }

    registerAddButtonEvent() {
        $("#btn-add").on("click", () => {
            this.currentAction = "add";
            this.resetReportPopup();
        });
    }

    registerDoneButtonEvent() {
        $("#create-report-modal .btn-done").on("click", (e) => {
            this.updateReportList();
        });
    }

    updateReportList() {
        form = $("#create-report-modal .report-form");
        report  = this.getReportData(form);

        if (Object.keys(report).length) {
            form = form.clone()
                       .removeClass()
                       .addClass("hidden hidden-report")
                       .attr("data-report", this.count)
                       .append(this.getTextareaBox(report["desc"]));

            if (this.currentAction == "update") {
                this.updateReport(form, report);
            } else {
                this.appendReport(form, report);
                this.currentReport = this.count;
                this.count++;
            }
            this.currentAction = "add";
            this.resetReportPopup();
            $("#report .alert").addClass("hidden")
        } else {
            $("#report .alert").removeClass("hidden");
        }
    }

    registerDeleteButtonEvent() {
        $("#report").on("click", "button[data-action=delete]", (e) => {
            report = $(e.target).data("report");
            id = $(`.report-preview[data-report=${report}]`).data("report-id");

            if (id) {
                if (confirm("Are you sure?")) {
                    $.ajax({
                        url: this.baseUrl + "/delete",
                        data: {
                            id: id
                        },
                        type: "DELETE"
                    }).done((result) => {
                        showToast(result, "snackbar", 5000);
                        this.removeReport(report);
                        this.reports.splice(report, 1);
                    });
                }
            } else {
                this.removeReport(report);
                this.reports.splice(report, 1);
            }
        });
    }

    registerUpdateButtonEvent() {
        $("#report").on("click", "button[data-action=update]", (e) => {
            report = $(e.target).data("report");
            this.currentAction = "update";
            this.currentReport = report;

            popup = $("#create-report-modal .report-form");
            this.updateForm(popup, this.reports[report]);
            $("#create-report-modal").modal("show");
        });
    }

    registerSaveButtonEvent() {
        $("#create-report-modal .btn-save").on("click", (e) => {
            form = $("#create-report-modal .report-form");
            report  = this.getReportData(form);
            if (this.checkReportData(report)) {
                var method = "POST";
                if (this.currentAction == "update") {
                    report["id"] = form.data("report-id");
                    method = "PUT";
                }
                $.ajax({
                    url: this.baseUrl + "/" + this.currentAction,
                    data: report,
                    type: method
                }).done((result) => {
                    showToast(result['message'], "snackbar", 5000);
                    $("#report .alert").addClass("hidden");
                    this.updateReportList();
                    $(`#report .report-preview[data-report=${this.currentReport}]`).attr("data-report-id", result['id']);
                    report["id"] = result["id"];
                    this.reports[this.currentReport] = report;
                }).fail((e) => {
                    $("#report .alert").removeClass("hidden");
                });
            } else {
                $("#report .alert").removeClass("hidden");
            }
        });
    }

    registerLessonStartDateChangeEvent() {
        $(".date-picker[name=start_date]").bootstrapMaterialDatePicker().on("change", (e, date) => {
            $("#create-report-modal input.date-picker").bootstrapMaterialDatePicker("setMinDate", date);
        });
    }

    loadOldReports() {
        $("#report div.report-preview").each((index, oldReport) => {
            report = {};
            report["name"] = $(".report-name", oldReport).data("name");
            report["due_date"] = $(".report-date", oldReport).data("due-date");
            report["format"] = $(".report-format", oldReport).data("format");
            report["format_text"] = $(".report-format", oldReport).data("format-text");
            report["desc"] =  $(".report-desc", oldReport).data("desc");
            if (this.isEditPage) {
                report["id"] = $(oldReport).data("report-id");
                this.baseUrl = $("#report").data("url");
            } else {
                form = $("#create-report-modal .report-form").clone();
                form = form.removeClass()
                           .addClass("hidden hidden-report")
                           .attr("data-report", this.count)
                           .append(this.getTextareaBox(report["desc"]));
                form = this.updateForm(form, report);

                $("#report .btn-add").before(form);
            }
            this.reports[index] = report;
            this.count++;
        });
        this.baseUrl = $("#report").data("url");
    }

    makeReportPreview(report, i) {
        result =
            `<div class="col-sm-12 report-preview" data-report="${i}">
                <div class="break-word">
                    <label>${report["name"]}</label>
                <div>
                <div class="row">
                    <div class="col-sm-6">Due date: ${report["due_date"]}</div>
                    <div class="col-sm-6">Format: ${report["format_text"]}</div>
                </div>
                <div class="report-desc break-word">${report["desc"]}</div>
                <div class="lesson-action pull-right">
                    <button type="button" class="btn btn-rise btn-sm btn-success" data-action="update" data-report="${i}">Update</button>
                    <button type="button" class="btn btn-rise btn-sm btn-danger" data-action="delete" data-report="${i}">Delete</button>
                </div>
            </div>`
        return result;
    }

    getTextareaBox(text) {
        return `<textarea name="reports[desc][]">${text}</textarea>`;
    }

    appendReport(form, report) {
        this.reports[this.count] = report;
        preview = this.makeReportPreview(report, this.count);
        $("#report .btn-add").before(preview);
        $("#report .btn-add").before(form);
    }

    removeReport(report) {
        $("#report .report-preview[data-report=" + report + "]").remove();
        $(".hidden-report[data-report=" + report + "]").remove();
    }

    updateReport(form, report) {
        preview = this.makeReportPreview(report, this.currentReport);
        this.reports[this.currentReport] = report;
        form = form.attr("data-report", this.currentReport);

        $("#report .report-preview[data-report=" + this.currentReport + "]").replaceWith(preview);
        $(".hidden-report[data-report=" + this.currentReport + "]").replaceWith(form);
    }

    getReportData(form) {
        report = {};
        report["name"] = $(".report-name input", form).val();
        report["due_date"] = $(".report-date input", form).val();
        report["format_text"] = $("select option:selected", form).text();
        report["format"] = $("select", form).val();
        report["desc"] = $("textarea", form).val();

        if (!this.checkReportData(report)) {
            report = {};
        }
        return report;
    }

    resetReportPopup(report){
        form = $("#create-report-modal .report-form");
        this.updateForm(form, []);
    }

    checkReportData(report) {
        var result = true;
        $.each(report, function (index, value) {
            if (value == "") {
                result = false;
            }
        });
        return result;
    }

    updateForm(form, report) {
        if (report) {
            $(".report-name input", form).val(report["name"]);
            $(".report-date input", form).val(report["due_date"]);
            $("select", form).val(report["format"]);
            $("textarea", form).val(report["desc"]);

            if (this.currentAction == "update") {
                form.attr("data-report-id", report["id"])
            }
        } else {
            $(".report-name input", form).val("");
            $(".report-date input", form).val("");
            $("select", form).val("");
            $("textarea", form).val("");
        }
        return form;
    }
}
