$(document).ready(function() {
    $.material.init();
    registerDateTimePickers();
    addClearButton();
    addTargetBankLinkMarkdown();
    registerPreviewFilePopupEvent();
    registerToggleFormDiv();
    registerClickCourseItem();
});

$.ajaxSetup({
    headers: {
        "X-CSRF-TOKEN": $("meta[name='_token']").attr("content")
    }
});

function registerDateTimePickers() {
    $(".date-picker").bootstrapMaterialDatePicker({ time: false })
                     .attr("readonly", true)
                     .addClass("clearable");
    $(".time-picker").bootstrapMaterialDatePicker({ format: "HH:mm", date: false })
                     .attr("readonly", true)
                     .addClass("clearable");
    $(".datetime-picker").bootstrapMaterialDatePicker({ format: "YYYY-MM-DD HH:mm" })
                     .attr("readonly", true)
                     .addClass("clearable");
}

function showToast(content, style, timeout) {
    $.snackbar({
        content: content,
        style: "toast " + style,
        timeout: timeout
    });
}

function getPageName() {
    return $("#page-js-name").data("js-name");
}

function isPage(pageName) {
    return pageName === getPageName();
}

function addClearButton()
{
    $("input[class*=clearable]").each((index, ele) => {
        if ($(ele).val() != "") {
            $(ele).after(`<button class="clear-input" type="button"></button>`);
        } else {
            $(ele).after(`<button class="clear-input hidden" type="button"></button>`);
        }
    }).on("change", (e) => {
        if ($(e.target).val() != "") {
            $(e.target).next().removeClass("hidden");
        } else {
            $(e.target).next().addClass("hidden");
        }
    });

    $("body").on("click", "button.clear-input", (e) => {
        $(e.target).addClass("hidden")
                   .prev("input")
                   .val("");
    });
}

function addTargetBankLinkMarkdown() {
    $(".markdown a").each((index, ele) => {
        href = $(ele).attr('href');
        if (href.search('#') == -1) {
            $(ele).attr('target', '_blank');
        }
    })
}

function registerPreviewFilePopupEvent() {
    $("body").on("click", ".preview-file", (e) => {
        showLink = $(e.target).attr("show");
        downloadLink = $(e.target).attr("download");
        title = $(e.target).attr("title");
        $("#file-preview .modal-dialog .modal-body iframe").attr("src", showLink);
        $("#file-preview .modal-dialog .modal-header .download").attr("href", downloadLink);
        $("#file-preview .modal-dialog .modal-header .modal-title").text(title);
        width = window.outerWidth - 50;
        height = window.outerHeight - 220;
        $("#file-preview .modal-dialog.modal-lg").css({
            "width": width,
            "height": height
        });
        $("#file-preview .modal-dialog.modal-lg iframe").attr("height", height);
        $('iframe').load(function() {
            if ($('iframe').contents().find("body img").length) {
                $('iframe').contents().find("body").attr("style", "text-align: center; margin: 0px;");
                $('iframe').contents().find("body img").attr("style", "max-width: 100%;");
            } else {
                $('iframe').contents().find("body").attr("style", "text-align: center; overflow: hidden; margin: 0px;");
            }
        });
    });
}

function registerToggleFormDiv() {
    $("body").on("click", ".sent-messages-list .show-form", (e) => {
        $(".sent-messages-list .hide-form").show();
        $(".sent-messages-list .show-form").hide();
        $(".msg-sent-all").addClass("hide");
    });
    $("body").on("click", ".sent-messages-list .hide-form", (e) => {
        $(".sent-messages-list .show-form").show();
        $(".sent-messages-list .hide-form").hide();
        $(".msg-sent-all").removeClass("hide");
    });

    $("body").on("click", ".sent-messages-list .show-content", (e) => {
        id = $(e.target).attr('id');
        $(`.hide-${id}`).show();
        $(`.show-${id}`).hide();
        $(`#msg-${id}`).show();
    });
    $("body").on("click", ".sent-messages-list .hide-content", (e) => {
        id = $(e.target).attr('id');
        $(`.show-${id}`).show();
        $(`.hide-${id}`).hide();
        $(`#msg-${id}`).hide();
    });
    
    $("body").on("click", ".sent-messages-list .show-content .mdi-navigation-arrow-drop-down", (e) => {
        id = $(e.target).parent().attr('id');
        $(`.hide-${id}`).show();
        $(`.show-${id}`).hide();
        $(`#msg-${id}`).show();
    });
    $("body").on("click", ".sent-messages-list .hide-content .mdi-navigation-arrow-drop-up", (e) => {
        id = $(e.target).parent().attr('id');
        $(`.show-${id}`).show();
        $(`.hide-${id}`).hide();
        $(`#msg-${id}`).hide();
    });
}

function registerClickCourseItem() {
    $("body").on("click", ".course-list .course-item", (e) => {
        href = $(e.target).closest("div.course-item").data("href");
        window.location.href = href;
    });
    $("body").on("click", ".common-lessons-list .lesson-item", (e) => {
        href = $(e.target).closest("div.lesson-item").data("href");
        window.location.href = href;
    });
}
