<?php

return [
    'dashboard' => [
        'next_lesson' => 'Check next lesson!',
        'current_lesson' => 'Check current lesson!',
        'date_time' => 'Date time',
        'room' => 'Room',
        'lessons' => 'Lessons',
        'reports' => 'Reports',
        'teacher' => 'Teacher',
    ],
    'lessons' => [
        'messages' => [
            'already_submit_report'  => 'You has already submit this report on ',
            'hasnt_submit_report'    => 'You hasn\'t submit this report! Please submit right now.',
            'lesson_isnt_start'      => 'Lesson is not start, you can not sumbit report now',
            'report_expired'         => 'Report is expired, you can not submit report anymore.',
            'attend_updated_success' => 'You has been attended lesson',
        ],
        'reports' => [
            'your_report' => 'Your report'
        ],
        'attend' => 'Attend',
        'attended' => 'Attended',
    ],
    'courses' => [
        'messages' => [
            'register_success' => 'Register course success',
            'register_already' => 'Register course already',
            'register_false'   => 'Something false, please try again later',
            'not_register'     => 'Please join course to view lesson(s).'
        ],
        'teacher_messages_list' => 'Teacher Messages List',
    ],
    'login' => 'Student Login',
    'subject_student_send_message' => '[Awesome Academy] Student send a message'
];
