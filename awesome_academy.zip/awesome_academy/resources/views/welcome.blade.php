@extends('layouts.default')
@section('main')
<div class="container">
    <div class="content">
        <h1>Laravel 5</h1>
        <h3>{{ Inspiring::quote() }}</h3>
    </div>
</div>
@stop