@extends('layouts.error', ['className' => 'page-maintenance'])

@section('main')
<div class="container maintenance">
    <h1>Maintenance</h1>
    <br />
    <h2>
        This website is currently down
        <br />
        because we're doing maintenance.
    </h2>
    <br />
    <br />
    <img alt="Maintenance" src="/img/503.png" />
</div>
@stop
