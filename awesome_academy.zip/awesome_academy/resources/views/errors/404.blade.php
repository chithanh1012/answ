@extends('layouts.error', ['className' => 'page-not-found'])

@section('main')
<div class="container notfound {{ $className }}">
    <h1>404</h1>
    <br />
    <h2>Page not found</h2>
    <br />
    <a href="/" title="Back to Home">Back to Home</a>
    <br />
    <br />
    <img alt="Page not found" src="/img/404.png" />
</div>
@stop
