@extends('layouts.emails')

@section('main')
<table class="table table-mail" style="width: 100%;margin-top: 10px;background-color: #FFFFFF;">
    <tr>
        <td align="center" style="padding: 0px">
            <table class="table" bgcolor="#ffffff" style="width: 100%">
                <tr>
                    <td align="left" class="logo" style="padding: 16px 16px 30px 16px;
                        background-color: #3F51B5; color: #FFFFFF;">
                        <h2>
                            Awesome Academyへ
                        </h2>
                        <h1 style="text-align: center;font-weight: normal;">ようこそ！</h1>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <h3 style="color: #3F51B5;padding: 13px 13px 0 13px;margin: 10px;">
                            アカウントをご登録頂きありがとうございます。
                        <br />
                            アカウントを有効化するため、以下にご案内する手順をご実行ください。
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <h3 style="color: #3F51B5;padding: 13px;margin: 10px;">
                            1．下記のリンクをクリックしアクセスして下さい。
                            <br />
                            2．表示されるページより、「Password」及び「Confirm password」に任意の
                            <br />
                            パスワード（8文字以上）をご入力頂き、『CREATE』ボタンを押下してください。
                            <br />
                            3．2が完了すると、パスワードが登録され、アカウントが有効化となります。
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td><hr style="border: 1px solid #E0E0E0;margin-left: 10px;margin-right: 10px;"/></td>
                </tr>
                <tr>
                    <td class="space_footer" style="padding:0!important">&nbsp;</td>
                </tr>
                <tr>
                    <td class="box">
                        <table class="table" style="width:100%">
                            <tr>
                                <td align="center">
                                    <a style="text-decoration: none;color: #ffffff;"
                                        href="{{ url('teacher/activate-account/' . $token) }}">
                                        <h2 style="margin: 0 55px 20px;padding: 40px;
                                            background-color:#424242;color:#ffffff;font-weight: normal;">
                                            アカウント有効化
                                        </h2>
                                    </a>
                                </td>
                            </tr>
                            <tr>
                                <td align="left">
                                    <h4 style="padding: 13px;margin: 10px;">
                                        ※本メールにお心あたりがない場合は、お手数ですが このままメールを破棄いただきますようお願いします。
                                    </h4>
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td class="footer" style="text-align: center;padding:7px 0;color: #BDBDBD;">
                        <span>
                            <h3>&copy; Framgia, Inc. All Rights Reserved.</h3>
                        </span>
                    </td>
                </tr>
            </table>
        </td>
    </tr>
</table>
@endsection
