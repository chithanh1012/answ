@extends('layouts.auth')

@section('main')
<div class="panel panel-default">
    <div class="panel-heading panel-custom">
        <h4>{{ trans('common.labels.update_profile') }}</h4>
    </div>
    <div class="panel-body">
        @include('layouts.includes._errors_list')
        {!! Form::open(['class' => 'form-horizontal']) !!}
            <div class="form-group">
                <label class="col-md-4 control-label required">
                    {{ trans('common.labels.fullname') }}
                </label>
                <div class="col-md-6">
                    {!! Form::text('full_name', $currentUser->full_name, [
                        'class' => 'form-control',
                        'placeholder' => trans('common.labels.fullname'),
                    ]) !!}
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-6 col-md-offset-4">
                    <button type="submit" class="btn btn-{{ $mainColor }}">
                        {{ trans('common.buttons.update') }}
                    </button>
                </div>
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection
