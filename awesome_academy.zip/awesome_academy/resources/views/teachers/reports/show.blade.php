@extends('layouts.default')

@section('main')
<div class="container common-tabbed-show-page">
    <div class="panel panel-{{ $mainColor }} panel-basic-info">
        <div class="panel-heading">
            <h4 class="break-word">
                <a href="{{ action('Teacher\LessonController@show', [$courseId, $lessonId, 'reports']) }}">
                    {{ $report->name }}
                </a>
            </h4>
        </div>
        <div class="panel-body">
            <div class="row col-md-12">
                <div class="col-md-4">
                    <span class="blur-text">{{ trans('common.lessons.due_date') }}: </span>
                    <span>{{ $report->due_date->format('d/m/Y') }}</span>
                </div>
                <div class="col-md-4">
                    <span class="blur-text">{{ trans('common.lessons.format') }}: </span>
                    <span>{{ get_report_format_options()[$report->format] }}</span>
                </div>
                <div class="col-md-4">
                    <span class="blur-text">{{ trans('common.labels.last_updated') }}: </span>
                    <span>{{ $report->updated_at->format('d/m/Y') }}</span>
                </div>
            </div>
            <div class="col-md-12 break-word text-justify blur-text">
                {!! nl2br_without_tags($report->desc) !!}
            </div>
        </div>
    </div>
    <div>
        <ul class="nav nav-tabs nav-{{ $mainColor }} tab-bar">
            <li class="active">
                <a href="#reports" class="tab-button" data-toggle="tab">
                    {{ trans('teachers.lessons.student_report') }}
                </a>
            </li>
        </ul>
        <div class="tab-content">
            <div id="reports" class="tab-pane fade active in clearfix">
                @foreach ($reportStudents as $key => $reportStudent)
                <div class="student-report">
                    <h4>
                        {{ ($reportStudents->currentPage() - 1)  * $reportStudents->perPage() + $key + 1  }}.
                        {{ $reportStudent->student->full_name }}
                        <small class="pull-right">{{ trans('common.labels.last_updated') }}: {{ $reportStudent->updated_at }}</small>
                    </h4>
                @if ($report->isTextFormat())
                    <div class="text-justify break-word">
                        {!! nl2br_without_tags($reportStudent->content) !!}
                    </div>
                @else
                    <ul>
                    @foreach ($reportStudent->media as $media)
                        <li class="media-item">
                            <a href="{{ url('/media/download/' . $media->id) }}" class="break-word">{{ $media->file_name }}</a>
                        </li>
                    @endforeach
                    </ul>
                @endif
                </div>
                <hr/>
                @endforeach
                {!! $reportStudents->render() !!}
            </div>
        </div>
    </div>
</div>
@stop
