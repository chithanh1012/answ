@extends('layouts.auth')

@section('main')
<div class="panel panel-default">
    <div class="panel-heading panel-custom">
        <h4>{{ trans('teachers.change_password') }}</h4>
    </div>
    <div class="panel-body">
        @include('layouts.includes._errors_list')
        {!! Form::open(['class' => 'form-horizontal']) !!}
            <div class="form-group">
                <label class="col-md-5 control-label required">
                    {{ trans('teachers.old_password') }}
                </label>
                <div class="col-md-7">
                    {!! Form::password('old_password', [
                        'class' => 'form-control',
                        'placeholder' => trans('teachers.old_password'),
                    ]) !!}
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-5 control-label required">
                    {{ trans('teachers.new_password') }}
                </label>
                <div class="col-md-7">
                    {!! Form::password('password', [
                        'class' => 'form-control',
                        'placeholder' => trans('common.labels.password'),
                    ]) !!}
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-5 control-label required">
                    {{ trans('teachers.confirm_new_password') }}
                </label>
                <div class="col-md-7">
                    {!! Form::password('password_confirmation', [
                        'class' => 'form-control',
                        'placeholder' => trans('common.labels.confirm_password'),
                    ]) !!}
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-7 col-md-offset-5">
                    <button type="submit" class="btn btn-{{ $mainColor }}">
                        {{ trans('teachers.change') }}
                    </button>
                </div>
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection
