@extends('layouts.auth', ['noMenus' => true])

@section('main')
<div class="panel panel-default">
    <div class="panel-heading panel-custom">
        <h4>{{ trans('teachers.login') }}</h4>
    </div>
    @include('layouts.includes._form_login', ['action' => url('/teacher/login'), 'type' => 'teacher'])
</div>
@endsection
