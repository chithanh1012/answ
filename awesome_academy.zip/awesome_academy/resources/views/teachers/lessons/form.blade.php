@extends('layouts.teacher', [
    'pageName'      => 'js-teacher-create-lesson',
])

@section('main_container')
<div class="col-sm-offset-2 col-sm-8">
    @include('layouts.includes._errors_list')

    {!! Form::open(['action' => $action, 'method' => $method, 'class' => 'form-horizontal', 'id' => 'create-lesson']) !!}
        <div class="col-md-10 col-md-offset-2" id="shortcut">
            <a href="#basic-info">{{ trans('common.lessons.basic_info') }}</a>
            <a href="#attach-document">{{ trans('common.lessons.attach_documents') }}</a>
            <a href="#report">{{ trans('common.lessons.report') }}</a>
        </div>
        <div id="basic-info"></div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.lessons.course') }}</label>
            <div class="col-sm-9">
                {!! Form::label(null, $course->name, ['class' => 'form-control']) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.lessons.location') }}</label>
            <div class="col-sm-9">
                {!! Form::text('location', $lesson->location, ['class' => 'form-control', 'placeholder' => $course->location]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.lessons.start_date') }} <span class="required">*</span></label>
            <div class="col-sm-4">
                {!! Form::text('start_date', $lesson->start_date ? $lesson->start_date->format('Y-m-d') : '', [
                    'class' => 'form-control date-picker',
                    'placeholder' => trans('common.lessons.start_date')
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.lessons.time') }} <span class="required">*</span></label>
            <div class="col-sm-4">
                {!! Form::text('start_time', $lesson->start_time ? $lesson->start_time->format('H:i') : $course->time_table[0]->start_time, [
                    'class' => 'form-control time-picker',
                    'placeholder' => trans('common.labels.from')
                ]) !!}
            </div>
            <div class="col-sm-4">
                {!! Form::text('end_time', $lesson->end_time ? $lesson->end_time->format('H:i') : $course->time_table[0]->end_time, [
                    'class' => 'form-control time-picker',
                    'placeholder' => trans('common.labels.to')
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.lessons.description') }}</label>
            <div class="col-sm-9">
                {!! Form::text('desc', $lesson->desc, ['class' => 'form-control', 'placeholder' => trans('common.lessons.description')]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.lessons.content') }}</label>
            <div class="col-sm-9">
                {!! Form::textarea('content', $lesson->content, [
                    'class' => 'form-control',
                    'rows' => 8,
                    'placeholder' => trans('common.lessons.content')
                ]) !!}
            </div>
        </div>

        <div id="attach-document">
            <div class="row">
                <div class="col-sm-9 col-sm-offset-3">
                    <h3 class="page-header text-center">
                        {{ trans('common.lessons.attach_documents') }}
                    </h3>
                    @include('layouts.includes.partials._drop_file', [
                        'medium' => $lesson->media,
                        'withExpiredDate' => true,
                    ])
                </div>
            </div>
        </div>

        <div class="row" id="report"
             data-url="{{ $isEditPage ? link_to_lesson($moduleName, $course->id, $lesson->id) . '/report' : '' }}">
            <div class="col-sm-9 col-sm-offset-3">
                <h3 class="page-header text-center">{{ trans('common.lessons.reports') }}</h3>
                <div class="alert alert-warning hidden">
                    {{ trans('common.messages.lessons.something_missing') }}
                </div>
                @if ($lesson->reports->count())
                    @include('layouts.lessons._reports_list', ['reports' => $lesson->reports])
                @endif
                @if (old('reports') && !$isEditPage)
                    @include('layouts.includes.partials._old_report_list', ['reports' => old('reports')])
                @endif
                <div class="btn-add">
                    <button type="button" class="btn btn-sm btn-rise btn-{{ $mainColor }}" id="btn-add" data-toggle="modal" data-target="#create-report-modal">
                        {{ trans('teachers.lessons.add_report') }}
                    </button>
                </div>
            </div>
        </div>

        <div class="form-group">
            <div class="col-sm-offset-3">
                <button class="btn btn-{{ $mainColor }} btn-raised">{{ trans('common.labels.submit') }}</button>
                <a href="{{ action('Teacher\LessonController@show', [$course->id, $lesson->id]) }}"
                    class="btn btn-{{ $mainColor }} btn-raised">
                    {{ trans('common.labels.back') }}
                </a>
            </div>
        </div>
    {!! Form::close() !!}

    <div id="media-item-template" class="hidden">
        @include('layouts.includes.partials._media_item', ['withExpiredDate' => true])
    </div>
    @include('layouts.includes.partials._create_report_popup')
</div>
@stop

@section('script')
    <script type="text/javascript">
        var isEditPage = {{ $isEditPage ? 1 : 0 }};
        var minDate = isEditPage ? "{{ $lesson->start_date }}" : moment();
    </script>
@endsection
