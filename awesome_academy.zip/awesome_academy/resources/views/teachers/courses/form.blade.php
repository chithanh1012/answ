@extends('layouts.teacher', ['pageName' => 'js-teacher-course'])

@section('main_container')
<div class="col-sm-offset-2 col-sm-8">
    @include('layouts.includes._errors_list')

    {!! Form::open(['action' => $action, 'method' => $method, 'class' => 'form-horizontal']) !!}
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.courses.name') }} <span class="required">*</span></label>
            <div class="col-sm-9">
                {!! Form::text('name', $course->name, ['class' => 'form-control', 'placeholder' => trans('common.courses.name')]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.courses.location') }} <span class="required">*</span></label>
            <div class="col-sm-9">
                {!! Form::text('location', $course->location, ['class' => 'form-control', 'placeholder' => trans('common.courses.location')]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.courses.max_students') }}</label>
            <div class="col-sm-4">
                {!! Form::text('max_students', $course->max_students ?: '', [
                    'class' => 'form-control',
                    'placeholder' => trans('common.labels.unlimited')
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.courses.register_type') }}</label>
            <div class="col-sm-4">
                {!! Form::select('register_type', get_course_types(), $course->register_type, ['class' => 'form-control']) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.labels.day') }} <span class="required">*</span></label>
            <div class="col-sm-4">
                {!! Form::select('day', get_day_options(),
                    $course->time_table ? $course->time_table[0]->day : 'mon',
                    ['class' => 'form-control']
                ) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.labels.time') }} <span class="required">*</span></label>
            <div class="col-sm-4">
                {!! Form::text('start_time',
                    $course->time_table ? $course->time_table[0]->start_time : '', [
                        'class' => 'form-control time-picker',
                        'placeholder' => trans('common.labels.from')
                    ]
                ) !!}
            </div>
            <div class="col-sm-4">
                {!! Form::text('end_time',
                    $course->time_table ? $course->time_table[0]->end_time : '', [
                        'class' => 'form-control time-picker',
                        'placeholder' => trans('common.labels.to')
                    ]
                ) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.courses.publish') }} <span class="required">*</span></label>
            <div class="col-sm-4">
                {!! Form::text('publish_started_at',
                    $course->publish_started_at ? $course->publish_started_at->format('Y-m-d') : '', [
                        'class' => 'form-control date-picker',
                        'placeholder' => trans('common.labels.from')
                    ]
                ) !!}
            </div>
            <div class="col-sm-4">
                {!! Form::text('publish_ended_at',
                    $course->publish_ended_at ? $course->publish_ended_at->format('Y-m-d') : '', [
                        'class' => 'form-control date-picker',
                        'placeholder' => trans('common.labels.to')
                    ]
                ) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.courses.description') }} <span class="required">*</span></label>
            <div class="col-sm-9">
                {!! Form::text('desc', $course->desc, [
                    'class' => 'form-control',
                    'placeholder' => trans('common.courses.description')
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">{{ trans('common.courses.content') }} </label>
            <div class="col-sm-9">
                {!! Form::textarea('content', $course->content, [
                    'class' => 'form-control',
                    'rows' => 8,
                    'placeholder' => trans('common.courses.content')
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-sm-3 control-label">Course Assistants</label>
            <div class="col-sm-9 assistant-list">
                <ol>
                    <li>
                    @if (isset($isEditPage))
                        {{ $course->teacher->full_name }} [{{ trans('teachers.courses.owner') }}]
                    @else
                        {{ $currentTeacher->full_name }} [{{ trans('teachers.courses.owner') }}]
                    @endif
                    </li>
                @if (old('teacher_ids'))
                    @for ($i = 0; $i < count(old('teacher_ids')); $i ++)
                        @include('layouts.courses._course_assistant', [
                            'teacher_id'  => old('teacher_ids')[$i],
                            'status'      => old('status')[$i],
                            'id'          => old('ids')[$i],
                            'teacherName' => old('teacherNames')[$i],
                        ])
                    @endfor
                @elseif ($course->courseAssistants->count())
                    @foreach ($course->courseAssistants as $courseAssistant)
                        @include('layouts.courses._course_assistant', [
                            'teacher_id'  => $courseAssistant->teacher->id,
                            'status'      => 'old',
                            'id'          => $courseAssistant->id,
                            'teacherName' => $courseAssistant->teacher->full_name
                        ])
                    @endforeach
                @endif
                </ol>
                <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#search-teacher">
                    {{ trans('common.buttons.add') }}
                </button>
            </div>
        </div>
        <div class="form-group">
            <div class="col-sm-offset-3">
                <button class="btn btn-{{ $mainColor }} btn-raised">
                    {{ trans('common.labels.submit') }}
                </button>
                <a href="/"
                    class="btn btn-{{ $mainColor }} btn-raised">
                    {{ trans('common.labels.back') }}
                </a>
            </div>
        </div>
    {!! Form::close() !!}
    @include('layouts.courses._search_teacher_popup')
</div>
@stop
