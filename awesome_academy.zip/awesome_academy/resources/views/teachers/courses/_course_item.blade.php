<div class="col-md-4 col-xs-6 course-item course-status-{{ $course->getStatus() }}" data-href="{{ $url }}">
    <div class="panel panel-{{ $mainColor }} shadow-z-1">
        <div class="panel-heading">
            <div class="row">
                <h3 class="panel-title truncate-text col-xs-7">{{ $course->name }}</h3>
                <div class="col-xs-5">
                    <div class="pull-right course-status course-status-{{ $course->getStatus() }}">
                        {{ trans('common.courses.status.' . $course->getStatus()) }}
                    </div>
                </div>
            </div>
        </div>
        <div class="panel-body">
            <div class="course-upper-row">
                <div class="row">
                    <div class="col-xs-4 truncate-text">
                        {{ trans('common.menus.lessons') }}:
                        <a class="e-resize" href="{{ url('teacher/courses', [$course->id, 'lessons']) }}">
                            {{ $course->getLessonsCount() }}
                        </a>
                    </div>
                    <div class="col-xs-4 truncate-text">
                        {{ trans('common.menus.students') }}:
                        <a class="e-resize" href="{{ url('teacher/courses', [$course->id, 'students']) }}">
                            {{ $course->getStudentsCount() }}
                        </a>
                    </div>
                    <div class="col-xs-4 truncate-text">
                        {{ trans('common.labels.messages') }}:
                        <a class="e-resize" href="{{ url('teacher/courses', [$course->id, 'messages']) }}">
                            {{ $course->getMessagesCount() }}
                        </a>
                    </div>
                </div>
            </div>
            <div class="course-lower-row">
                <div class="course-desc">
                    <p class="truncate-text">
                        {{ $course->desc }}
                    </p>
                </div>
                <div class="row">
                    <div class="col-sm-4 text-right">{{ trans('common.courses.time_table') }}:</div>
                    <div class="col-sm-8 truncate-text">
                        {{ $course->getTimeTable() }}
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4 text-right">{{ trans('common.courses.location') }}:</div>
                    <div class="col-sm-8 truncate-text">
                        {{ $course->location }}
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4 text-right">{{ trans('common.courses.publish') }}:</div>
                    <div class="col-sm-8 truncate-text">
                        {{ $course->publish_started_at->format(config('app.date_time_format')) }} -
                        {{ $course->publish_ended_at->format(config('app.date_time_format')) }}
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4 text-right">{{ trans('common.courses.type') }}:</div>
                    <div class="col-sm-8 truncate-text">
                        {{ strtoupper(get_course_types()[$course->register_type]) }}
                    </div>
                </div>
                <div class="row">
                    <div class="col-sm-4 text-right">{{ trans('common.labels.last_updated') }}:</div>
                    <div class="col-sm-8 truncate-text">
                        {{ $course->updated_at }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
