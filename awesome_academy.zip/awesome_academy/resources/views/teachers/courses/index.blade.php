@extends('layouts.default', ['pageName' => 'js-teacher-course'])

@section('main')
<div class="container course-index">
    <a href="/teacher/courses/create" class="btn btn-{{ $mainColor }} btn-raised">{{ trans('common.courses.create') }}</a>
    <a href="/teacher/courses/assistant" class="btn btn-{{ $mainColor }} btn-raised">{{ trans('common.courses.assistant_course') }}</a>
    <div class="checkbox checkbox-{{ $mainColor }}">
        <label for="show-courses" id="show-courses-done">
            <input type="checkbox" name="show_courses_done" id="show-courses">
            {{ trans('common.labels.show_courses_done') }}
        </label>
    </div>
    <div class="course-list row">
    @foreach ($courses as $course)
        @include('teachers.courses._course_item', ['url' => url('/teacher/courses/' . $course->id)])
    @endforeach
    </div>
    {!! $courses->render() !!}
</div>
@stop
