@extends('layouts.auth')

@section('main')
@include('layouts.includes._alert_message')
<div class="panel panel-default">
    <div class="panel-heading panel-custom">
        <h4>{{ trans('common.labels.send_password_reset_link') }}</h4>
    </div>
    <div class="panel-body">
        @include('layouts.includes._errors_list')
        {!! Form::open(['class' => 'form-horizontal']) !!}
            <div class="form-group">
                <label class="col-md-4 control-label required">
                    {{ trans('common.labels.email') }}
                </label>
                <div class="col-md-7">
                    {!! Form::email('email', null, [
                        'class' => 'form-control',
                        'value' => old('email'),
                        'placeholder' => trans('common.labels.email'),
                    ]) !!}
                </div>
            </div>
            <div class="form-group">
                <div class="col-md-7 col-md-offset-4">
                    <button type="submit" class="btn btn-{{ $mainColor }}">{{ trans('common.buttons.send') }}</button>
                </div>
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection
