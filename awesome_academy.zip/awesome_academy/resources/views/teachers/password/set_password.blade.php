@extends('layouts.auth')

@section('main')
<div class="panel panel-default">
    <div class="panel-heading panel-custom">
        <h4>{{ trans('common.labels.set_password') }}</h4>
    </div>
    <div class="panel-body">
        @include('layouts.includes._errors_list')
        {!! Form::open(['action' => 'Teacher\PasswordController@postSetPassword', 'class' => 'form-horizontal']) !!}
            {!! Form::hidden('token', $token) !!}
            <div class="form-group">
                <label class="col-md-4 control-label required">
                    {{ trans('common.labels.password') }}
                </label>
                <div class="col-md-7">
                    {!! Form::password('password', [
                        'class' => 'form-control',
                        'placeholder' => trans('common.labels.password'),
                    ]) !!}
                </div>
            </div>
            <div class="form-group">
                <label class="col-md-4 control-label required">
                    {{ trans('common.labels.confirm_password') }}
                </label>
                <div class="col-md-7">
                    {!! Form::password('password_confirmation', [
                        'class' => 'form-control',
                        'placeholder' => trans('common.labels.password'),
                    ]) !!}
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-7 col-md-offset-4">
                    <button type="submit" class="btn btn-{{ $mainColor }}">
                        {{ trans('common.buttons.create') }}
                    </button>
                </div>
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection
