@extends('layouts.auth')

@section('main')
<div class="panel panel-default">
    <div class="panel-heading panel-custom">
        <h4>{{ trans('common.labels.reset_password') }}</h4>
    </div>
    <div class="panel-body">
        @include('layouts.includes._errors_list')
        {!! Form::open(['action' => 'Teacher\PasswordController@postReset', 'class' => 'form-horizontal']) !!}
            <input type="hidden" name="token" value="{{ $token }}">
            <div class="form-group">
                <label class="col-md-4 control-label required">
                    {{ trans('common.labels.email') }}
                </label>
                <div class="col-md-7">
                    <input class="form-control" name="email" value="{{ old('email') }}"
                        placeholder="{{ trans('common.labels.email') }}">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label required">
                    {{ trans('common.labels.password') }}
                </label>
                <div class="col-md-7">
                    <input type="password" class="form-control" name="password"
                        placeholder="{{ trans('common.labels.password') }}">
                </div>
            </div>

            <div class="form-group">
                <label class="col-md-4 control-label">
                    {{ trans('common.labels.confirm_password') }}
                </label>
                <div class="col-md-7">
                    <input type="password" class="form-control" name="password_confirmation"
                        placeholder="{{ trans('common.labels.confirm_password') }}">
                </div>
            </div>

            <div class="form-group">
                <div class="col-md-7 col-md-offset-4">
                    <button type="submit" class="btn btn-{{ $mainColor }}">
                        {{ trans('common.buttons.reset') }}
                    </button>
                </div>
            </div>
        {!! Form::close() !!}
    </div>
</div>
@endsection
