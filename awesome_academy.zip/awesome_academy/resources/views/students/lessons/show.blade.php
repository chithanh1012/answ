@extends('layouts.default', ['pageName' => 'js-lesson-detail'])

@section('main')
<div class="container lesson-detail">
    <!-- Course detail -->
    @include('layouts.includes.partials._lesson_detail')
    <hr>
    <!-- Lesson detail -->
    <div class="lesson-content text-justify markdown">
        {!! $lesson->getParsedContent() !!}
    @if (is_teacher_view($moduleName))
        <div>
            <a href="{{ url('/teacher/courses/' . $course->id . '/lessons/' . $lesson->id . '/edit') }}" class="btn btn-sm btn-{{ $mainColor }}">{{ trans('common.buttons.edit_lesson') }}</a>
        </div>
    @endif
    </div>
    <hr>
    <!-- Files list -->
    <span class="blur-text">{{ trans('common.labels.files') }}</span>
    @include('layouts.includes.partials._lesson_file_list')
    <hr>
    <!-- Student's reports list -->
    <span class="blur-text">{{ trans('common.labels.reports') }}</span>
    @include('layouts.includes.partials._student_report_list')
    <hr>
    <!-- Message from student -->
    <span class="blur-text">{{ trans('common.labels.messages') }} (<b>{{ $messages ? $messages->count() : 0 }}</b>)</span>
    @if ($currentStudent)
    <div id="messages" class="">
        <div class="message-list">
            <div class="row col-md-12">
                @if ($currentStudent && $joined)
                <div class="comment-respond">
                    @include('layouts.includes._errors_list')
                    {!! Form::open(['action' => $action, 'method' => $method, 'class' => 'form-horizontal comment-form']) !!}
                     <div class="form-group content">
                        <div class="col-sm-12 content-msg">
                            {!! Form::textarea('content', '', [
                                'class' => 'form-control',
                                'rows' => 5,
                                'cols' => 30,
                                'placeholder' => trans('common.labels.content')
                            ]) !!}
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <button class="btn btn-{{ $mainColor }} btn-raised">{{ trans('common.labels.send_btn') }}</button>
                        </div>
                    </div>
                    {!! Form::close() !!}
                </div>
                @endif
                @if ($messages->count())
                <div class="checkbox">
                    <label for="hide-replied-message">
                        <input type="checkbox" name="hide_replied_message" id="hide-replied-message"> {{ trans('common.labels.hide_replied_message') }}
                    </label>
                </div>
                @endif
            </div>
            @foreach ($messages as $key => $message)
                @if ($currentStudent && $message->student_id == $currentStudent->id)
            <div class="row {{ $message->repliedMessage ? 'message-replied' : '' }}" id="msg-{{ $message->id }}">
                <div class="col-md-12">
                    @if ($message->repliedMessage)
                    <button class="btn btn-{{ $mainColor }} btn-raised disabled">{{ trans('common.labels.replied')}}</button>
                    @endif
                    <div class="msg-send" id="msg-send-{{ $message->id }}">
                        <div class="text-right send-date">
                            <span>{{ trans('common.labels.send_date') }}</span>
                            <label class="control-label">{{ $message->created_at->format('d/m/Y H:i') }}</label>
                        </div>
                        <div class="break-word">
                            <div class="more">
                                {!! str_limit($message->getParsedContent(), $stringLengthLimit) !!}
                                @if (strlen($message->getParsedContent()) > $stringLengthLimit)
                                <a class="morelink" href="javascript:;">{{ trans('common.labels.more') }}</a>
                                @endif
                            </div>
                            <div class="less">
                                {!! $message->getParsedContent() !!}
                                <a class="lesslink" href="javascript:;">{{ trans('common.labels.close') }}</a>
                            </div>
                        </div>
                    </div>
                    @if ($message->repliedMessage)
                    <div class="msg-replied" id="msg-replied-{{ $message->id }}">
                        <div class="text-right replied-date">
                            <span>{{ trans('common.labels.replied_date') }}</span>
                            <label class="control-label">{{ $message->repliedMessage->created_at ? $message->repliedMessage->created_at->format('d/m/Y H:i') : '' }}</label>
                        </div>
                        <div class="break-word">
                            <div class="more">
                                {!! str_limit($message->repliedMessage->getParsedContent(), $stringLengthLimit) !!}
                                @if (strlen($message->repliedMessage->getParsedContent()) > $stringLengthLimit)
                                <a class="morelink" href="javascript:;">{{ trans('common.labels.more') }}</a>
                                @endif
                            </div>
                            <div class="less">
                                {!! $message->repliedMessage->getParsedContent() !!}
                                <a class="lesslink" href="javascript:;">{{ trans('common.labels.close') }}</a>
                            </div>
                        </div>
                    </div>
                    @endif
                    <hr />
               </div>
            </div>
                @endif
            @endforeach
        </div>
    </div>
    @endif
</div>
@stop

@section('script')
    <script type="text/javascript">
        var listLessons  = $.parseJSON('{!! json_encode($listLessons) !!}');
        var baseUrl = "{{ url('courses/' . $course->id . '/lessons/') }}";
        var selectedDate = "{{ $lesson->start_date->format('Y-m-d') }}";
    </script>
@endsection
