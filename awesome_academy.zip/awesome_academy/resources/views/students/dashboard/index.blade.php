@extends('layouts.default', ['pageName' => 'js-student-dashboard'])

@section('main')
<div class="container dashboard">
    <div class="row courses course-list">
    @foreach ($courses as $course)
        <div class="col-md-4 course-item" data-href="{{ url('courses/' . $course->id) }}">
            <div class="panel panel-{{ $mainColor }} shadow-z-1">
                <div class="panel-heading">
                    <h3 class="panel-title truncate-text">
                        {{ $course->name }}
                    </h3>
                </div>
                <div class="panel-body course-desc">
                    <p class="truncate-text">
                        {{ $course->desc }}
                    </p>
                </div>
                <div class="panel-body course-lesson">
                    <div class="course-next-lesson">
                    @if ($course->currentLesson)
                        <a class="e-resize" href="{{ url('courses/' . $course->id . '/lessons/' . $course->currentLesson->id) }}">
                    @elseif ($course->nextLesson)
                        <a class="e-resize" href="{{ url('courses/' . $course->id . '/lessons/' . $course->nextLesson->id) }}">
                    @else
                        <a class="e-resize disabled">
                    @endif
                            <i class="mdi-content-send"></i>
                        @if ($course->currentLesson)
                            <span>{{ trans('students.dashboard.current_lesson') }}</span>
                        @else
                            <span>{{ trans('students.dashboard.next_lesson') }}</span>
                        @endif
                        </a>
                    </div>
                </div>
                <div class="panel-body">
                    <div class="course-date break-word">
                        {{ trans('students.dashboard.date_time') }}:
                        <strong>
                        @if ($course->currentLesson)
                            {{ $course->currentLesson->start_date->format(config('app.date_time_format'))}}
                            {{ $course->getCurrentLessonDay() }}
                            <br />
                            <span>
                                {{ $course->getCurrentLessonTime() }}
                            </span>
                        @elseif ($course->nextLesson)
                            {{ $course->nextLesson->start_date->format(config('app.date_time_format'))}}
                            {{ $course->getNextLessonDay() }}
                            <br />
                            <span>
                                {{ $course->getNextLessonTime() }}
                            </span>
                        @endif
                        </strong>
                    </div>
                    <div class="course-room truncate-text">
                        {{ trans('students.dashboard.room') }}:
                        <strong class="course-room-content">
                        @if ($course->currentLesson)
                            {{ $course->getCurrentLessonLocation() }}
                        @else
                            {{ $course->getNextLessonLocation() }}
                        @endif
                        </strong>
                    </div>
                    <div class="course-teacher truncate-text">
                        {{ trans('students.dashboard.teacher') }}:
                        <strong class="course-teacher-content" title="{{ $course->teacher->full_name }}">
                            {{ $course->teacher->full_name }}
                        </strong>
                    </div>
                </div>
                <div class="panel-footer">
                    <div class="course-footer break-word">
                        @if ($course->getLessonsCount())
                        <a class="e-resize" href="{{ url("courses/{$course->id}/lessons") }}">
                            <span>
                                {{ trans('students.dashboard.lessons') }}:
                                <strong>{{ $course->getLessonsCount() }}</strong>
                            </span>
                        </a>
                        @else
                        <a class="course-footer-lessons">
                            {{ trans('students.dashboard.lessons') }}:
                            <strong>{{ $course->getLessonsCount() }}</strong>
                        </a>
                        @endif
                        <a>
                            {{ trans('students.dashboard.reports') }}:
                            <strong>{{ $course->reports()->count() }}</strong>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    @endforeach
    </div>
    {!! $courses->render() !!}
</div>
@stop
