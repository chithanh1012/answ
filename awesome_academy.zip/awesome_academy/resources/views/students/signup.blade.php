@extends('layouts.auth')

@section('main')
<div class="panel panel-default">
    <div class="panel-heading">{{ trans('common.labels.student_signup') }}</div>
    @include('layouts.includes._form_signup', ['action' => url('/signup')])
</div>
@endsection
