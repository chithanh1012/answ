@extends('layouts.auth', ['pageName' => 'js-login'])

@section('main')
    <div class="btn-group btn-group-lg btn-group-justified panel" role="group">
        <a class="btn btn-white btn-auth" href="{{ get_login_uri() }}">
            {{ trans('common.buttons.login') }}
        </a>
    </div>
    @if (get_signup($moduleName))
    <div class="btn-group btn-group-lg btn-group-justified panel" role="group">
        <a class="btn btn-white btn-auth" href="{{ get_signup_uri() }}">
            {{ trans('common.buttons.signup') }}
        </a>
    </div>
    @endif
@endsection
