@extends('layouts.default')

@section('main')
    <div class="container">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">{{ $course->name }}</div>
                <div class="panel-body">
                    <div class="markdown">
                        {!! $lesson->getParsedContent() !!}
                    </div>
                    <hr>
                    <div>
                        <div class="form-group text-justify">
                            {{ $report->desc }}
                        </div>
                        <hr>
                        <div class="form-group">
                        <h3>{{ trans('students.lessons.reports.your_report') }}</h3>
                        @if ($report->isTextFormat())
                            <p class="text-justify break-word">
                                {{ $reportStudent->content }}
                            </p>
                        @else
                            <div class="file-list">
                                <ul>
                                @foreach ($reportStudent->media as $media)
                                    <li>
                                        <a href="{{ url('/media/download/' . $media->id) }}">{{ $media->file_name }}</a>
                                    </li>
                                @endforeach
                                </ul>
                            </div>
                        @endif
                        </div>

                    </div>
                </div>
            </div>
        </div>
    </div>
@stop
