@extends('layouts.default', [
    'pageName' => 'js-student-create-report',
])

@section('main')
    <div class="container create-report">
        <div class="row">
            <div class="panel panel-{{ $mainColor }}">
                <div class="panel-heading">
                    <a href="{{ url('courses/' . $course->id . '/lessons/' . $lesson->id . '/reports') }}">
                        {{ $course->name }}
                    </a>
                </div>
                <div class="panel-body">
                {!! Form::open(['class' => 'form-horizontal']) !!}
                    <div class="report-detail">
                        <div class="form-group text-justify">
                            {{ $report->desc }}
                        </div>
                        <hr>
                    @if ($report->isTextFormat())
                        <div class="form-group">
                            <textarea name="content" class="form-control" rows="5" placeholder="Content"></textarea>
                        </div>
                        <button class="btn btn-sm btn-{{ $mainColor }} pull-right">
                            {{ trans('common.buttons.submit') }}
                        </button>
                    @else
                        <div class="row">
                            <div class="col-sm-6 col-sm-offset-3">
                                @include('layouts.includes.partials._drop_file')

                                <button class="btn btn-sm btn-{{ $mainColor }} pull-right">
                                    {{ trans('common.buttons.submit') }}
                                </button>
                            </div>
                        </div>
                    @endif
                    </div>
                @if ($currentReport)
                    <div class="col-md-12">
                        <hr>
                        <label>Old report</label>
                        <small>Last update: {{ $currentReport->updated_at }}</small>
                    @if ($report->isTextFormat())
                        <div class="text-justify break-word">
                            {!! nl2br_without_tags($currentReport->content) !!}
                        </div>
                    @else
                        <ol id="old-media-list">
                        @foreach ($currentReport->media as $media)
                            <li class="media-item">
                                <input type="hidden" name="media_id[]" value="{{ $media->id }}" />
                                <input type="hidden" name="media_status[]" value="" />
                                <input type="hidden" name="media_name[]" value="{{ $media->file_name }}" />
                                <a href="{{ url('/media/download/' . $media->id) }}" class="break-word">{{ $media->file_name }}</a>
                                (<a href="#" class="media-delete">Delete</a>)
                            </li>
                        @endforeach
                        </ol>
                    @endif
                    </div>
                @endif
                {!! Form::close() !!}
                </div>
            </div>
        </div>
        <div id="media-item-template" class="hidden">
            @include('layouts.includes.partials._media_item')
        </div>
    </div>
@stop
