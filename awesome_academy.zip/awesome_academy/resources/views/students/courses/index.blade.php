@extends('layouts.default', [
    'pageName'      => 'js-student-courses',
    'activeMenu'    => 'courses',
])

@section('main')
<div class="container">
    <div class="course-list row">
    @foreach ($courses as $course)
        @include('students.courses._course_item', ['url' => url('/courses/' . $course->id)])
    @endforeach
    </div>
    {!! $courses->render() !!}
</div>
@stop
