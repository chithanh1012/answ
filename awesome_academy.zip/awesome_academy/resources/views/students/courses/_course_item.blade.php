<div class="col-md-4 col-xs-6 course-item" data-href="{{ $url }}">
    <div class="panel panel-{{ $mainColor }} shadow-z-1">
        <div class="panel-heading">
            <h3 class="panel-title truncate-text">{{ $course->name }}</h3>
        </div>
        <div class="panel-body">
            <div class="course-desc">
                <p class="truncate-text">
                    {{ $course->desc }}
                </p>
            </div>
            <div class="course-location truncate-text">
                {{ trans('common.courses.location') }}: {{ $course->location }}
            </div>
            <div class="course-status">
                {{ trans('common.courses.student_number') }}: {{ $course->students->count() }} {{ $course->max_students ? '/ ' . $course->max_students : ''}}
            </div>
            <div class="date">
                {{ trans('common.courses.publish') }}: {{ $course->publish_started_at->format(config('app.date_time_format')) }} - {{ $course->publish_ended_at->format(config('app.date_time_format')) }}
            </div>
        </div>
    </div>
</div>
