@extends('layouts.default', ['pageName' => 'js-student-course-view'])

@section('main')
<div class="container student common-tabbed-show-page">
    @include('layouts.includes._alert_message')
    <div class="panel panel-{{ $mainColor }}">
        <div class="panel-heading"><h3 class="break-word">{{ $course->name }}</h3></div>
            <div class="panel-body">
                @include('layouts.includes.partials._course_info')
            </div>
    </div>
    @include('layouts.includes.partials._course_extra_info')
</div>
@stop

@section('script')
    <script type="text/javascript">
        var listLessons  = $.parseJSON('{!! json_encode($listLessons) !!}');
        var baseUrl = "{{ url('courses/' . $course->id . '/lessons/') }}";
    </script>
@endsection
