<div id="search-student" class="modal fade bs-example-modal-lg"
     tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">{{ trans('teachers.courses.search_student') }}</h4>
            </div>
            <div class="modal-body">
                {!! Form::open([
                    'data-action' => url('/teacher/courses/' . $course->id . '/search'),
                    'data-method' => 'POST',
                    'id' => 'popup-search-form',
                    'class' => 'form-horizontal'
                ]) !!}
                    <div class="form-group">
                        <div class="col-sm-9">
                            {!! Form::text('name', null, [
                                'class' => 'form-control',
                                'placeholder' => trans('teachers.courses.student_name')
                            ]) !!}
                        </div>
                        <div class="col-sm-3">
                            <button type="button" id="btnSearch" class="btn btn-{{ $mainColor }}"
                                    data-form-id="#popup-search-form" data-result-table="#result-table">
                                {{ trans('teachers.courses.search') }}
                            </button>
                        </div>
                    </div>
                    <div class="alert alert-warning hidden"></div>
                {!! Form::close() !!}

                {!! Form::open([
                    'data-action' => url('/teacher/courses/' . $course->id . '/invite_students'),
                    'data-method' => 'POST',
                    'id' => 'popup-add-form',
                    'class' => 'form-horizontal'
                ]) !!}
                    <div class="form-group">
                        <div class="col-sm-9">
                            {!! Form::textarea('identity_number_list', null, [
                                'class' => 'form-control',
                                'id' => 'student-list',
                                'placeholder' => trans('teachers.courses.identity_number_list')
                            ]) !!}
                        </div>
                        <div class="col-sm-3">
                            <button type="button" id="btnAddList" class="btn btn-{{ $mainColor }}"
                                    data-form-id="#popup-add-form">
                                {{ trans('common.buttons.add') }}
                            </button>
                        </div>
                    </div>
                    <div class="alert alert-warning hidden"></div>
                {!! Form::close() !!}

                {!! Form::open([
                    'data-action' => url('/teacher/courses/' . $course->id . '/invite'),
                    'data-method' => 'POST',
                    'id' => 'popup-result-form',
                    'class' => 'form-horizontal'
                ]) !!}
                    <table class="table table-bordered" id="result-table">
                        <thead>
                            <th>#</th>
                            <th>
                                {{ trans('common.labels.identity_number') }}
                            </th>
                            <th>
                                {{ trans('common.labels.fullname') }}
                            </th>
                            <th>
                                {{ trans('teachers.courses.invite') }}
                            </th>
                        </thead>
                        <tbody></tbody>
                    </table>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
</div>
