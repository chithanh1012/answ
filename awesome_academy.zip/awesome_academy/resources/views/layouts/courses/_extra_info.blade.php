<div class="view-course-tabs">
    <ul class="nav nav-tabs nav-{{ $mainColor }} tab-bar">
        <li class="{{ !$currentTab ? 'active' :  '' }}">
            <a href="#description" class="tab-button" data-toggle="tab"
                data-url="{{ link_to_course($moduleName, $course->id) }}">
                {{ trans('common.courses.content') }}
            </a>
        </li>
    @if ($currentUser && $currentUser->can('view-lesson-student-message', $course))
        <li class="{{ $currentTab === 'lessons' ? 'active' :  '' }}">
            <a href="#lessons" class="tab-button" data-toggle="tab"
                data-url="{{ link_to_course($moduleName, $course->id, 'lessons') }}">
                {{ trans('common.labels.lessons') }}
                (<b>{{ $lessons ? $lessons->count() : 0 }}</b>)
            </a>
        </li>
        <li class="tab-button {{ $currentTab === 'students' ? 'active' :  '' }}">
            <a href="#students" class="tab-button" data-toggle="tab"
                data-url="{{ link_to_course($moduleName, $course->id, 'students') }}">
                {{ trans('common.labels.students') }}
                (<b>{{ $courseStudents->count() }}</b>)
            </a>
        </li>
        @if (is_teacher_view($moduleName))
        <li class="{{ $currentTab === 'assistants' ? 'active' :  '' }}">
            <a href="#assistants" class="tab-button" data-toggle="tab"
                data-url="{{ link_to_course($moduleName, $course->id, 'assistants') }}">
                {{ trans('common.courses.assistant_course') }}
                (<b>{{ $courseAssistants->count() + 1 }}</b>)
            </a>
        </li>
        @endif
        @if (is_teacher_view($moduleName))
        <li class="{{ $currentTab === 'sentmessages' ? 'active' :  '' }}">
            <a href="#sentmessages" class="tab-button" data-toggle="tab"
                data-url="{{ link_to_course($moduleName, $course->id, 'sentmessages') }}">
                {{ trans('teachers.sent_messages_list') }}
                (<b>{{ $sentMessages ? $sentMessages->count() : 0 }}</b>)
            </a>
        </li>
        @else
        <li class="{{ $currentTab === 'teachermessages' ? 'active' :  '' }}">
            <a href="#teachermessages" class="tab-button" data-toggle="tab"
                data-url="{{ link_to_course($moduleName, $course->id, 'teachermessages') }}">
                {{ trans('students.courses.teacher_messages_list') }}
                (<b>{{ $teacherMessages ? $teacherMessages->count() : 0 }}</b>)
            </a>
        </li>
        @endif
        <li class="{{ $currentTab === 'messages' ? 'active' :  '' }}">
            <a href="#messages" class="tab-button" data-toggle="tab"
                data-url="{{ link_to_course($moduleName, $course->id, 'messages') }}">
                @if (is_teacher_view($moduleName))
                    {{ trans('teachers.received_messages_list') }}
                @else
                    {{ trans('teachers.sent_messages_list') }}
                @endif
                (<b>{{ $messages ? $messages->count() : 0 }}</b>)
            </a>
        </li>
    @endif
    </ul>
    <div class="tab-content">
        <div id="description" class="tab-pane fade {{ !$currentTab ? 'active in' :  '' }} text-justify markdown clearfix">
            {!! $course->getParsedContent() !!}
        </div>
        <div id="lessons" class="tab-pane fade {{ $currentTab === 'lessons' ? 'active in' :  '' }}">
            @include('layouts.courses._lessons_list', ['lessons' => $lessons])
        </div>
        <div id="students" class="tab-pane fade {{ $currentTab === 'students' ? 'active in' :  '' }}">
        @if (is_teacher_view($moduleName) && !$course->isOpenRegister())
            <div class="pull-right">
                <button class="btn btn-{{ $mainColor }} btn-search" data-toggle="modal" data-target="#search-student">
                    {{ trans('teachers.courses.invite_student') }}
                </button>
            </div>
        @endif
            @include('layouts.courses._students_list')
        </div>

        @if (is_teacher_view($moduleName))
            @include('layouts.courses._course_assistants_list')
            @include('layouts.courses._sent_messages_list', [
                'currentTeacher' => $currentTeacher,
                'teacherAction' => $teacherAction,
                'method' => $method,
                'totalCourseStudents' => $courseStudents->count(),
            ])
        @else
            @include('layouts.courses._sent_messages_list', [
                'currentTeacher' => '',
            ])
        @endif


        @include('layouts.courses._messages_list', [
            'currentStudent' => $currentStudent,
            'currentTeacher' => $currentTeacher,
            'joined' => $joined,
            'action' => $action,
            'method' => $method,
            'messages' => $messages,
            'allowReply' => $allowReply,
        ])
    </div>
</div>
