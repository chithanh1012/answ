<div id="assistants" class="tab-pane fade {{ $currentTab === 'assistants' ? 'active in' :  '' }} clearfix">
    <table class="table table-bordered table-striped">
        <thead>
            <th>{{ trans('common.labels.fullname') }}</th>
        </thead>
        <tbody>
            <tr>
                <td>
                    {{ $course->teacher->full_name }} [{{ trans('teachers.courses.owner') }}]
                </td>
            </tr>
        @foreach ($courseAssistants as $courseAssistant)
            <tr>
                <td>
                    {{ $courseAssistant->teacher->full_name }}
                </td>
            </tr>
        @endforeach
        </tbody>
    </table>
</div>
