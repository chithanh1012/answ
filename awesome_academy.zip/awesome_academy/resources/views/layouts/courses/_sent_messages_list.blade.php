@if ($currentTeacher)
<div id="sentmessages" class="tab-pane fade {{ $currentTab === 'sentmessages' ? 'active in' :  '' }} clearfix">
    <div class="sent-messages-list">
    @include('layouts.includes._alert_message')
    @include('layouts.includes._errors_list')
    @if ($totalCourseStudents)
    <div class="panel panel-default shadow-z-1">
        <div class="panel-body">
            {!! Form::open(['action' => $teacherAction, 'method' => $method, 'class' => 'form-horizontal comment-form']) !!}
                <div>
                    <div class="col-sm-12">
                        <label class="control-label pull-right hide-form">
                            <i class="mdi-navigation-arrow-drop-down mdi-lg"></i>
                            {{ trans('common.labels.open') }}
                        </label>
                        <label class="control-label pull-right show-form">
                            <i class="mdi-navigation-arrow-drop-up mdi-lg"></i>
                            {{ trans('common.labels.close') }}
                        </label>
                    </div>
                </div>
                <div class="msg-sent-all">
                    <div class="form-group">
                        <label class="col-sm-2 control-label">{{ trans('common.courses.name') }} <span class="required">*</span></label>
                        <div class="col-sm-6">
                            {!! Form::text('title', '', ['class' => 'form-control', 'placeholder' => trans('common.courses.name')]) !!}
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-sm-2 control-label">{{ trans('common.labels.content') }} <span class="required">*</span></label>
                        <div class="col-sm-10">
                            {!! Form::textarea('content', '', [
                                'class' => 'form-control',
                                'rows' => 5,
                                'cols' => 20,
                                'placeholder' => trans('common.labels.content')
                            ]) !!}
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-offset-2">
                            <button class="btn btn-{{ $mainColor }} btn-raised">{{ trans('common.buttons.send_to_all') }}</button>
                        </div>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
    @endif
    @foreach ($sentMessages as $msg)
    <div class="col-md-12 thumbnail shadow-z-1">
        <div class="col-sm-12">
            <label class="control-label pull-right show-content show-content-{{ $msg->id }}" id="content-{{ $msg->id }}">
                <i class="mdi-navigation-arrow-drop-down mdi-lg"></i>
                {{ trans('common.labels.open') }}
            </label>
            <label class="control-label pull-right hide-content hide-content-{{ $msg->id }}" id="content-{{ $msg->id }}">
                <i class="mdi-navigation-arrow-drop-up mdi-lg"></i>
                {{ trans('common.labels.close') }}
            </label>
        </div>
        <div class="col-md-2">
            <label class="control-label">{{ $msg->created_at->format('d/m/Y H:i') }}</label>
        </div>
        <div class="col-md-10 title">
            <label>{{ $msg->title}}</label>
        </div>
        <div class="col-md-offset-2 break-word msg-content" id="msg-content-{{ $msg->id }}">
            {!! $msg->getParsedContent() !!}
        </div>
    </div>
    @endforeach
@else
<div id="teachermessages" class="tab-pane fade {{ $currentTab === 'teachermessages' ? 'active in' :  '' }} clearfix">
    <div class="sent-messages-list">
        @foreach ($teacherMessages as $msg)
        <div class="col-md-12 thumbnail shadow-z-1">
            <div class="col-sm-12">
                <label class="control-label pull-right show-content show-content-{{ $msg->id }}" id="content-{{ $msg->id }}">
                    <i class="mdi-navigation-arrow-drop-down mdi-lg"></i>
                    {{ trans('common.labels.open') }}
                </label>
                <label class="control-label pull-right hide-content hide-content-{{ $msg->id }}" id="content-{{ $msg->id }}">
                    <i class="mdi-navigation-arrow-drop-up mdi-lg"></i>
                    {{ trans('common.labels.close') }}
                </label>
            </div>
            <div class="col-md-2">
                <label class="control-label">{{ $msg->created_at->format('d/m/Y H:i') }}</label>
            </div>
            <div class="col-md-10 title">
                <label>{{ $msg->title}}</label>
            </div>
            <div class="col-md-offset-2 break-word msg-content" id="msg-content-{{ $msg->id }}">
                {!! $msg->getParsedContent() !!}
            </div>
        </div>
        @endforeach
@endif
    </div>
</div>