<div class="student-list">
    <table class="table table-bordered table-striped">
        <tr>
            <th class="student-id">{{ trans('common.labels.identity_number') }}</th>
            <th class="student-name">{{ trans('common.labels.fullname') }}</th>
            @if (is_teacher_view($moduleName))
            <th class="student-email">{{ trans('common.labels.email') }}</th>
            <th class="student-status">{{ trans('common.labels.status') }}</th>
            <th class="student-status">{{ trans('common.labels.active') }}</th>
            <th class="student-memo">{{ trans('teachers.courses.memo') }}</th>
            @endif
        </tr>
    @if ($courseStudents)
        @foreach ($courseStudents as $courseStudent)
        <tr>
            <td>{{ $courseStudent->student->identity_number }}</td>
            <td>{{ $courseStudent->student->full_name }}</td>
            @if (is_teacher_view($moduleName))
            <td>{{ $courseStudent->student->email }}</td>
            <td>{{ trans('common.courses.joined') }}</td>
            <td>
                <div class="togglebutton">
                    <label>
                        <input url={{ url('teacher/courses/' . $course->id . '/active') }} course-student-id="{{ $courseStudent->id }}"
                            class="course-student-active" type="checkbox"
                            {{ $courseStudent->is_active ? 'checked' : '' }} />
                    </label>
                </div>
            </td>
            <td class="break-word">
                @if ($courseStudent->memo)
                    {{ str_limit($courseStudent->memo, $stringLengthLimit) }}
                <br />
                <button id="{{ $courseStudent->id }}"
                    class="student-show-memo btn btn-sm btn-{{ $mainColor }} btn-raised"
                    data-toggle="modal" data-target="#student-memo">
                    {{ trans('common.buttons.edit') }}
                </button>
                @else
                <button id="{{ $courseStudent->id }}"
                    class="student-show-memo btn btn-sm btn-{{ $mainColor }} btn-raised"
                    data-toggle="modal" data-target="#student-memo">
                    {{ trans('common.buttons.add') }}
                </button>
                @endif
            </td>
            @endif
            <div style="display: none;" id="content-{{ $courseStudent->id }}">
                {{ $courseStudent->memo }}
            </div>
        </tr>
        @endforeach
    @endif
    @if (isset($invitionStudents))
        @foreach ($invitionStudents as $invitionStudent)
        <tr>
            <td>{{ $invitionStudent->identity_number }}</td>
            <td>{{ $invitionStudent->full_name }}</td>
            @if (is_teacher_view($moduleName))
            <td>{{ $invitionStudent->email }}</td>
            <td>
                {{ trans('common.courses.waiting') }}
            </td>
            <td>
            </td>
            @endif
        </tr>
        @endforeach
    @endif
    </table>
    @if (is_teacher_view($moduleName))
    <div id="student-memo" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                    <h4 class="modal-title">{{ trans('teachers.courses.memo_content') }}</h4>
                </div>
                <div class="modal-body">
                    {!! Form::open(['action' => $memoAction,
                        'method' => 'POST',
                        'id' => "popup-memo-form",
                        'class' => 'form-horizontal'
                    ]) !!}
                        <div class="form-group">
                            <div class="col-sm-12">
                                {!! Form::hidden('id', '', ['id' => 'student-memo-id']) !!}
                                {!! Form::textarea('memo', '', [
                                    'class' => 'form-control',
                                    'placeholder' => trans('common.courses.content'),
                                    'id' => 'student-memo-content',
                                 ]) !!}
                            </div>
                            <div class="col-sm-12">
                                <button type="submit" id="btnSubmit" class="btn btn-{{ $mainColor }}">
                                    {{ trans('common.buttons.save') }}
                                </button>
                            </div>
                        </div>
                        <div class="alert alert-warning hidden"></div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
    @endif
</div>
