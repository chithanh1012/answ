@if (is_teacher_view($moduleName))
    @include('layouts.includes._errors_list')
    <div class="row">
        {!! Form::open(['action' => ['Teacher\LessonController@generate', $course->id]]) !!}
        <div class="col-md-2">
            {!! Form::text('start_date', '', [
                'class' => 'form-control date-picker margin-top-10',
                'placeholder' => trans('common.lessons.start_date')
            ]) !!}
        </div>
        <div class="col-md-2">
            {!! Form::text('generate_times', '', [
                'class' => 'form-control margin-top-10',
                'placeholder' => trans('teachers.courses.generate_times')
            ]) !!}
        </div>
        <div class="col-md-3">
            <button class="btn btn-no-margin btn-{{ $mainColor }}">
                {{ trans('teachers.courses.auto_generate') }}
            </button>
        </div>
        {!! Form::close() !!}
        <div class="col-md-3 col-md-offset-2">
            <a href="{{ action('Teacher\LessonController@create', $course->id) }}"
               class="btn btn-no-margin btn-{{ $mainColor }}">
                {{ trans('common.lessons.create_lesson') }}
            </a>
        </div>
    </div>
<hr/>
@endif

@if (count($lessons))
    @if (is_student_view($moduleName))
<div class="row">
    <div class="col-md-12 checkbox checkbox-{{ $mainColor }}">
        <label for="show-lessons" id="show-lessons-done">
            <input type="checkbox" name="show_lessons_done" id="show-lessons">
            {{ trans('common.labels.show_lessons_done') }}
        </label>
    </div>
    <hr/>
</div>
    @endif
<div class="form-horizontal common-lessons-list">
    @foreach ($lessons as $key => $lesson)
    <div class="row lesson-item lesson-status-{{ $lesson->getStatus() }}"
        data-href="{{ link_to_lesson($moduleName, $course->id, $lesson->id) }}">
        <div class="col-lg-1">
            @if ($course->nextLesson && $course->nextLesson->id === $lesson->id)
            <div class="lesson-status lesson-status-next">
                {{ trans('common.lessons.status.next') }}
            </div>
            @else
            <div class="lesson-status lesson-status-{{ $lesson->getStatus() }}">
                {{ trans('common.lessons.status.' . $lesson->getStatus()) }}
            </div>
            @endif
        </div>
        <div class="col-lg-2">
            <div>{{ $lesson->start_date->format(config('app.date_time_format')) }}</div>
            <div>{{ $lesson->start_time->format('H:i') }} - {{ $lesson->end_time->format('H:i') }}</div>
        </div>
        <div class="col-lg-2 break-word">
            {{ $lesson->getLocation() }}
        </div>
        <div class="col-lg-{{ is_teacher_view($moduleName) ? 2 : 4 }} break-word lesson-desc">
            {{ str_limit($lesson->desc, config('common.string_length_limit')) }}
        </div>
        <div class="col-lg-{{ is_teacher_view($moduleName) ? 5 : 3 }}">
            <div class="row pull-left">
                <ul class="nav nav-pills col-xs-{{ is_teacher_view($moduleName) ? 4 : 6 }} text-center">
                    <li class="active">
                        <a class="e-resize" href="{{ link_to_lesson($moduleName, $course->id, $lesson->id, 'reports') }}">
                            {{ trans('common.labels.reports') }}
                            <span class="badge {{$lesson->getReportsCount()? '' : 'zero'}}">{{ $lesson->getReportsCount() }}</span>
                        </a>
                    </li>
                </ul>
                <ul class="nav nav-pills col-xs-{{ is_teacher_view($moduleName) ? 4 : 6 }} text-center">
                    <li class="active">
                        <a class="e-resize" href="{{ link_to_lesson($moduleName, $course->id, $lesson->id, 'messages') }}">
                            {{ trans('common.labels.messages') }}
                            <span class="badge {{$lesson->getMessagesCount()? '' : 'zero'}}">{{ $lesson->getMessagesCount() }}</span>
                        </a>
                    </li>
                </ul>
                @if (is_teacher_view($moduleName))
                <ul class="nav nav-pills col-xs-4 text-center">
                    <li class="active">
                        <a class="e-resize" href="{{ link_to_lesson($moduleName, $course->id, $lesson->id, 'students') }}">
                            {{ trans('common.lessons.presences') }}
                            <span class="badge {{$lesson->getParticipantsCount()? '' : 'zero'}}">{{ $lesson->getParticipantsCount() }}</span>
                        </a>
                    </li>
                </ul>
                @endif
            </div>
        </div>
    </div>
    @endforeach
</div>
@else
    <h4>{{ trans('common.messages.courses.no_lesson') }}</h4>
@endif
