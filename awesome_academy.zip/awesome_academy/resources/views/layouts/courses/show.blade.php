@extends('layouts.default', [
    'pageName' => is_teacher_view($moduleName) ? 'js-teacher-course-view' : 'js-student-course-view',
])

@section('main')
<div class="container course-show common-tabbed-show-page">
    @include('layouts.includes._alert_message')
    <div class="panel panel-{{ $mainColor }} panel-basic-info">
        <div class="panel-heading">
            <div class="row">
                <div class="col-xs-9">
                    @if (is_teacher_view($moduleName))
                    <a href="/"
                        class="btn btn-fab btn-fab-mini btn-material-white btn-back"
                        title="{{ trans('common.courses.list_course') }}">
                        <i class="mdi-navigation-arrow-back"></i>
                    </a>
                    @else
                    <a href="/"
                        class="btn btn-fab btn-fab-mini btn-material-white btn-back"
                        title="{{ trans('common.courses.list_course') }}">
                        <i class="mdi-navigation-arrow-back"></i>
                    </a>
                    @endif
                    <h4 class="break-word">{{ $course->name }}</h4>
                </div>
                @if (is_teacher_view($moduleName))
                <div class="col-xs-3">
                    <a href="{{ action('Teacher\CourseController@edit', $course->id) }}"
                       class="btn btn-fab btn-fab-mini btn-material-white btn-edit"
                       title="{{ trans('common.courses.edit_course') }}">
                        <i class="mdi-image-edit"></i>
                    </a>
                </div>
                @endif
            </div>
        </div>
        <div class="panel-body">
            @include('layouts.courses._basic_info')
        </div>
    </div>
    @include('layouts.courses._extra_info')

    @if (is_teacher_view($moduleName))
        @include('layouts.courses._search_student_popup')
    @endif
</div>
@stop

@section('script')
    <script type="text/javascript">
        var currentUrl = "{{ link_to_course($moduleName, $course->id) }}";
        var listLessons  = $.parseJSON('{!! json_encode($listLessons) !!}');
        var baseUrl = "{{ link_to_course($moduleName, $course->id, 'lessons') }}";
    </script>
@endsection
