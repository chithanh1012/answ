<div class="course-info col-md-12">
    <div class="col-md-8">
        <div class="course-desc row">
            <div class="break-word col-xs-12">
                {{ $course->desc }}
            </div>
        </div>
        <div class="course-location row">
            <div class="col-md-4 col-xs-6">
                {{ trans('common.courses.location') }}:
            </div>
            <div class="col-md-8 col-xs-6 break-word">
                {{ $course->location }}
            </div>
        </div>
        <div class="course-time-table row">
            <div class="col-md-4 col-xs-6">
                {{ trans('common.courses.time_table') }}:
            </div>
            <div class="col-md-8 col-xs-6">
                {{ $course->getTimeTable() }}
            </div>
        </div>
        <div class="course-scheduled-lesson row">
            <div class="col-md-4 col-xs-6">
                {{ trans('common.courses.scheduled_lesson') }}:
            </div>
            <div class="col-md-8 col-xs-6">
                {{ $lessons ? $lessons->count() : 0 }}
                {{ ($lessons && $lessons->count() > 1 ) ? trans('common.courses.times') :
                    trans('common.courses.time') }}
            </div>
        </div>
        <div class="course-time row">
            <div class="col-md-4 col-xs-6">
                {{ trans('common.courses.publish') }}:
            </div>
            <div class="col-md-8 col-xs-6">
                {{ $course->publish_started_at->format(config('app.date_time_format')) }} -
                {{ $course->publish_ended_at->format(config('app.date_time_format')) }}
            </div>
        </div>
    @if (!$currentTeacher || $currentTeacher->id != $course->teacher->id)
        <div class="course-teacher row">
            <div class="col-md-4 col-xs-6">
                {{ trans('common.courses.teacher') }}:
            </div>
            <div class="col-md-8 col-xs-6">
                {{ $course->teacher->email }}
            </div>
        </div>
    @endif
    @if ($currentStudent)
        <div class="join-course">
            {!! Form::open(['method' => 'POST', 'class' => 'form-horizontal']) !!}
                <div class="col-md-offset-3">
                @if ($joined)
                    <button class="btn btn-primary disabled" type="button">
                        {{ trans('common.courses.joined') }}
                    </button>
                @elseif ($canJoin)
                    <button class="btn btn-primary">
                        {{ trans('common.courses.join') }}
                    </button>
                @endif
                </div>
            {!! Form::close() !!}
        </div>
    @endif
    </div>
    <div class="col-md-4 col-xs-6">
        @include('layouts.includes.partials._mini_calendar_template')
    </div>
</div>
