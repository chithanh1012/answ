<li>
    <input type="hidden" name="teacher_ids[]" value="{{ $teacher_id or '' }}">
    <input type="hidden" name="status[]" value="{{ $status or '' }}">
    <input type="hidden" name="ids[]" value="{{ $id or '' }}">
    <input type="hidden" name="teacherNames[]" value="{{ $teacherName or '' }}">
    <span class="teacher_name">{{ $teacherName or '' }}</span>
@if (isset($teacher_id) && $teacher_id == $currentTeacher->id)
    [{{ trans('teachers.courses.you') }}]
@else
    [<a href="#" class="btn-remove">{{ trans('common.buttons.delete') }}</a>]
@endif
</li>
