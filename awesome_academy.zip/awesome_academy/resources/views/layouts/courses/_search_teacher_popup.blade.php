<div id="search-teacher" class="modal fade" tabindex="-1" role="dialog">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                <h4 class="modal-title">{{ trans('teachers.courses.search_teacher') }}</h4>
            </div>
            <div class="modal-body">
                {!! Form::open([
                    'data-action' => url('/teacher/search'),
                    'data-method' => 'POST',
                    'id' => 'popup-search-form',
                    'class' => 'form-horizontal'
                ]) !!}
                    <div class="form-group">
                        <input type="hidden" name="course_id" value="{{ $course->id or '' }}">
                        <div class="col-sm-9">
                            {!! Form::text('name', null, [
                                'class' => 'form-control',
                                'placeholder' => trans('teachers.courses.teacher_name')
                            ]) !!}
                        </div>
                        <div class="col-sm-3">
                            <button type="button" id="btnSearch" class="btn btn-{{ $mainColor }}"
                                    data-form-id="#popup-search-form" data-result-table="#result-table">
                                {{ trans('teachers.courses.search') }}
                            </button>
                        </div>
                    </div>
                    <div class="alert alert-warning hidden"></div>
                {!! Form::close() !!}
                <table class="table table-bordered" id="result-table">
                    <thead>
                        <th>#</th>
                        <th>{{ trans('common.labels.fullname') }}</th>
                        <th>{{ trans('teachers.courses.invite') }}</th>
                    </thead>
                    <tbody></tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<div class="hidden" id="assistant-template">
    @include('layouts.courses._course_assistant')
</div>
