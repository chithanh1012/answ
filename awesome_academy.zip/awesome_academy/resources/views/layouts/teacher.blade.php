@extends('layouts.default')

@section('main')
    <div class="container main teacher">
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header text-center">{{ $title or '' }}</h2>
            </div>
        </div>
        <div class="row">
            @yield('main_container')
        </div>
    </div>
@stop
