<div class="view-lesson-tabs">
    <ul class="nav nav-tabs nav-{{ $mainColor }} tab-bar">
        <li class="{{ !$currentTab ? 'active' :  '' }}">
            <a href="#content" class="tab-button" data-toggle="tab"
                data-url="{{
                    action(
                        is_teacher_view($moduleName) ?
                            'Teacher\LessonController@show' :
                            'Student\LessonController@show',
                        [$course->id, $lesson->id]
                    )
                }}">
                {{ trans('common.lessons.content') }}
            </a>
        </li>
        <li class="{{ $currentTab === 'files' ? 'active' :  '' }}">
            <a href="#files" class="tab-button" data-toggle="tab"
                data-url="{{
                    action(
                        is_teacher_view($moduleName) ?
                            'Teacher\LessonController@show' :
                            'Student\LessonController@show',
                        [$course->id, $lesson->id, 'files']
                    )
                }}">
                {{ trans('common.labels.files') }}
                (<b>{{ $lesson->notExpiredMedia->count() }}</b>)
            </a>
        </li>
        @if (is_teacher_view($moduleName))
        <li class="{{ $currentTab === 'students' ? 'active' :  '' }}">
            <a href="#students" class="tab-button" data-toggle="tab"
                data-url="{{
                    action(
                        is_teacher_view($moduleName) ?
                            'Teacher\LessonController@show' :
                            'Student\LessonController@show',
                        [$course->id, $lesson->id, 'students']
                    )
                }}">
                {{ trans('teachers.lessons.attended') }}
                (<b>{{ $lesson->participants->count() }}</b>)
            </a>
        </li>
        @endif
        <li class="{{ $currentTab === 'reports' ? 'active' :  '' }}">
            <a href="#reports" class="tab-button" data-toggle="tab"
                data-url="{{
                    action(
                        is_teacher_view($moduleName) ?
                            'Teacher\LessonController@show' :
                            'Student\LessonController@show',
                        [$course->id, $lesson->id, 'reports']
                    )
                }}">
                {{ trans('common.labels.reports') }}
                (<b>{{ $reports->count() }}</b>)
            </a>
        </li>
        <li class="{{ $currentTab === 'messages' ? 'active' :  '' }}">
            <a href="#messages" class="tab-button" data-toggle="tab"
                data-url="{{
                    action(
                        is_teacher_view($moduleName) ?
                            'Teacher\LessonController@show' :
                            'Student\LessonController@show',
                        [$course->id, $lesson->id, 'messages']
                    )
                }}">
                {{ trans('common.labels.messages') }}
                (<b>{{ $messages->count() }}</b>)
            </a>
        </li>
    </ul>
    <div class="tab-content">
        <div id="content" class="tab-pane fade {{ !$currentTab ? 'active in' :  '' }} markdown clearfix">
            <div class="col-md-12">
                <div class="row">
                    <label class="col-sm-2">{{ trans('common.lessons.location') }}:</label>
                    <div class="col-sm-10 break-word">
                        {{ $lesson->getLocation() }}
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2">{{ trans('common.lessons.date') }}:</label>
                    <div class="col-sm-10 break-word">
                        {{ $lesson->start_date->format('d/m/Y') }}
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2">{{ trans('common.lessons.time') }}:</label>
                    <div class="col-sm-10 break-word">
                        {{ $lesson->start_time->format('H:i') }} -
                        {{ $lesson->end_time->format('H:i') }}
                    </div>
                </div>
                <div class="row">
                    <label class="col-sm-2">{{ trans('common.lessons.description') }}:</label>
                    <div class="col-sm-10 break-word">
                        {{ $lesson->desc }}
                    </div>
                </div>
            </div>
            <hr class="hr-content">
            {!! $lesson->getParsedContent() !!}
        </div>
        <div id="files" class="tab-pane fade {{ $currentTab === 'files' ? 'active in' :  '' }} clearfix">
            @include('layouts.lessons._files_list')
        </div>
        @if (is_teacher_view($moduleName))
        <div id="students" class="tab-pane fade {{ $currentTab === 'students' ? 'active in' :  '' }} clearfix">
            @include('layouts.lessons._students_list')
        </div>
        @endif
        <div id="reports" class="tab-pane fade {{ $currentTab === 'reports' ? 'active in' :  '' }} clearfix">
            @include('layouts.lessons._student_reports_list')
        </div>
        <div id="messages" class="tab-pane fade {{ $currentTab === 'messages' ? 'active in' :  '' }} clearfix">
            @if (is_teacher_view($moduleName))
                @include('layouts.lessons._messages_list')
            @else
                @include('layouts.lessons._student_messages_list')
            @endif
        </div>
    </div>
</div>
