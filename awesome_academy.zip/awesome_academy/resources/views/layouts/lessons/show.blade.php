@extends('layouts.default', ['pageName' => 'js-lesson-detail'])

@section('main')
<div class="container lesson-detail common-tabbed-show-page">
    @include('layouts.includes._alert_message')
    <div class="panel panel-{{ $mainColor }} panel-basic-info">
        <div class="panel-heading">
            <div class="row">
                <div class="col-xs-10">
                    @if (is_teacher_view($moduleName))
                    <a href="{{ action('Teacher\CourseController@show', [$course->id, 'lessons']) }}"
                        class="btn btn-fab btn-fab-mini btn-material-white btn-back"
                        title="{{ trans('common.courses.list_course') }}">
                        <i class="mdi-navigation-arrow-back"></i>
                    </a>
                    @else
                    <a href="{{ action('Student\CourseController@show', [$course->id, 'lessons']) }}"
                        class="btn btn-fab btn-fab-mini btn-material-white btn-back"
                        title="{{ trans('common.courses.list_course') }}">
                        <i class="mdi-navigation-arrow-back"></i>
                    </a>
                    @endif
                    <h4 class="break-word">
                        <a href="javascript:;">
                            {{ $course->name }}
                        </a>
                    </h4>
                </div>
                @if (is_teacher_view($moduleName))
                <a href="{{ action('Teacher\LessonController@edit', [$course->id, $lesson->id]) }}"
                   class="btn btn-fab btn-fab-mini btn-material-white btn-edit"
                   title="{{ trans('common.lessons.edit_lesson') }}">
                    <i class="mdi-image-edit"></i>
                </a>
                @else
                    @if (!$checkStudentAttend && $currentUser->can('check-attendance', $lesson))
                    {!! Form::open(['action' => $attendAction, 'method' => $method, 'class' => 'form-horizontal']) !!}
                        <button class="btn btn-white btn-edit btn-submit"
                           title="{{ trans('students.lessons.attend') }}">
                            {{ trans('students.lessons.attend') }}
                        </button>
                    {!! Form::close() !!}
                    @endif
                    @if ($checkStudentAttend)
                    <button class="btn btn-white btn-edit btn-submit disabled"
                        title="{{ trans('students.lessons.attended') }}">
                        {{ trans('students.lessons.attended') }}
                    </button>
                    @endif
                @endif
            </div>
        </div>
    </div>

    @include('layouts.lessons._extra_info')
</div>
@stop

@section('script')
    <script type="text/javascript">
        var listLessons  = $.parseJSON('{!! json_encode($listLessons) !!}');
        var baseUrl = "{{ link_to_course($moduleName, $course->id, 'lessons') }}";
        var selectedDate = "{{ $lesson->start_date->format('Y-m-d') }}";
    </script>
@endsection
