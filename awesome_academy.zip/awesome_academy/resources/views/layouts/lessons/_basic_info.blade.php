<div class="course-detail">
    <div class="row">
        <div class="col-md-7">
            <div class="row">
                <label class="col-sm-2">{{ trans('common.lessons.location') }}:</label>
                <div class="col-sm-10 break-word">
                    {{ $lesson->getLocation() }}
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2">{{ trans('common.lessons.date') }}:</label>
                <div class="col-sm-10 break-word">
                    {{ $lesson->start_date->format('d/m/Y') }}
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2">{{ trans('common.lessons.time') }}:</label>
                <div class="col-sm-10 break-word">
                    {{ $lesson->start_time->format('H:i') }} -
                    {{ $lesson->end_time->format('H:i') }}
                </div>
            </div>
            <div class="row">
                <label class="col-sm-2">{{ trans('common.lessons.description') }}:</label>
                <div class="col-sm-10 break-word">
                    {{ $lesson->desc }}
                </div>
            </div>
        </div>
        <div class="col-md-5 hidden-xs hidden-sm">
            <div class="pull-right">
                @include('layouts.includes.partials._mini_calendar_template')
            </div>
        </div>
    </div>
</div>
