<div class="tab-files files-list">
@foreach ($lesson->notExpiredMedia as $media)
    <div class="row file-item">
        <div class="col-xs-5 col-file-name truncate-text">
            @if (get_preview_file($media->id))
            <a href="javascript:;" show="{{ action('MediaController@show', $media->id) }}"
                download="{{ action('MediaController@download', $media->id) }}"
                title="{{ $media->file_name }}"
                class="break-word preview-file"
                data-toggle="modal" data-target="#file-preview">
            @else
            <a href="{{ action('MediaController@download', $media->id) }}"
                title="{{ $media->file_name }}">
            @endif
                {{ $media->file_name }}
            </a>
        </div>
        @if ($currentTeacher)
        <div class="col-xs-4 truncate-text">
            <a href="{{ action('MediaController@destroy', $media->id) }}"
               class="btn btn-sm btn-flat btn-danger btn-delete">
                {{ trans('common.buttons.delete') }}
            </a>
        </div>
        @endif
    </div>
@endforeach
</div>

<div id="file-preview" class="modal fade" tabindex="-1" role="document"
    role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <div>
                    <button type="button" class="btn btn-sm btn-{{ $mainColor }} pull-right" data-dismiss="modal"
                        aria-label="{{ trans('common.labels.close') }}">
                        {{ trans('common.labels.close') }}
                    </button>
                    <a href="" type="button" class="download btn btn-sm btn-{{ $mainColor }} pull-right">
                        {{ trans('common.labels.download') }}
                    </a>
                    <h5 class="modal-title"></h5>
                </div>
            </div>
            <hr class="hr"/>
            <div class="modal-body">
                <iframe src=""
                   frameborder="0" allowtransparency="true"
                   height="100%" width="100%" align="center"
                   align="middle" id="iframe-content">
                </iframe>
            </div>
        </div>
    </div>
</div>
