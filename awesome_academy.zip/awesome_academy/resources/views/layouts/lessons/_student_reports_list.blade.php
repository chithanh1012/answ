<div class="report-list cold-md-12">
@foreach ($lesson->reports as $key => $report)
    <div class="report col-md-12">
        <div class="break-word report-name">
            <h4>{{ $report->name }}</h4>
        </div>
        <div class="col-md-12 report-header">
            <div class="col-md-3">
                <span class="blur-text">{{ trans('common.lessons.due_date') }}: </span>
                <span>{{ $report->due_date->format('d/m/Y') }}</span>
            </div>
            <div class="col-md-3">
                <span class="blur-text">{{ trans('common.lessons.format') }}: </span>
                <span>{{ get_report_format_options()[$report->format] }}</span>
            </div>
            <div class="col-md-3">
                <span class="blur-text">{{ trans('common.lessons.last_update') }}: </span>
                <span>{{ $report->updated_at->format('d/m/Y') }}</span>
            </div>
            <div class="col-md-3">
            @if ($currentStudent && $currentStudent->can('submit-report', [$report, $lesson]))
                <a href="{{ url('courses/' . $course->id . '/lessons/' . $lesson->id . '/reports/' . $report->id . '/submit') }}" class="btn btn-sm btn-{{ $mainColor }}">
                    {{ trans('common.buttons.submit') }}
                </a>
            @endif
            </div>
        </div>
        <div class="col-md-12">
        @if ($currentStudent && $currentStudent->isSubmitedReport($report->id))
            <div class="alert alert-dismissable alert-warning">
                {{ trans('students.lessons.messages.already_submit_report') }}: {{ $report->getStudentSubmitedTime($currentStudent->id) }}
            </div>
        @elseif($currentStudent)
            <div class="alert alert-dismissable alert-danger">
            @if (!$lesson->isStarted())
                {{ trans('students.lessons.messages.lesson_isnt_start') }}
            @elseif ($report->isExpired())
                {{ trans('students.lessons.messages.report_expired') }}
            @else
                {{ trans('students.lessons.messages.hasnt_submit_report') }}
            @endif
            </div>
        @endif
        </div>
        <div class="col-md-12 break-word text-justify blur-text">
            {!! nl2br_without_tags($report->desc) !!}
        @if (is_teacher_view($moduleName))
            <a href="{{ action('Teacher\ReportStudentController@show', [$course->id, $lesson->id, $report->id]) }}">[{{ trans('common.buttons.show_report') }}]</a>
        @endif
        </div>
    </div>
    <div class="clearfix"></div>
    @if (count($lesson->reports) - 1 != $key)
    <hr>
    @endif
@endforeach
</div>
<div class="clearfix"></div>
