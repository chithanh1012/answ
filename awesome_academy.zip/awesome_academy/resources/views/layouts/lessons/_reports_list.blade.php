@foreach ($reports as $key => $report)
<div class="report-preview" data-report="{{ $key }}" data-report-id="{{ $report->id }}">
    <label class="report-name break-word" data-name="{{ $report->name }}">{{ $report->name }}</label>
    <div class="row">
        <div class="col-sm-6 report-date" data-due-date="{{ $report->due_date->format('Y-m-d') }}">
            {{ trans('common.labels.due_date') }}:
            {{ $report->due_date->format("d/m/Y") }}
        </div>
        <div class="col-sm-6 report-format" data-format="{{ $report->format }}" data-format-text="{{ get_report_format_options()[$report->format] }}">
            {{ trans('common.labels.format') }}:
            {{ get_report_format_options()[$report->format] }}
        </div>
    </div>
    <div class="report-desc break-word" data-desc="{{ $report->desc }}">{!! nl2br_without_tags($report->desc) !!}</div>
    <div class="row">
        <div class="col-xs-12">
            <div class="pull-right">
                <button type="button" class="btn btn-rise btn-sm btn-success"
                    data-action="update" data-report="{{ $key }}">
                    {{ trans('common.buttons.update') }}
                </button>
                <button type="button" class="btn btn-rise btn-sm btn-danger"
                    data-action="delete" data-report="{{ $key }}">
                    {{ trans('common.buttons.delete') }}
                </button>
            </div>
        </div>
    </div>
</div>
@endforeach

