<div id="messages" class="">
    <div class="message-list">
        @include('layouts.includes._alert_message')
        @include('layouts.includes._errors_list')
        <div class="col-md-12">
            @if ($messages->count())
            <div class="checkbox">
                <label for="hide-replied-message">
                    <input type="checkbox" name="hide_replied_message" id="hide-replied-message"> {{ trans('common.labels.hide_replied_message') }}
                </label>
            </div>
            <h4>{{ trans('common.labels.student') }}</h4>
            @endif
        </div>
        @foreach ($messages as $key => $message)
            @if ($currentTeacher && $message->teacher_id == $currentTeacher->id)
        <div class="row {{ $message->repliedMessage ? 'message-replied' : '' }}" id="msg-{{ $message->id }}">
            <div class="col-md-2 text-center">
                <label class="control-label">{{ $message->student_id }}</label> <br />
                <label class="control-label full_name">{{ $message->student->full_name }}</label>
            </div>
            <div class="col-md-10">
                @if ($message->repliedMessage)
                <button class="btn btn-{{ $mainColor }} btn-raised disabled">{{ trans('common.labels.replied')}}</button>
                @endif
                <div class="msg-send" id="msg-send-{{ $message->id }}">
                    <div class="text-right send-date">
                        <span>{{ trans('common.labels.send_date') }}</span>
                        <label class="control-label">{{ $message->created_at->format('d/m/Y H:i') }}</label>
                    </div>
                    <div class="break-word">
                        <div class="more">
                            {!! str_limit($message->getParsedContent(), $stringLengthLimit) !!}
                            @if (strlen($message->getParsedContent()) > $stringLengthLimit)
                            <a class="morelink" href="javascript:;">{{ trans('common.labels.more') }}</a>
                            @endif
                        </div>
                        <div class="less">
                            {!! $message->getParsedContent() !!}
                            <a class="lesslink" href="javascript:;">{{ trans('common.labels.close') }}</a>
                        </div>
                    </div>
                </div>
                @if ($message->repliedMessage)
                <div class="msg-replied" id="msg-replied-{{ $message->id }}">
                    <div class="text-right replied-date">
                        <span>{{ trans('common.labels.replied_date') }}</span>
                        <label class="control-label">{{ $message->repliedMessage->created_at ? $message->repliedMessage->created_at->format('d/m/Y H:i') : '' }}</label>
                    </div>
                    <div class="break-word">
                        <div class="more">
                            {!! str_limit($message->repliedMessage->getParsedContent(), $stringLengthLimit) !!}
                            @if (strlen($message->repliedMessage->getParsedContent()) > $stringLengthLimit)
                            <a class="morelink" href="javascript:;">{{ trans('common.labels.more') }}</a>
                            @endif
                        </div>
                        <div class="less">
                            {!! $message->repliedMessage->getParsedContent() !!}
                            <a class="lesslink" href="javascript:;">{{ trans('common.labels.close') }}</a>
                        </div>
                    </div>
                </div>
                @endif
                @if ($currentTeacher && !$message->repliedMessage && $allowReply)
                <button class="btn btn-{{ $mainColor }} btn-raised btn-reply" id="msg-reply-{{ $message->id }}">{{ trans('common.labels.reply_message')}}</button>
                <div class="comment-reply"  id="show-msg-reply-{{ $message->id }}">
                    {!! Form::open(['action' => $action, 'method' => $method, 'class' => 'form-horizontal comment-form']) !!}
                        {!! Form::hidden('reply_to', $message->id) !!}
                     <div class="form-group reply-content">
                        <div class="col-sm-12 content-msg">
                            {!! Form::textarea('content', '', [
                                'class' => 'form-control',
                                'rows' => 5,
                                'cols' => 30,
                                'placeholder' => trans('common.labels.content'),
                                'required' => 'required'
                            ]) !!}
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-sm-12">
                            <button class="btn btn-{{ $mainColor }} btn-raised">{{ trans('common.labels.send_btn') }}</button>
                        </div>
                    </div>
                    {!! Form::close() !!}
                </div>
                @endif
                <hr />
           </div>
        </div>
            @endif
        @endforeach
    </div>
</div>
