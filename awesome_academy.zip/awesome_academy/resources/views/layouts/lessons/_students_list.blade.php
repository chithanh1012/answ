<table class="table table-bordered">
    <thead>
        <th>#</th>
        <th>{{ trans('common.labels.fullname') }}</th>
        <th>{{ trans('teachers.lessons.ip') }}</th>
        <th>{{ trans('teachers.lessons.agent') }}</th>
        <th>{{ trans('teachers.lessons.attended_time') }}</th>
    </thead>
    <tbody>
    @foreach ($students as $student)
        <tr class="{{ isset($student['attendedInfo']) ? 'success' : 'no-attend' }}">
            <td>{{ $student['identity_number'] }}</td>
            <td>{{ $student['full_name'] }}</td>
        @if (isset($student['attendedInfo']))
            <td>{{ $student['attendedInfo']['ip_address'] }}</td>
            <td>{{ $student['attendedInfo']['user_agent'] }}</td>
            <td>{{ $student['attendedInfo']['created_at'] }}</td>
        @else
            <td></td>
            <td></td>
            <td></td>
        @endif
        </tr>
    @endforeach
    </tbody>
</table>
