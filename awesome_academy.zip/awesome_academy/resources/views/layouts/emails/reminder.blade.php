@extends('layouts.emails')

@section('main')
<table class="table table-mail" style="width: 100%;margin-top: 10px;background-color: #FFFFFF;">
    <tr>
        <td align="center" style="padding: 0px">
            <table class="table" bgcolor="#ffffff" style="width: 100%">
                <tr>
                    <td align="left" class="logo" style="padding: 16px 16px 40px 16px;background-color: {{ get_main_color_email($isTeacher) }}; color: #FFFFFF;">
                        <h2>
                            Awesome Academy
                            <span style="font-weight: lighter;">{{ $isTeacher ? 'teacher' : 'student' }}</span>
                        </h2>
                        <h1 style="text-align: center;">Today's Lesson!</h1>
                        <h2 style="text-align: center;font-weight: normal;">
                            ({{ $lesson->start_date->format(config('app.date_time_format')) }})
                        </h2>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <h3 style="background-color: {{ get_main_color_email($isTeacher) }};color: #FFFFFF;padding: 13px;margin: 10px;font-weight: normal;">
                            {{ $lesson->course->name }}
                        </h3>
                    </td>
                </tr>
                <tr>
                    <td>
                        <p style="padding: 10px;margin: 5px 15px 5px 15px;font-weight: normal;font-size: 18px;text-align: justify;">
                            {{ $lesson->course->desc }}
                        </p>
                    </td>
                </tr>
                <tr>
                    <td><hr style="border: 1px solid #E0E0E0;margin-left: 10px;margin-right: 10px;"/></td>
                </tr>
                <tr>
                    <td class="box">
                        <table class="table" style="width:100%;font-size: 18px;padding: 25px;">
                            <tr>
                                <td width="20%" style="padding:7px 0">
                                    {{ trans('common.courses.location') }}:
                                </td>
                                <td width="80%" style="padding:7px 0;color: {{ get_main_color_email($isTeacher) }};">
                                    {{ $lesson->getLocation() }}
                                </td>
                            </tr>
                            <tr>
                                <td width="20%" style="padding:7px 0;">
                                    {{ trans('common.courses.time_table')}}:
                                </td>
                                <td width="80%" style="padding:7px 0;color: {{ get_main_color_email($isTeacher) }};">
                                    {{ $lesson->start_time->format('H:i') }} - {{ $lesson->end_time->format('H:i') }}
                                </td>
                            </tr>
                            <tr>
                                <td width="20%" style="padding:7px 0;vertical-align: top;">
                                    {{ trans('common.courses.description') }}:
                                </td>
                                <td width="80%" style="padding:7px 0;color: {{ get_main_color_email($isTeacher) }};">
                                    {{ $lesson->desc }}
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            <tr>
                <td class="space_footer" style="padding:0!important">&nbsp;</td>
            </tr>
            <tr>
                <td class="box">
                    <table class="table" style="width:100%">
                        <tr>
                            <td align="center">
                                <a style="text-decoration: none;color: #ffffff;"
                                @if ($isTeacher)
                                    href="{{ url('teacher/courses/' . $lesson->course->id . '/lessons/' . $lesson->id) }}"
                                @else
                                    href="{{ url('courses/' . $lesson->course->id . '/lessons/' . $lesson->id) }}"
                                @endif
                                >
                                    <h2 style="margin: 0 55px 20px;padding: 40px;background-color:#424242;color:#ffffff;font-weight: normal;">
                                        {{ trans('common.labels.read_more') }}
                                    </h2>
                                </a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td class="footer" style="text-align: center;padding:7px 0;color: #BDBDBD;">
                    <span>
                        <h3>{{ trans('common.labels.copy_right') }}</h3>
                    </span>
                </td>
            </tr>
        </table>
    </tr>
</table>
@endsection
