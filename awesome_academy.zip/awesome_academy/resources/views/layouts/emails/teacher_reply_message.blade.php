Dear you,
<br />
Teacher has been replied to a message for you.
<br />
Content: {!! nl2br_without_tags($data['content']) !!}
<br />
Please click link bellow to view detail:
<br />
@if ($data['lessonId'])
<a href="{{ url('courses/' . $data['course']->id . '/lessons/' . $data['lessonId'] . '/messages') }}#msg-send-{{ $data['messageId'] }}">
    {{ trans('common.buttons.view') }}
</a>
@else
<a href="{{ url('courses/' . $data['course']->id . '/messages') }}#msg-send-{{ $data['messageId'] }}">
    {{ trans('common.buttons.view') }}
</a>
@endif
