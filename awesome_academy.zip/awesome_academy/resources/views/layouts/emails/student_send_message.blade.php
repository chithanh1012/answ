Dear teacher,
<br />
Student have sent a message to you.
<br />
Content: {!! nl2br_without_tags($data['content']) !!}
<br />
Please click link bellow to view detail:
<br />
@if ($data['lessonId'])
<a href="{{ url('teacher/courses/' . $data['courseId'] . '/lessons/' . $data['lessonId'] . '/messages') }}">
    {{ trans('common.buttons.view') }}
</a>
@else
<a href="{{ url('teacher/courses/' . $data['courseId'] . '/messages') }}">
    {{ trans('common.buttons.view') }}
</a>
@endif
