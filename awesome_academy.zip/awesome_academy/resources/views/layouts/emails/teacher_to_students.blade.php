@extends('layouts.emails')

@section('main')
<table class="table table-mail" style="width: 100%;margin-top: 10px;background-color: #FFFFFF;">
    <tr>
        <td align="center" style="padding: 0px">
            <table class="table" bgcolor="#ffffff" style="width: 100%">
                <tr>
                    <td align="left" class="logo" style="padding: 16px 16px 40px 16px;background-color: #009688; color: #FFFFFF;">
                        <h2>
                            Awesome Academy
                            <span style="font-weight: lighter;">student</span>
                        </h2>
                        <br />
                        <h2 style="text-align: center;font-weight: normal;">Notification about lesson</h2>
                    </td>
                </tr>
                <tr>
                    <td align="left">
                        <br />
                        <h3 style="padding: 13px;margin: 10px;font-weight: normal;">
                            Dear All with joined <b>"{{ $data['course']['name'] }}"</b>
                        </h3>
                        <h2 style="color: #009688;padding: 13px;margin: 10px;"
                            onmouseover='this.style.boxShadow="0 5px 11px 0 #424242, 0 4px 15px 0 #424242"'
                            onmouseout='this.style.boxShadow="none"'>
                            <span>{{ $data['title'] }}</span>
                        </h2>
                    </td>
                </tr>
                <tr>
                    <td><hr style="border: 1px solid #E0E0E0;margin-left: 10px;margin-right: 10px;"/></td>
                </tr>
                <tr>
                    <td class="box">
                        <table class="table" style="width:100%;font-size: 18px;padding: 25px;">
                            <tr>
                                <td>
                                {!! nl2br_without_tags($data['content']) !!}
                                </td>
                            </tr>
                        </table>
                    </td>
                </tr>
            <tr>
                <td class="space_footer" style="padding:0!important">&nbsp;</td>
            </tr>
            <tr>
                <td class="box">
                    <table class="table" style="width:100%">
                        <tr>
                            <td align="center">
                                <a style="text-decoration: none;color: #ffffff;"
                                    href="{{ url('courses/' . $data['course']['id'] . '/teachermessages') }}">
                                    <h2 style="margin: 0 55px 20px;padding: 40px;background-color:#424242;color:#ffffff;font-weight: normal;">
                                        {{ trans('common.labels.read_more') }}
                                    </h2>
                                </a>
                            </td>
                        </tr>
                        <tr>
                            <td align="left">
                                <h3 style="background-color: #009688;color: #FFFFFF;padding: 13px;margin: 10px;font-weight: normal;">
                                    {{ $data['course']['name'] }}
                                </h3>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <p style="padding: 10px;margin: 5px 15px 5px 15px;font-weight: normal;font-size: 18px;text-align: justify;">
                                    {{ $data['course']['desc'] }}
                                </p>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr>
                <td class="footer" style="text-align: center;padding: 20px 0 7px;color: #BDBDBD;margin-top: 20px;">
                    <span>
                        <h3>&copy; Framgia, Inc. All Rights Reserved.</h3>
                    </span>
                </td>
            </tr>
        </table>
    </tr>
</table>
@endsection
