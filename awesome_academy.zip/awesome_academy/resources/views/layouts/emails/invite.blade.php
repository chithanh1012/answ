You got an invite to join <b> <a href="{{ url('/courses/' . $course->id) }}">{{ $course->name }}</a></b><br>
Please use link bellow to join this course:<br>
<a href="{{ url('/courses/' . $course->id . '/join/' . $code) }}">{{ url('/courses/' . $course->id . '/join/' . $code) }}</a>
