<div class="panel-body">
    @include('layouts.includes._errors_list')
    <form class="form-horizontal" role="form" method="POST" action="{{ $action }}" novalidate="novalidate">
        <input type="hidden" name="_token" value="{{ csrf_token() }}">

        <div class="form-group">
            <label class="col-md-4 control-label">{{ trans('common.labels.email') }}</label>
            <div class="col-md-7">
                <input class="form-control" name="email" value="{{ old('email') }}" placeholder="Email">
            </div>
        </div>

        <div class="form-group">
            <label class="col-md-4 control-label">{{ trans('common.labels.password') }}</label>
            <div class="col-md-7">
                <input type="password" class="form-control" name="password" placeholder="Password">
            </div>
        </div>

        @if ($type == 'teacher')
        <div class="form-group">
            <label class="col-md-7 col-md-offset-4">
                <a href="{{ url('teacher/password/email') }}">{{ trans('common.labels.forgot_password') }}</a>
            </label>
        </div>
        @endif

        <div class="form-group">
            <div class="col-md-7 col-md-offset-4">
                <button type="submit" class="btn btn-{{ $mainColor }}">{{ trans('common.buttons.login') }}</button>
            </div>
        </div>
    </form>
</div>
