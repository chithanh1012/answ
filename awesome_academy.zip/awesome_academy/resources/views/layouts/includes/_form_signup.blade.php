<div class="panel-body">
    @include('layouts.includes._errors_list')
    {!! Form::open(['class' => 'form-horizontal']) !!}
        <div class="form-group">
            <label class="col-md-4 control-label">
                {{ trans('common.labels.fullname') }} <span class="required">*</span>
            </label>
            <div class="col-md-7">
                {!! Form::text('full_name', null, [
                    'class' => 'form-control',
                    'placeholder' => trans('common.labels.fullname'),
                ]) !!}
            </div>
        </div>
        @if (is_student_view($moduleName))
        <div class="form-group">
            <label class="col-md-4 control-label">
                {{ trans('common.labels.identity_number') }} <span class="required">*</span>
            </label>
            <div class="col-md-7">
                {!! Form::text('identity_number', null, [
                    'class' => 'form-control',
                    'placeholder' => trans('common.labels.identity_number'),
                ]) !!}
            </div>
        </div>
        @endif
        <div class="form-group">
            <label class="col-md-4 control-label">
                {{ trans('common.labels.email') }} <span class="required">*</span>
            </label>
            <div class="col-md-7">
                {!! Form::email('email', null, [
                    'class' => 'form-control',
                    'placeholder' => trans('common.labels.email'),
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-4 control-label">
                {{ trans('common.labels.password') }} <span class="required">*</span>
            </label>
            <div class="col-md-7">
                {!! Form::password('password', [
                    'class' => 'form-control',
                    'placeholder' => trans('common.labels.password'),
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <label class="col-md-4 control-label">
                {{ trans('common.labels.confirm_password') }} <span class="required">*</span>
            </label>
            <div class="col-md-7">
                {!! Form::password('password_confirmation', [
                    'class' => 'form-control',
                    'placeholder' => trans('common.labels.password'),
                ]) !!}
            </div>
        </div>
        <div class="form-group">
            <div class="col-md-7 col-md-offset-4">
                <button type="submit" class="btn btn-{{ $mainColor }}">
                    {{ trans('common.buttons.signup') }}
                </button>
            </div>
        </div>
    {!! Form::close() !!}
</div>
