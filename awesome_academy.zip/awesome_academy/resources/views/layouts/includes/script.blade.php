<script type="text/javascript" src="{{ elixir('js/all.js') }}"></script>
@yield('script')
