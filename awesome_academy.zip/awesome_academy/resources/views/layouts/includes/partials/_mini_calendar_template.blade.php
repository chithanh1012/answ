<div id="calendar" class="mini-clndr clearfix shadow-z-2 calendar-{{ $mainColor }}"></div>
<script id="mini-clndr-template" type="text/template">
    <div class="controls">
        <div class="clndr-previous-button">&lsaquo;</div><div class="month"><%= month %></div><div class="clndr-next-button">&rsaquo;</div>
    </div>
    <div class="days-container">
        <div class="days">
            <div class="headers">
                <% _.each(daysOfTheWeek, function(day) { %><div class="day-header"><%= day %></div><% }); %>
            </div>
            <% _.each(days, function(day) { %><div class="<%= day.classes %>" id="<%= day.id %>"><%= day.day %></div><% }); %>
        </div>
    </div>
    <div class="events hidden">
        <div class="events-list">
            <% _.each(eventsThisMonth, function(event) { %>
            <div class="event" data-date="<%= event.date %>" data-url="<%= event.url %>"></div>
            <% }); %>
        </div>
    </div>
</script>
