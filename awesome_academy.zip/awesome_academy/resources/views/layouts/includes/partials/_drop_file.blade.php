<div id="attach-document" class="form-group">
    <div id="media-list">
        @if (old('media_id'))
            @for ($i = 0; $i < count(old('media_id')); $i++)
                @include('layouts.includes.partials._media_item', [
                    'mediaId'           => old('media_id')[$i],
                    'mediaStatus'       => old('media_status')[$i],
                    'mediaName'         => old('media_name')[$i],
                    'mediaExpiredDate'  => old('media_expired_date')[$i],
                ])
            @endfor
        @elseif (isset($medium))
            @foreach ($medium as $media)
                @include('layouts.includes.partials._media_item', [
                    'mediaId'           => $media->id,
                    'mediaName'         => $media->file_name,
                    'mediaExpiredDate'  => $media->expired_date->timestamp > 0 ?
                                           $media->expired_date->format('Y-m-d') : '',
                ])
            @endforeach
        @endif
    </div>
    <div id="drop-zone">
        {{ trans('common.labels.drop_your_files') }}
    </div>
</div>
