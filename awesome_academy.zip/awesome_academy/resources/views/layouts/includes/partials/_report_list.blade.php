<div class="report-list col-md-12">
@foreach ($reports as $key => $report)
    <div class="report col-md-12">
        <div class="break-word report-name">
            <h4>{{ $report->name }}</h4>
        </div>
        <div class="col-md-12 report-header">
            <div class="col-md-4">
                <span class="blur-text">{{ trans('common.lessons.due_date') }}: </span>
                <span>{{ $report->due_date->format('d/m/Y') }}</span>
            </div>
            <div class="col-md-4">
                <span class="blur-text">{{ trans('common.lessons.format') }}: </span>
                <span>{{ get_report_format_options()[$report->format] }}</span>
            </div>
            <div class="col-md-4">
                <span class="blur-text">{{ trans('common.lessons.last_update') }}: </span>
                <span>{{ $report->updated_at->format('d/m/Y') }}</span>
            </div>
        </div>
        <div class="col-md-12 break-word text-justify blur-text">
            {!! nl2br_without_tags($report->desc) !!}
        </div>
    </div>
    <div class="clearfix"></div>
    @if (count($reports) - 1 != $key)
    <hr>
    @endif
@endforeach
</div>
<div class="clearfix"></div>
