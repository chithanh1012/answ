<div class="form-group media-item {{ isset($mediaStatus) && $mediaStatus === 'removed' ? 'hidden' : '' }}">
    <input type="hidden" name="media_id[]" value="{{ $mediaId or '' }}" />
    <input type="hidden" name="media_status[]" value="{{ $mediaStatus or '' }}" />
    <input type="hidden" name="media_name[]" value="{{ $mediaName or '' }}" />

    @if (!empty($withExpiredDate))
    <div class="col-md-6 truncate-text">
        <a class="media-link" href="/media/download/{{ $mediaId or '' }}" title="{{ $mediaName or '' }}">
            {{ $mediaName or '' }}
        </a>
    </div>
    <div class="col-md-6">
        <div class="row">
            <div class="col-xs-6">
                <input type="text" name="media_expired_date[]"
                    value = "{{ isset($mediaExpiredDate) ? $mediaExpiredDate : '' }}"
                    class="form-control date-picker margin-top-10"
                    placeholder="{{ trans('common.labels.expired_date') }}" />
            </div>
            <div class="col-xs-6">
                <a class="btn btn-danger btn-flat media-delete">{{ trans('common.labels.delete') }}</a>
            </div>
        </div>
    </div>
    @else
    <div class="col-xs-8 truncate-text">
        <a class="media-link" href="/media/download/{{ $mediaId or '' }}" title="{{ $mediaName or '' }}">
            {{ $mediaName or '' }}
        </a>
    </div>
        <div class="col-xs-4">
            <a class="btn btn-danger btn-flat media-delete">{{ trans('common.labels.delete') }}</a>
        </div>
    @endif
</div>
