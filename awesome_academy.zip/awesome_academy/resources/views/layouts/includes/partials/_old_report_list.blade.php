@for ($i = 0; $i < count($reports['name']); $i ++)
<div class="col-sm-12 report-preview" data-report="{{ $i }}">
    <div class="break-word">
        <label class="report-name" data-name="{{ $reports['name'][$i] }}">{{ $reports['name'][$i] }}</label>
    </div>
    <div class="row">
        <div class="col-sm-6 report-date" data-due-date="{{ $reports['due_date'][$i] }}">
            Due date: {{ $reports['due_date'][$i] }}
        </div>
        <div class="col-sm-6 report-format" data-format="{{ $reports['format'][$i] }}" data-format-text="{{ get_report_format_options()[$reports['format'][$i]] }}">
            Format: {{ get_report_format_options()[$reports['format'][$i]] }}
        </div>
    </div>
    <div class="report-desc break-word" data-desc="{{ $reports['desc'][$i] }}">{{ $reports['desc'][$i] }}</div>
    <div class="lesson-action pull-right">
        <button type="button" class="btn btn-rise btn-sm btn-success" data-action="update" data-report="{{ $i }}">Update</button>
        <button type="button" class="btn btn-rise btn-sm btn-danger" data-action="delete" data-report="{{ $i }}">Delete</button>
    </div>
</div>
@endfor
