<div id="create-report-modal" class="modal fade" tabindex="-1" role="dialog" >
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                <h4 class="modal-title">{{ trans('teachers.lessons.add_report') }}</h4>
            </div>
            <div class="modal-body report-form">
                <div class="report-name">
                    <input type="text" name="reports[name][]" class="form-control" placeholder="{{ trans('common.lessons.report') }}" value="" maxlength="255">
                </div>
                <div>
                    <div class="col-md-6 sm-input">
                        <label class="col-md-4 control-label">{{ trans('common.lessons.due_date') }}:</label>
                        <div class="col-md-8 report-date">
                            <input type="text" name="reports[due_date][]" class="form-control date-picker" placeholder="{{ trans('common.lessons.due_date') }}">
                        </div>
                    </div>
                    <div class="col-md-6 sm-input">
                        <label class="col-md-4 control-label">{{ trans('common.lessons.format') }}</label>
                        <div class="col-md-8">
                            <select class="form-control" name="reports[format][]">
                            @foreach (get_report_format_options() as $key => $option)
                                <option value="{{ $key }}">{{ $option }}</option>
                            @endforeach
                            </select>
                        </div>
                    </div>
                </div>
                <div>
                    <div class="col-md-12 sm-input">
                        <textarea class="form-control" rows="5" placeholder="Content"></textarea>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
            @if ($isEditPage)
                <button class="btn btn-rise btn-{{ $mainColor }} btn-save" data-dismiss="modal">
                    {{ trans('common.buttons.save') }}
                </button>
            @else
                <button class="btn btn-rise btn-{{ $mainColor }} btn-done" data-dismiss="modal">
                    {{ trans('common.buttons.done') }}
                </button>
            @endif
            </div>
        </div>
    </div>
</div>
