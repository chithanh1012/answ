<div class="row course-detail">
    <div class="col-md-8">
        <h1>{{ $course->name }}</h1>
        <div class="blur-text text-justify markdown">
            {!! $course->getParsedContent() !!}
        </div>
    </div>
    <div class="col-md-4">
        @include('layouts.includes.partials._mini_calendar_template')
    </div>
    <div class="col-md-12">
        <div class="col-md-4">
            <span class="blur-text">{{ trans('common.lessons.date') }}:</span>
            <span class="big-text">{{ $lesson->start_date->format('d/m/Y') }}</span>
        </div>
        <div class="col-md-4">
            <span class="blur-text">{{ trans('common.lessons.time') }}:</span>
            <span class="big-text orange-text">
                {{ $lesson->start_time->format('H:i') }} -
                {{ $lesson->end_time->format('H:i') }}
            </span>
        </div>
        <div class="col-md-4">
            <span class="blur-text">{{ trans('common.lessons.location') }}: </span>
            <span class="big-text orange-text">{{ $course->location }}</span>
        </div>
    </div>
</div>
