<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<meta name="description" content="">
<meta name="_token" content="{{ csrf_token() }}">
<title>{{ isset($title) ? $title . ' :: ' : '' }} Awesome Academy {{ $moduleName or '' }} {{ get_env_title() }}</title>
<link rel="stylesheet" href="{{ elixir('css/all.css') }}">
@yield('css')
