<!DOCTYPE html>
<!--[if IE 9]><html class="lt-ie10" lang="en" > <![endif]-->
<html lang="en">
<head>
    @include('layouts.includes.head')
    <script>
      (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
      (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
      m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
      })(window,document,'script','//www.google-analytics.com/analytics.js','ga');

      ga('create', '{{ env('GOOGLE_ANALYTICS_ID') }}', 'auto');
      ga('send', 'pageview');

    </script>
</head>
<body id="auth" class="{{ $moduleName }}">
    @if (!empty($pageName))
        @include('layouts.includes._page_js_name', ['pageName' => $pageName])
    @endif
    <nav class="navbar navbar-white">
        <div class="navbar-header">
            <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                <span class="sr-only">Toggle Navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <a class="navbar-brand" href="{{ $modulePath }}">
                <img src="/img/logo.png" title="Awesome Academy {{ ucfirst($moduleName) }}"/>
                <span class="title">{{ get_env_title() }}</span>
            </a>
        </div>

        <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
            <ul class="nav navbar-nav navbar-right">
            @if ($currentUser)
                <li>
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                        {{ $currentUser->full_name }}
                        <span class="caret"></span>
                    </a>
                    <ul class="dropdown-menu">
                        @if (is_teacher_view($moduleName))
                        <li>
                            <a href="{{ url($modulePath . 'change-password') }}">
                                {{ trans('common.labels.change_password') }}
                            </a>
                        </li>
                        <li>
                            <a href="{{ url($modulePath . 'update-profile') }}">
                                {{ trans('common.labels.update_profile') }}
                            </a>
                        </li>
                        @endif
                    </ul>
                </li>
                <li>
                    <a href="{{ url($currentUser->getModulePath() . 'logout') }}">
                        {{ trans('common.labels.logout') }}
                    </a>
                </li>
            @else
                @if (is_student_view($moduleName))
                <li>
                    <a href="{{ get_login_uri() }}">{{ trans('common.buttons.login') }}</a>
                </li>
                    @if (get_signup($moduleName))
                <li>
                    <a href="{{ env('AA_SERVER_URL') . 'signup?redirect_uri=' . env('AA_REDIRECT_URI') }}">
                        {{ trans('common.labels.signup') }}
                    </a>
                </li>
                    @endif
                @else
                <li>
                    <a href="{{ url($modulePath . 'login') }}">{{ trans('common.buttons.login') }}</a>
                </li>
                    @if (get_signup($moduleName))
                <li>
                    <a href="{{ url($modulePath . 'signup') }}">{{ trans('common.labels.signup') }}</a>
                </li>
                    @endif
                @endif
            @endif
            </ul>
        </div>
    </nav>

    <div class="{{ $moduleName }}">
        <div class="container-fluid auth-page">
            <div class="row">
                @if (is_student_view($moduleName))
                <div class="col-lg-3 col-lg-push-9 main-form">
                    @yield('main')
                </div>
                <div class="col-lg-9 col-lg-pull-3 main-photo">
                    <img class="img" src="/img/{{ $moduleName }}_obj.png" />
                </div>
                @else
                <div class="col-lg-5 col-lg-push-7 main-form">
                    @yield('main')
                </div>
                <div class="col-lg-7 col-lg-pull-5 main-photo">
                    <img class="img" src="/img/{{ $moduleName }}_obj.png" />
                </div>
                @endif
            </div>
        </div>
    </div>
    @include('layouts.includes.script')
</body>
</html>
