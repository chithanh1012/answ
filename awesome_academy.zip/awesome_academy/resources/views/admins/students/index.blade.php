@extends('layouts.default')

@section('main')
<div class="container">
    <table class="table table-striped table-hover ">
        <thead>
            <tr>
                <th>#</th>
                <th>{{ trans('common.labels.fullname') }}</th>
                <th>{{ trans('common.labels.email') }}</th>
                <th>{{ trans('common.labels.birthday') }}</th>
                <th>{{ trans('common.labels.gender') }}</th>
            </tr>
        </thead>
        <tbody>
        @foreach ($students as $student)
            <tr>
                <td>{{ $student->id }}</td>
                <td>{{ $student->full_name }}</td>
                <td>{{ $student->email }}</td>
                <td>{{ $student->birthday }}</td>
                <td>{{ $gender[$student->gender] }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    {!! $students->render() !!}
</div>
@stop
