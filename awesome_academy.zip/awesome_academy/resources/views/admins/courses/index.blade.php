@extends('layouts.default')

@section('main')
<div class="container admin-course-list">
    <table class="table table-striped table-hover ">
        <thead>
            <tr>
                <th class="admin-course-id">#</th>
                <th class="admin-course-name">{{ trans('common.courses.name') }}</th>
                <th class="admin-course-desc">{{ trans('common.courses.description') }}</th>
                <th>{{ trans('common.courses.location') }}</th>
                <th>{{ trans('common.courses.student_number') }}</th>
                <th>{{ trans('common.courses.period') }}</th>
            </tr>
        </thead>
        <tbody>
        @foreach ($courses as $course)
            <tr>
                <td>{{ $course->id }}</td>
                <td>{{ $course->name }}</td>
                <td>{{ str_limit($course->desc, $limit = 200, $end = '...') }}</td>
                <td>{{ $course->location }}</td>
                <td>{{ $course->students->count() }} {{ $course->max_students ? '/ ' . $course->max_students : ''}}</td>
                <td>{{ $course->start_date->format(config('app.date_time_format')) }} - {{ $course->end_date->format(config('app.date_time_format')) }}</td>
            </tr>
        @endforeach
        </tbody>
    </table>
    {!! $courses->render() !!}
</div>
@stop
