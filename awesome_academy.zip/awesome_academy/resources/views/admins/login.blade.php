@extends('layouts.default', ['noMenus' => true])

@section('main')
<div class="container-fluid login-page">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Admin Login</div>
                @include('layouts.includes._form_login', ['action' => url('/admin/login'), 'type' => 'admin'])
            </div>
        </div>
    </div>
</div>
@endsection
