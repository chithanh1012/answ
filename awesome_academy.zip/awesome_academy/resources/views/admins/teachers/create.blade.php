@extends('layouts.default')

@section('main')
<div class="container create-list">
    <div class="panel panel-default">
        <div class="panel-heading panel-custom">
            <h4>{{ trans('common.labels.create_teacher') }}</h4>
        </div>
        <div class="panel-body">
            @include('layouts.includes._errors_list')
            {!! Form::open(['class' => 'form-horizontal', 'action' => $action]) !!}
                <div class="form-group">
                    <label class="col-md-4 control-label required">
                        {{ trans('common.labels.fullname') }}
                    </label>
                    <div class="col-md-6" >
                        {!! Form::text('full_name', null, [
                            'class' => 'form-control',
                            'placeholder' => trans('common.labels.fullname'),
                        ]) !!}
                    </div>
                </div>
                <div class="form-group">
                    <label class="col-md-4 control-label required">
                        {{ trans('common.labels.email') }}
                    </label>
                    <div class="col-md-6">
                        {!! Form::email('email', null, [
                            'class' => 'form-control',
                            'placeholder' => trans('common.labels.email'),
                        ]) !!}
                    </div>
                </div>
                <div class="form-group">
                    <div class="col-md-6 col-md-offset-4">
                        <button type="submit" class="btn btn-{{ $mainColor }}">
                            {{ trans('common.buttons.create') }}
                        </button>
                        <a href="{{ url('admin/teachers') }}" class="btn btn-back btn-raised">
                            {{ trans('common.buttons.back') }}
                        </a>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
</div>
@endsection
