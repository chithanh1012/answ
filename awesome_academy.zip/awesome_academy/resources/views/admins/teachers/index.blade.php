@extends('layouts.default')

@section('main')
<div class="container">
    @include('layouts.includes._alert_message')
    <div class="panel panel-default">
        <div class="panel-body">
            @include('layouts.includes._errors_list')
            {!! Form::open(['class' => 'form-horizontal', 'action' => ['Admin\TeacherController@postSearch']]) !!}
                <fieldset>
                    <legend>{{ trans('common.labels.search_teacher') }}</legend>
                    <div class="form-group">
                        <div class="col-md-12">
                            {!! Form::text('input', $name, [
                                'class' => 'form-control',
                                'placeholder' => trans('common.labels.name_id_email'),
                            ]) !!}
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-lg-12">
                            <button type="submit" class="btn btn-{{ $mainColor }} btn-raised">
                                {{ trans('common.buttons.search') }}
                            </button>
                        </div>
                    </div>
                </fieldset>
            </form>
        </div>
    </div>
    <div class="col-lg-12 user-list">
        <table class="table table-striped table-hover ">
            <thead>
                <tr>
                    <th>#</th>
                    <th>{{ trans('common.labels.fullname') }}</th>
                    <th>{{ trans('common.labels.email') }}</th>
                </tr>
            </thead>
            <tbody>
            @foreach ($teachers as $teacher)
                <tr>
                    <td>{{ $teacher->id }}</td>
                    <td>{{ $teacher->full_name }}</td>
                    <td>{{ $teacher->email }}</td>
                </tr>
            @endforeach
            </tbody>
        </table>
        {!! $teachers->render() !!}
    </div>
</div>
@stop
