<?php
    use Carbon\Carbon;
    use App\Models\Report;
    use App\Models\Course;
    use App\Repositories\MediaRepository;

    function get_day_options()
    {
        return [
            'mon'   => trans('common.day_of_week.monday'),
            'tue'   => trans('common.day_of_week.tuesday'),
            'wed'   => trans('common.day_of_week.wednesday'),
            'thu'   => trans('common.day_of_week.thursday'),
            'fri'   => trans('common.day_of_week.friday'),
            'sat'   => trans('common.day_of_week.saturday'),
            'sun'   => trans('common.day_of_week.sunday'),
        ];
    }

    function get_course_types()
    {
        return [
            Course::REGISTER_TYPE_OPEN      => trans('common.courses.types.open'),
            Course::REGISTER_TYPE_INVITE    => trans('common.courses.types.invite'),
        ];
    }

    function format_date($dateString, $format)
    {
        return Carbon::parse($dateString)->format($format);
    }

    function get_genders()
    {
        return [
            1  => trans('common.labels.male'),
            0  => trans('common.labels.female'),
        ];
    }

    function get_report_format_options()
    {
        return [
            Report::REPORT_FORMAT_TEXT => trans('common.lessons.format_text'),
            Report::REPORT_FORMAT_FILE => trans('common.lessons.format_file'),
        ];
    }

    function is_student_view($moduleName)
    {
        return $moduleName === 'student' || $moduleName === '';
    }

    function is_teacher_view($moduleName)
    {
        return $moduleName === 'teacher';
    }

    function nl2br_without_tags($content)
    {
        return nl2br(strip_tags($content));
    }

    function link_to_course($moduleName, $courseId, $tab = null)
    {
        return action(
            is_teacher_view($moduleName) ?
                'Teacher\CourseController@show' :
                'Student\CourseController@show',
            [$courseId, $tab]
        );
    }

    function link_to_lesson($moduleName, $courseId, $lessonId, $tab = null)
    {
        return action(
            is_teacher_view($moduleName) ?
                'Teacher\LessonController@show' :
                'Student\LessonController@show',
            [$courseId, $lessonId, $tab]
        );
    }

    function get_signup($moduleName)
    {
        return (env('ALLOW_TEACHER_SIGNUP') && is_teacher_view($moduleName)) || (env('ALLOW_STUDENT_SIGNUP') && is_student_view($moduleName));
    }

    function get_login_uri()
    {
        return \AwesomeAuth::getLoginUrl();
    }

    function get_signup_uri()
    {
        return env('AA_SERVER_URL') . 'signup?redirect_uri=' . env('AA_REDIRECT_URI');
    }

    function get_env_title()
    {
        return env('APP_ENV') != 'production' ? '| ' .  env('APP_ENV') : '';
    }

    function get_changepassword_uri()
    {
        return env('AA_SERVER_URL') . 'change-password?redirect_uri=' . env('AA_REDIRECT_URI');
    }

    function get_logout_uri()
    {
        return env('AA_SERVER_URL') . 'logout?redirect_uri=' . env('AA_REDIRECT_URI');
    }

    function get_preview_file($mediaId)
    {
        $allowContentTypePreview = [
            'image/gif',
            'image/jpeg',
            'image/png',
            'application/pdf'
        ];
        $mediaRepository = new MediaRepository();
        $media = $mediaRepository->find($mediaId);
        $contentType = File::mimeType($media->url);

        if (in_array($contentType, $allowContentTypePreview)) {
            return true;
        }

        return false;
    }

    function get_update_profile_uri()
    {
        return env('AA_SERVER_URL') . 'update-profile?redirect_uri=' . env('AA_REDIRECT_URI') . 'reload';
    }

    function get_main_color_email($isTeacher = false)
    {
        if ($isTeacher) {
            return config('common.main_color_teacher_code');
        }

        return config('common.main_color_student_code');
    }

    function get_awesome_uri()
    {
        if (env('AWESOME_URI')) {
            return env('AWESOME_URI') . 'awesome_auth/login';
        }
        return false;
    }

    function run_command_background($commandName, $params = [])
    {
        $path = base_path();
        $paramStr = '';
        foreach ($params as $key => $value) {
            $paramStr .= $key . "='" . $value . "' ";
        }
        $paramStr = trim($paramStr);
        $command = "php {$path}/artisan {$commandName} {$paramStr}";
        $command .= '> /dev/null 2>/dev/null &';
        exec($command);
    }
