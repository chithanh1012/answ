<?php

namespace App\Http\Controllers\Student;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Repositories\CourseRepository;
use App\Repositories\LessonRepository;
use App\Repositories\ParticipantRepository;
use App\Repositories\MessageRepository;
use App\Services\CourseServices;

class LessonController extends BaseController
{
    private $courseRepository;
    private $lessonRepository;
    private $participantRepository;
    private $messageRepository;

    public function __construct(
        CourseRepository $courseRepository,
        LessonRepository $lessonRepository,
        ParticipantRepository $participantRepository,
        MessageRepository $messageRepository
    ) {
        parent::__construct();

        $this->courseRepository = $courseRepository;
        $this->lessonRepository = $lessonRepository;
        $this->participantRepository = $participantRepository;
        $this->messageRepository = $messageRepository;
    }

    public function show($courseId, $lessonId, $tab = null)
    {
        $canView = $this->currentUser && $this->currentUser->can('view-lesson', $courseId);
        if (!$canView) {
            return redirect()->back()->with([
                'message' => trans('students.courses.messages.not_register'),
                'result'  => 'warning'
            ]);
        }

        $course = $this->courseRepository->find($courseId);
        $listLessons = $course->lessons()->lists('id', 'start_date')->toArray();
        $lesson = $this->lessonRepository->find($lessonId);

        $messages = [];
        if ($this->currentUser) {
            $messages = $this->messageRepository->getMessagesSentByStudent($courseId, $this->currentUser->id, $lessonId);
        }

        $checkStudentAttend = $this->participantRepository->findByStudentIdLessonId($this->currentUser->id, $lessonId);
        $attendAction = '';
        if (!$checkStudentAttend) {
            $attendAction = ['Student\LessonController@store', $courseId, $lessonId];
        }

        return view('layouts.lessons.show', [
            'course'             => $course,
            'lesson'             => $lesson,
            'listLessons'        => $listLessons,
            'reports'            => $lesson->reports,
            'messages'           => $messages,
            'action'             => ['MessageController@lesson', $courseId, $lessonId],
            'method'             => 'post',
            'joined'             => $canView,
            'currentTab'         => $tab,
            'courseId'           => $courseId,
            'lessonId'           => $lessonId,
            'attendAction'       => $attendAction,
            'checkStudentAttend' => $checkStudentAttend,
        ]);
    }

    public function store(Request $request, $courseId, $lessonId, $tab = null)
    {
        $canView = $this->currentUser && $this->currentUser->can('view-lesson', $courseId);
        if (!$canView) {
            return redirect()->back()->with([
                'message' => trans('students.courses.messages.not_register'),
                'result'  => 'warning'
            ]);
        }

        $course = $this->courseRepository->find($courseId);
        $lesson = $this->lessonRepository->find($lessonId);

        if ($this->currentUser->can('check-attendance', $lesson)) {
            $this->participantRepository->create([
                'student_id' => $this->currentStudent->id,
                'lesson_id'  => $lessonId,
                'user_agent' => request()->header('user-agent'),
                'ip_address' => request()->getClientIp()
            ]);
            return redirect(action('Student\LessonController@show', [$course->id, $lessonId]))
                ->with([
                    'message' => trans('students.lessons.messages.attend_updated_success'),
                    'result' => 'success',
                ]);
        }
    }
}
