<?php

namespace App\Http\Controllers\Student;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Auth;
use App\Repositories\StudentRepository as Student;

class SessionController extends Controller
{
    private $studentRepository;

    public function __construct(Student $studentRepository)
    {
        parent::__construct();
        $this->middleware('guest', ['except' => ['getLogout']]);

        $this->studentRepository = $studentRepository;
    }

    public function getLogin()
    {
        return view('students/login');
    }

    public function postLogin(Request $request)
    {
        $validator = $this->studentRepository->validatorLogin($request->all());
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        $credentials = $request->only('email', 'password');

        if (Auth::student()->attempt($credentials, $request->has('remember'))) {
            return redirect('/');
        }

        return redirect('login')
            ->withInput($request->only('email', 'remeber'))
            ->withErrors([
                'msg' => trans('common.messages.login_invalid'),
            ]
        );
    }

    public function getLogout()
    {
        \AwesomeAuth::logout();
        Auth::student()->logout();

        return redirect(get_logout_uri());
    }

    public function getSignup()
    {
        if (!env('ALLOW_STUDENT_SIGNUP')) {
            return redirect('login');
        }
        return view('students/signup');
    }

    public function postSignup(Request $request)
    {
        if (!env('ALLOW_STUDENT_SIGNUP')) {
            return redirect('login');
        }
        $student = $request->all();

        $validator = $this->studentRepository->validatorSignup($student);
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        $credentials = [
            'email'    => $student['email'],
            'password' => $student['password']
        ];

        $student['password'] = bcrypt($student['password']);
        $this->studentRepository->create($student);

        Auth::student()->attempt($credentials);
        return redirect('/');
    }

    public function getAutoLogin()
    {
        return redirect(\AwesomeAuth::getLoginUrl());
    }
}
