<?php

namespace App\Http\Controllers\Student;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Repositories\CourseRepository;
use App\Repositories\CourseStudentRepository;
use App\Repositories\MessageRepository;
use Carbon\Carbon;
use App\Models\Course;
use App\Services\CourseServices;

class CourseController extends BaseController
{
    private $courseRepository;
    private $courseStudentRepository;
    private $messageRepository;

    public function __construct(
        CourseRepository $courseRepository,
        CourseStudentRepository $courseStudentRepository,
        MessageRepository $messageRepository
    ) {
        parent::__construct();
        $this->middleware('auth.student');

        $this->courseRepository = $courseRepository;
        $this->courseStudentRepository = $courseStudentRepository;
        $this->messageRepository = $messageRepository;
    }

    public function index()
    {
        $today = Carbon::today();
        $courses = $this->courseRepository
                        ->where('publish_started_at', '<=', $today)
                        ->where('publish_ended_at', '>=', $today)
                        ->where('register_type', Course::REGISTER_TYPE_OPEN)
                        ->orderBy('created_at', 'DESC')
                        ->paginate(config('student.course_per_page'));
        $courses->load('studentsCount');

        return view('students/courses/index', [
            'courses' => $courses
        ]);
    }

    public function show($courseId, $tab = null)
    {
        $course = $this->courseRepository->find($courseId);
        $joined = $this->currentStudent && $this->currentStudent->isJoinedCourse($courseId);
        $viewable = $joined && $this->currentStudent->canViewCourse($courseId);
        $this->authorize('student-view-course', [$course, $joined, $viewable]);
        $canJoin = $this->currentStudent && !$joined && $course->hasFreeSlot() && $course->isOpenRegister();

        $messages = [];
        $teacherMessages = [];
        if ($this->currentUser) {
            $messages = $this->messageRepository->getMessagesSentByStudent($courseId, $this->currentUser->id);
            $teacherMessages = $this->messageRepository->getMessagesSentAllStudents($this->currentUser->id, $courseId);
        }
        $lessons = $course->lessons;
        $lessons->load('participantsCount', 'reportsCount', 'messagesCount');

        $courseStudents = $course->courseStudents;
        $courseStudents->load('student');

        return view('layouts.courses.show', [
            'course'        => $course,
            'lessons'       => $lessons,
            'listLessons'   => CourseServices::getLessonList($lessons),
            'courseStudents'=> $courseStudents,
            'joined'        => $joined,
            'currentTab'    => $tab,
            'messages'      => $messages,
            'action'        => ['MessageController@course', $courseId],
            'method'        => 'post',
            'canJoin'       => $canJoin,
            'allowReply'    => false,
            'teacherMessages'    => $teacherMessages,
        ]);
    }
}
