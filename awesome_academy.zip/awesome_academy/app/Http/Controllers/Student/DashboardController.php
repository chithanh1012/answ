<?php

namespace App\Http\Controllers\Student;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Repositories\StudentRepository;
use Auth;
use Illuminate\Support\Facades\Input;

class DashboardController extends BaseController
{
    private $studentRepository;

    public function __construct(StudentRepository $studentRepository)
    {
        parent::__construct();

        $this->studentRepository = $studentRepository;
    }

    public function index()
    {
        if ($this->currentTeacher) {
            return redirect('/teacher');
        }
        if ($this->currentAdmin) {
            return redirect('/admin');
        }

        if (!$this->currentStudent) {
            $user = \AwesomeAuth::getUser();
            if ($user) {
                $user['awesome_authentication_id'] = $user['id'];
                $student = $this->studentRepository->findStudentByEmail($user['email'], true);
                $user['id'] = $student ? $student->id : null;
                $data = array_filter($user);

                $this->studentRepository->makeModel(true);
                $this->studentRepository->updateOrCreate($data);
                $student = $this->studentRepository->findStudentByEmail($user['email'], true);
                Auth::student()->login($student);

                return redirect('/');
            } else {
                return redirect('/login');
            }
        }

        $courses = $this->currentStudent->getCurrentCourses();
        $courses->load('lessonsCount', 'studentsCount', 'teacher');
        return view('students/dashboard/index', [
            'courses' => $courses,
        ]);
    }

    public function reload()
    {
        if ($this->currentUser) {
            $user = \AwesomeAuth::getUser(true);
            if ($user) {
                $user['awesome_authentication_id'] = $user['id'];
                $student = $this->studentRepository->findStudentByEmail($user['email'], true);
                $user['id'] = $student ? $student->id : null;
                $data = array_filter($user);

                $this->studentRepository->makeModel(true);
                $this->studentRepository->updateOrCreate($data);
                $student = $this->studentRepository->findStudentByEmail($user['email'], true);
                Auth::student()->login($student);

                return redirect(Input::get('redirect_uri', '/'));
            }
            return redirect('/');
        } else {
            return redirect('/login');
        }
    }
}
