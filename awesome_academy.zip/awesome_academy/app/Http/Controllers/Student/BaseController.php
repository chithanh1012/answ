<?php

namespace App\Http\Controllers\Student;

use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    public function __construct()
    {
        parent::__construct();
    }
}
