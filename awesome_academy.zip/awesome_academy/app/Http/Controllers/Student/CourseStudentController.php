<?php
namespace App\Http\Controllers\Student;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Repositories\CourseRepository;
use App\Repositories\CourseStudentRepository;
use App\Repositories\CourseInvitationRepository;

class CourseStudentController extends BaseController
{
    private $courseStudentRepository;
    private $courseInvitationRepository;
    private $courseRepository;

    public function __construct(
        CourseRepository $courseRepository,
        CourseStudentRepository $courseStudentRepository,
        CourseInvitationRepository $courseInvitationRepository
    ) {
        parent::__construct();
        $this->middleware('auth.student');

        $this->courseRepository = $courseRepository;
        $this->courseStudentRepository = $courseStudentRepository;
        $this->courseInvitationRepository = $courseInvitationRepository;
    }

    public function join($courseId, $code)
    {
        $course = $this->courseRepository->find($courseId);
        $message = trans('students.courses.messages.register_success');
        $result = 'success';
        $invite = $this->currentStudent->getInviteWithCode($courseId, $code);
        if ($invite && $course->hasFreeSlot()) {
            $this->courseStudentRepository->create([
                'course_id'  => $courseId,
                'student_id' =>  $this->currentStudent->id
            ]);
            $this->courseInvitationRepository->update(['used' => true], $invite->id);
        } else {
            $message = trans('students.courses.messages.register_false');
            $result = 'warning';
        }

        return redirect('/courses/' . $courseId)->with([
            'message' => $message,
            'result'  => $result
        ]);
    }

    public function store($courseId)
    {
        $course = $this->courseRepository->find($courseId);
        $message = trans('students.courses.messages.register_success');
        $result = 'success';

        if ($this->currentStudent->isJoinedCourse($courseId)) {
            $message = trans('students.courses.messages.register_already');
            $result = 'warning';
        } else {
            if ($course->hasFreeSlot() && $course->isOpenRegister()) {
                $this->courseStudentRepository->create([
                    'course_id'  => $courseId,
                    'student_id' =>  $this->currentStudent->id
                ]);
            } else {
                $message = trans('students.courses.messages.register_false');
                $result = 'warning';
            }
        }

        return redirect()->back()->with([
            'message' => $message,
            'result'  => $result
        ]);
    }
}
