<?php

namespace App\Http\Controllers\Student;

use Illuminate\Http\Request;
use App\Http\Requests;
use App\Repositories\CourseRepository;
use App\Repositories\LessonRepository;
use App\Repositories\ReportRepository;
use App\Repositories\ReportStudentRepository;
use App\Services\MediaServices;

class ReportStudentController extends BaseController
{
    private $courseRepository;
    private $lessonRepository;
    private $reportRepository;
    private $reportStudentRepository;

    public function __construct(
        CourseRepository $courseRepository,
        LessonRepository $lessonRepository,
        ReportRepository $reportRepository,
        ReportStudentRepository $reportStudentRepository
    ) {
        parent::__construct();
        $this->middleware('auth.student');

        $this->courseRepository = $courseRepository;
        $this->lessonRepository = $lessonRepository;
        $this->reportRepository = $reportRepository;
        $this->reportStudentRepository = $reportStudentRepository;
    }

    public function create($courseId, $lessonId, $reportId)
    {
        $lesson = $this->lessonRepository->find($lessonId);
        $report = $this->reportRepository->find($reportId);
        if ($this->currentStudent->can('submit-report', [$report, $lesson])) {
            $course = $this->courseRepository->find($courseId);
            $currentReport = $this->currentStudent
                                  ->reportStudents()
                                  ->where('report_id', $reportId)
                                  ->first();

            return view('students.reports.create', [
                'course' => $course,
                'lesson' => $lesson,
                'report' => $report,
                'currentReport' => $currentReport,
            ]);
        } else {
            return redirect(action('Student\LessonController@show', [$courseId, $lessonId]));
        }
    }

    public function store($courseId, $lessonId, $reportId, Request $request)
    {
        $reportStudent = $request->all();
        $reportStudent['student_id'] = $this->currentStudent->id;
        $reportStudent['report_id'] = $reportId;
        $message = trans('students.lessons.messages.submit_report_success');

        $report = $this->reportRepository->find($reportId);
        $currentReport = $this->currentStudent
                              ->reportStudents()
                              ->where('report_id', $reportId)
                              ->first();
        if ($currentReport) {
            if ($report->isTextFormat()) {
                $this->reportStudentRepository->update(['content' => $reportStudent['content']], $currentReport->id);
            } else {
                MediaServices::updateReportStudentMedia($request->all(), $currentReport->id);
            }
        } else {
            if ($this->currentStudent->isJoinedCourse($courseId)) {
                $reportStudent = $this->reportStudentRepository->create($reportStudent);
                if (!$report->isTextFormat()) {
                    MediaServices::updateReportStudentMedia($request->all(), $reportStudent->id);
                }
            } else {
                $message = trans('common.messages.something_wrong');
            }
        }

        return redirect(action('Student\ReportStudentController@create', [$courseId, $lessonId, $reportId]))->with([
            'message' => $message
        ]);
    }
}
