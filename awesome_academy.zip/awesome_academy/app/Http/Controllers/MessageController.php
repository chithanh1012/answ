<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Repositories\MessageRepository;
use App\Models\Message;

class MessageController extends Controller
{
    private $messageRepository;

    public function __construct(MessageRepository $messageRepository)
    {
        parent::__construct();

        $this->messageRepository = $messageRepository;
    }

    public function course($courseId, Request $request, $role = '')
    {
        $result = $this->messageRepository->sendMessage($request, $this->currentUser, $courseId, $role);

        if (!$result) {
            app()->abort(403);
        }

        if ($this->currentTeacher) {
            $messages = $role ? 'sentmessages' : 'messages';
            return redirect(action('Teacher\CourseController@show', [$courseId, $messages]))->with([
                'message' => trans('common.messages.sended_success'),
                'result' => config('common.main_color_teacher'),
            ]);
        }

        return redirect(action('Student\CourseController@show', [$courseId, 'messages']))->with([
            'message' => trans('common.messages.sended_success'),
            'result' => config('common.main_color_student'),
        ]);
    }

    public function lesson($courseId, $lessonId, Request $request)
    {
        $result = $this->messageRepository->sendMessage($request, $this->currentUser, $courseId, '', $lessonId);

        if (!$result) {
            app()->abort(403);
        }

        if ($this->currentTeacher) {
            return redirect("/teacher/courses/$courseId/lessons/$lessonId/messages")->with([
                'msg' => trans('common.messages.messages.sended_success')
            ]);
        }

        return redirect("/courses/$courseId/lessons/$lessonId/messages")->with([
            'msg' => trans('common.messages.messages.sended_success')
        ]);
    }
}
