<?php
namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use App\Services\AjaxController;
use App\Repositories\MediaRepository;
use App\Models\Media;
use Carbon\Carbon;
use File;

class MediaController extends Controller
{
    use AjaxController;

    private $mediaRepository;

    public function __construct(MediaRepository $mediaRepository)
    {
        parent::__construct();
        $this->middleware('auth');

        $this->mediaRepository = $mediaRepository;
    }

    public function upload()
    {
        $originalFileName = urldecode(@$_SERVER['HTTP_X_FILE_NAME']);
        $data = file_get_contents("php://input");
        $fileSize = strlen($data);

        $maxSize = config('common.max_media_upload_size');
        if ($fileSize > $maxSize) {
            $maxSizeString = ($maxSize / 1000000) . ' MB';
            return $this->responseAjaxFailed(trans('common.messages.file_too_big', ['maxSize' => $maxSizeString]));
        }

        $uploadFilePath = config('paths.upload') . uniqid();
        if (file_put_contents($uploadFilePath, $data) === false) {
            return $this->responseAjaxFailed(trans('common.messages.something_wrong'));
        }

        $mediaData = [
            'file_name'     => $originalFileName,
            'url'           => $uploadFilePath,
            'object_id'     => 0,
            'object_type'   => Media::OBJECT_TYPE_TEMPORARY,
        ];
        $media = $this->mediaRepository->create($mediaData);

        return $this->responseAjaxSuccess([
            'id'        => $media->id,
            'fileName'  => $media->file_name,
        ]);
    }

    public function show($mediaId)
    {
        $media = $this->mediaRepository->find($mediaId);
        if ($media->expired_date->timestamp > 0 && $media->expired_date->lt(Carbon::today())) {
            app()->abort(404);
        }

        $contentType = File::mimeType($media->url);
        $contents = File::get($media->url);

        return response()->make($contents, 200, [
            'Content-Type' => $contentType,
        ]);
    }

    public function download($mediaId)
    {
        $media = $this->mediaRepository->find($mediaId);
        if ($media->expired_date->timestamp > 0 && $media->expired_date->lt(Carbon::today())) {
            app()->abort(404);
        }
        return response()->download($media->url, $media->file_name);
    }

    public function destroy($mediaId)
    {
        if (!$this->mediaRepository->delete($mediaId)) {
            return $this->responseAjaxFailed();
        }
        return $this->responseAjaxSuccess();
    }
}
