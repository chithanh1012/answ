<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Auth;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    protected $currentAdmin;
    protected $currentTeacher;
    protected $currentStudent;
    protected $currentUser;

    public function __construct()
    {
        $this->currentAdmin = Auth::admin()->get();
        $this->currentTeacher = Auth::teacher()->get();
        $this->currentStudent = Auth::student()->get();
        $this->currentUser = $this->currentAdmin ?: ($this->currentTeacher ?: $this->currentStudent);

        if ($this->currentAdmin) {
            $mainColor = config('common.main_color_admin');
        } elseif ($this->currentTeacher) {
            $mainColor = config('common.main_color_teacher');
        } else {
            $mainColor = config('common.main_color_student');
        }

        view()->share([
            'currentAdmin' => $this->currentAdmin,
            'currentTeacher' => $this->currentTeacher,
            'currentStudent' => $this->currentStudent,
            'currentUser' => $this->currentUser,
            'moduleName' => 'student',
            'modulePath' => '/',
            'menus' => [],
            'mainColor' => $mainColor,
            'stringLengthLimit' => config('common.string_length_limit'),
        ]);
    }
}
