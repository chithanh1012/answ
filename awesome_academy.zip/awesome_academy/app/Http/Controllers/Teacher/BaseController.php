<?php

namespace App\Http\Controllers\Teacher;

use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    public function __construct()
    {
        parent::__construct();

        view()->share([
            'moduleName' => 'teacher',
            'modulePath' => '/teacher/',
            'mainColor' => config('common.main_color_teacher'),
            'menus' => [],
        ]);
    }
}
