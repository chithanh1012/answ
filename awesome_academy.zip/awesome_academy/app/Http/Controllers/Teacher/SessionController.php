<?php

namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use Auth;
use App\Repositories\TeacherRepository as Teacher;

class SessionController extends BaseController
{
    private $teacherRepository;

    public function __construct(Teacher $teacherRepository)
    {
        parent::__construct();
        $this->middleware('guest', ['except' => ['getLogout']]);

        $this->teacherRepository = $teacherRepository;
    }

    public function getLogin()
    {
        return view('teachers/login');
    }

    public function postLogin(Request $request)
    {
        $this->validate($request, [
            'email' => 'required|email',
            'password' => 'required',
            ]);

        $credentials = $request->only('email', 'password');

        if (Auth::teacher()->attempt($credentials, $request->has('remember'))) {
            return redirect('teacher');
        }

        return redirect('teacher/login')
            ->withInput($request->only('email', 'remeber'))
            ->withErrors([
                'msg' => trans('common.messages.login_invalid'),
            ]);
    }

    public function getLogout()
    {
        Auth::teacher()->logout();
        return redirect('teacher/login');
    }

    public function getSignup()
    {
        if (!env('ALLOW_TEACHER_SIGNUP')) {
            return redirect('teacher/login');
        }
        return view('teachers/signup');
    }

    public function postSignup(Request $request)
    {
        if (!env('ALLOW_TEACHER_SIGNUP')) {
            return redirect('teacher/login');
        }
        $teacher = $request->all();

        $validator = $this->teacherRepository->validatorSignup($teacher);
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        $credentials = [
            'email'    => $teacher['email'],
            'password' => $teacher['password']
        ];

        $teacher['password'] = bcrypt($teacher['password']);
        $this->teacherRepository->create($teacher);

        Auth::teacher()->attempt($credentials);
        return redirect('/');
    }
}
