<?php

namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Repositories\TeacherRepository;
use App\Repositories\PasswordResetRepository;
use App\Events\ForgotPassword;
use App\Events\ResetPassword;
use Illuminate\Support\Facades\Input;

class PasswordController extends BaseController
{
    private $teacherRepository;
    private $passwordResetRepository;

    public function __construct(
        TeacherRepository $teacherRepository,
        PasswordResetRepository $passwordResetRepository
    ) {
        parent::__construct();

        $this->middleware('guest');
        $this->teacherRepository = $teacherRepository;
        $this->passwordResetRepository = $passwordResetRepository;
    }

    public function getEmail()
    {
        return view('teachers.password.forgot_password');
    }

    public function postEmail(Request $request)
    {
        $validator = $this->passwordResetRepository->validatorForgotPassword($request->all());
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        $email = $request->input('email');

        $teacher = $this->teacherRepository->checkEmailExists($email);
        if ($teacher) {
            $data = [
                'email' => $email,
            ];
            event(new ForgotPassword($data));

            return redirect()->back()->with([
                'message' => trans('passwords.sent'),
                'result' => 'success',
            ]);
        } else {
            return redirect()->back()->withErrors(['email' => trans('teachers.messages.email_not_exists')]);
        }
    }

    public function getReset($token = null)
    {
        if (is_null($token)) {
            throw new NotFoundHttpException;
        }

        return view('teachers.password.reset')->with('token', $token);
    }

    public function postReset(Request $request)
    {
        $validator = $this->passwordResetRepository->validatorResetPassword($request->all());
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        $credentials = $request->only(
            'email', 'password', 'password_confirmation', 'token'
        );

        $token = $this->passwordResetRepository->findByToken($credentials['token']);
        if($token){
            $result = event(new ResetPassword($credentials));

            if ($result) {
                return redirect('/')->with([
                    'message' => trans('passwords.reset'),
                    'result' => 'success',
                ]);
            }
        }
        return redirect()->back()
            ->withInput($request->only('email'))
            ->withErrors(['email' => trans('passwords.token')]);
    }

    public function getSetPassword($token = null)
    {
        if (is_null($token)) {
            throw new NotFoundHttpException;
        }

        return view('teachers.password.set_password')->with([
            'token' => $token,
        ]);
    }

    public function postSetPassword(Request $request)
    {

        $validator = $this->passwordResetRepository->validatorSetPassword($request->all());
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        $credentials = $request->only(
            'password', 'password_confirmation', 'token'
        );

        $teacher = $this->passwordResetRepository->findByToken($credentials['token'], true);
        if (!$teacher) {
            return redirect()->back()
                ->withInput($request->only('email'))
                ->withErrors(['email' => trans('common.messages.account_not_exists_expire')]);
        }

        $credentials['email'] = $teacher->email;

        $result = event(new ResetPassword($credentials));

        if ($result) {
            return redirect('teacher')->with([
                'message' => trans('common.messages.account_activate_success'),
                'result' => 'success',
            ]);
        }

        return redirect()->back()
            ->withInput($request->only('email'))
            ->withErrors(['email' => trans('common.messages.account_activate_failed')]);
    }
}
