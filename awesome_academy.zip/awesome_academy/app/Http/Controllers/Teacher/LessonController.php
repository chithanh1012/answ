<?php

namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use App\Repositories\CourseRepository;
use App\Repositories\LessonRepository;
use App\Repositories\ReportRepository;
use App\Repositories\MessageRepository;
use App\Repositories\MediaRepository;
use Carbon\Carbon;
use Route;
use App\Services\MediaServices;
use App\Services\CourseServices;

class LessonController extends BaseController
{
    private $courseRepository;
    private $lessonRepository;
    private $reportRepository;
    private $messageRepository;
    private $mediaRepository;

    private $course;

    public function __construct(
        CourseRepository $courseRepository,
        LessonRepository $lessonRepository,
        ReportRepository $reportRepository,
        MediaRepository $mediaRepository,
        MessageRepository $messageRepository
    ){
        parent::__construct();

        $this->courseRepository = $courseRepository;
        $this->lessonRepository = $lessonRepository;
        $this->reportRepository = $reportRepository;
        $this->messageRepository = $messageRepository;
        $this->mediaRepository = $mediaRepository;

        $courseId = Route::current()->getParameter('course_id');
        $this->course = $this->courseRepository->find($courseId);
        $this->authorize('course-owner', $this->course);
    }

    public function create($courseId)
    {
        $lesson =  $this->lessonRepository->makeModel();
        $lastLesson = $this->lessonRepository->getLastLesson($courseId);

        $nextLessonDate = Carbon::today();
        if ($lastLesson) {
            $lastStartDate = $lastLesson->start_date;
            $timeTableDay = $this->course->time_table[0]->day;
            $nextLessonDate = $this->lessonRepository->getNextStartDate($timeTableDay, $lastStartDate);
        }
        $lesson->start_date = $nextLessonDate;

        return view('teachers.lessons.form', [
            'title'     => trans('common.lessons.create_lesson'),
            'action'    => ['Teacher\LessonController@store', $courseId],
            'method'    => 'post',
            'course'    => $this->course,
            'lesson'    => $lesson,
            'isEditPage'=> false,
        ]);
    }

    public function store($courseId, Request $request)
    {
        $input = $request->all();
        $input['course_id'] = $courseId;
        $lesson = $this->lessonRepository->create($input);
        if ($request->has('media_id')) {
            MediaServices::updateLessonMedia($input, $lesson->id);
        }

        if ($request->has('reports')) {
            $reports = $request->get('reports');
            $this->reportRepository->createMutilpleReport($reports, $lesson->id);
        }

        return redirect(action('Teacher\LessonController@show', [$courseId, $lesson->id]))->with(['msg' => trans('common.lessons.created_success')]);
    }

    public function generate($courseId, Request $request)
    {
        $input = $request->all();
        $this->validate($request, [
            'start_date'     => 'required|date_format:"Y-m-d"',
            'generate_times' => 'required|integer|min:1|max:100'
        ]);

        $this->lessonRepository->generateLessons(
            $this->course,
            $input['start_date'],
            $input['generate_times']
        );

        return redirect()->back();
    }

    public function edit($courseId, $lessonId)
    {
        $lesson = $this->lessonRepository->find($lessonId);
        if ($courseId != $lesson->course_id) {
            app()->abort(403);
        }

        return view('teachers.lessons.form', [
            'title'         => trans('common.lessons.edit_lesson'),
            'action'        => ['Teacher\LessonController@update', $courseId, $lessonId],
            'method'        => 'put',
            'course'        => $this->course,
            'lesson'        => $lesson,
            'isEditPage'    => true,
        ]);
    }

    public function update($courseId, $lessonId, Request $request) {
        $lesson = $this->lessonRepository->find($lessonId);
        if ($courseId != $lesson->course_id) {
            app()->abort(403);
        }

        $input = $request->except('course_id', '_token', '_method');
        $this->lessonRepository->update($input, $lessonId);
        if ($request->has('media_id')) {
            MediaServices::updateLessonMedia($input, $lessonId);
        }

        return redirect(action('Teacher\LessonController@show', [$courseId, $lessonId]))->with(['msg' => trans('common.lessons.updated_success')]);
    }

    public function show($courseId, $lessonId, $tab = null)
    {
        $course = $this->courseRepository->find($courseId);
        $listLessons = $course->lessons()->lists('id', 'start_date')->toArray();
        $lesson = $this->lessonRepository->find($lessonId);
        $students = CourseServices::getStudentArray($course->students, $lesson->participants);
        $allowReply = $this->currentUser && $this->currentUser->id == $course->teacher_id;
        $messages = $this->messageRepository->getMessagesReceivedByTeacher($courseId, $lessonId);

        return view('layouts.lessons.show', [
            'course'       => $course,
            'lesson'       => $lesson,
            'listLessons'  => $listLessons,
            'students'     => $students,
            'reports'      => $lesson->reports,
            'messages'     => $messages,
            'action'       => ['MessageController@lesson', $courseId, $lessonId],
            'method'       => 'post',
            'allowReply'   => $allowReply,
            'currentTab'   => $tab,
        ]);
    }
}
