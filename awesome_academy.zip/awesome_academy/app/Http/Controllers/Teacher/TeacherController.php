<?php
namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use App\Repositories\TeacherRepository;
use App\Repositories\CourseRepository;
use App\Services\AjaxController;
use Auth;

class TeacherController extends BaseController
{
    use AjaxController;
    private $teacherRepository;
    private $courseRepository;

    public function __construct(TeacherRepository $teacherRepository, CourseRepository $courseRepository) {
        parent::__construct();
        $this->middleware('auth.teacher');

        $this->teacherRepository = $teacherRepository;
        $this->courseRepository  = $courseRepository;
    }

    public function ajaxSearch(Request $request) {
        $this->validate($request, [
            'name' => 'required|string|min:3',
        ]);
        $name = $request->get('name');
        $courseId = $request->get('course_id');
        $teachers = null;
        if ($courseId) {
            $course = $this->courseRepository->find($courseId);
            $teachers = $this->teacherRepository
                             ->searchTeacherByName($name, $this->currentTeacher->id, $course->teacher->id);
        } else {
            $teachers = $this->teacherRepository
                             ->searchTeacherByName($name, $this->currentTeacher->id);
        }
        if (count($teachers)) {
            return $this->responseAjaxSuccess([
                'teachers' => $teachers,
                'status'   => 'success'
            ]);
        } else {
            return $this->responseAjaxSuccess([
                'message' => trans('teachers.courses.messages.no_teacher_found'),
                'status'  => 'not_found'
            ]);
        }
    }

    public function getChangePassword(Request $request)
    {
        return view('teachers.change-password');
    }

    public function postChangePassword(Request $request)
    {
        $teacher = $request->all();

        $validator = $this->teacherRepository->validatorChangePassword($teacher);
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        if ($teacher['password'] == $teacher['password_confirmation']) {
            $teacher['password'] = bcrypt($teacher['password']);
            $this->teacherRepository->update($teacher, Auth::teacher()->get()->id);
            return redirect('/')->with([
                'message' => trans('teachers.change_password_success'),
                'result' => 'success',
            ]);
        }
    }

    public function getUpdateProfile(Request $request)
    {
        return view('teachers.update-profile');
    }

    public function postUpdateProfile(Request $request)
    {
        $teacher = $request->all();

        $teacherId = $this->currentUser->id;
        $validator = $this->teacherRepository->validatorUpdateProfile($teacher);
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        if ($this->teacherRepository->update($teacher, $teacherId)) {
            return redirect('/')->with([
                'message' => trans('common.messages.update_profile_success'),
                'result' => 'success',
            ]);
        }

        return redirect('/')->with([
            'message' => trans('common.messages.update_profile_failed'),
        ]);
    }
}
