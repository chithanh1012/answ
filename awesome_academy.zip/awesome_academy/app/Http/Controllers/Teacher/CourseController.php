<?php

namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use App\Repositories\CourseRepository;
use App\Repositories\LessonRepository;
use App\Repositories\StudentRepository;
use App\Repositories\MessageRepository;
use App\Models\Course;
use App\Services\SendGridService;
use App\Services\CourseServices;
use Carbon\Carbon;
use App\Repositories\CourseStudentRepository;
use App\Repositories\CourseAssistantRepository;
use App\Services\AjaxController;
use App\Models\Student;
use App\Models\CourseStudent;

class CourseController extends BaseController
{
    use AjaxController;
    private $courseRepository;
    private $studentRepository;
    private $messageRepository;
    private $lessonRepository;
    private $courseStudentRepository;
    private $courseAssistantRepository;

    public function __construct(
        CourseRepository $courseRepository,
        LessonRepository $lessonRepository,
        StudentRepository $studentRepository,
        MessageRepository $messageRepository,
        CourseStudentRepository $courseStudentRepository,
        CourseAssistantRepository $courseAssistantRepository
    ) {
        parent::__construct();
        $this->middleware('auth.teacher');

        $this->courseRepository = $courseRepository;
        $this->lessonRepository = $lessonRepository;
        $this->studentRepository = $studentRepository;
        $this->messageRepository = $messageRepository;
        $this->courseStudentRepository = $courseStudentRepository;
        $this->courseAssistantRepository = $courseAssistantRepository;
    }

    public function create()
    {
        $course =  $this->courseRepository->makeModel();

        return view('teachers.courses.form', [
            'title'         => trans('common.courses.create_course'),
            'action'        => 'Teacher\CourseController@store',
            'method'        => 'post',
            'course'        => $course,
        ]);
    }

    public function store(Request $request) {
        $input = $request->except('created_at', 'updated_at');
        $timeTable = [
            'day'           => $input['day'],
            'start_time'    => $input['start_time'],
            'end_time'      => $input['end_time'],
        ];
        $input['time_table'] = [$timeTable];
        $input['teacher_id'] = $this->currentUser->id;

        $course = $this->courseRepository->create($input);
        $this->courseAssistantRepository->updateData($input, $course->id);

        return redirect(action('Teacher\CourseController@show', $course->id))->with(['msg' => trans('common.courses.created_success')]);
    }

    public function index()
    {
        $teacherId = $this->currentUser->id;
        $courses = $this->courseRepository
                        ->where('teacher_id', '=', $teacherId)
                        ->orderBy('created_at', 'DESC')
                        ->paginate(config('teacher.course_per_page'));
        $courses->load(['lessonsCount', 'studentsCount', 'messagesCount']);

        return view('teachers/courses/index', [
            'courses' => $courses
        ]);
    }

    public function edit($id)
    {
        $course = $this->courseRepository->find($id);
        $this->authorize('course-owner', $course);

        return view('teachers.courses.form', [
            'title'         => trans('common.courses.edit_course'),
            'action'        => ['Teacher\CourseController@update', $course->id],
            'method'        => 'put',
            'course'        => $course,
            'isEditPage'    => true,
        ]);
    }

    public function update($id, Request $request) {
        $course = $this->courseRepository->find($id);
        $this->authorize('course-owner', $course);

        $input = $request->all();
        $timeTable = [
            'day'           => $input['day'],
            'start_time'    => $input['start_time'],
            'end_time'      => $input['end_time'],
        ];
        $input['time_table'] = json_encode([$timeTable]);

        $studentNumber = $course->students()->count();
        $this->courseRepository->updateValidationRules($studentNumber);
        $this->courseRepository->update($input, $id);
        $this->courseAssistantRepository->updateData($input, $course->id);

        return redirect(action('Teacher\CourseController@show', $course->id))->with(['msg' => trans('common.courses.updated_success')]);
    }

    public function show($id, $tab = null)
    {
        $course = $this->courseRepository->find($id);
        $this->authorize('course-owner', $course);

        $courseStudents = $course->courseStudents;
        $courseStudents->load('student');

        $invitionStudents = [];
        if ($course->register_type == Course::REGISTER_TYPE_INVITE) {
            $invitionStudents = $course->waitingJoinStudents;
        }

        $messages = [];
        $msgSentToAll = [];
        $allowReply = false;
        if ($this->currentUser) {
            $allowReply = $this->currentUser->id === $course->teacher_id;
            $messages = $this->messageRepository->getMessagesReceivedByTeacher($id);
            $sentMessages = $this->messageRepository->getMessagesSentAllStudents($this->currentUser->id, $id, true);
        }
        $lessons = $course->lessons;
        $lessons->load('participantsCount', 'reportsCount', 'messagesCount');

        $courseAssistants = $course->courseAssistants;
        $courseAssistants->load('teacher');

        return view('layouts.courses.show', [
            'course'           => $course,
            'courseStudents'   => $courseStudents,
            'invitionStudents' => $invitionStudents,
            'lessons'          => $lessons,
            'listLessons'      => CourseServices::getLessonList($lessons),
            'currentTab'       => $tab,
            'messages'         => $messages,
            'action'           => ['MessageController@course', $id],
            'teacherAction'    => ['MessageController@course', $id, 'teacher'],
            'memoAction'       => ['Teacher\CourseController@postMemo', $id],
            'method'           => 'post',
            'allowReply'       => $allowReply,
            'joined'           => false,
            'courseAssistants' => $courseAssistants,
            'sentMessages'     => $sentMessages,
        ]);
    }

    public function postSearch($courseId, Request $request)
    {
        $course = $this->courseRepository->find($courseId);
        $this->authorize('course-owner', $course);
        $this->validate($request, [
            'name' => 'required|string|min:3',
        ]);

        $students = $this->studentRepository
                         ->searchStudentByName($request->get('name'));
        $results = [];
        foreach ($students as $key => $student) {
            $isJoinedCourse = $student->isJoinedCourse($courseId);
            $results[$key] = $student->toArray();
            $results[$key]['isJoinedCourse'] = $isJoinedCourse;
        }
        if ($results) {
            return $this->responseAjaxSuccess([
                'students' => $results,
                'status'   => 'success'
            ]);
        } else {
            return $this->responseAjaxSuccess([
                'message' => trans('teachers.courses.messages.no_student_found'),
                'status'  => 'not_found'
            ]);
        }
    }

    public function postInvite($courseId, Request $request)
    {
        $course = $this->courseRepository->find($courseId);
        $this->authorize('course-owner', $course);

        $data = $request->all();
        $student = $this->studentRepository->find($data['student_id']);
        $message = trans('common.messages.something_wrong');
        $code = 'false';

        if ($course->hasFreeSlot()) {
            if (!$student->isJoinedCourse($courseId)) {
                $data['course_id'] = $courseId;
                $this->courseStudentRepository->create($data);
                $code  = 'success';
                $message = trans('common.messages.invitations.invite_success');
            }
        } else {
            $message = trans('common.messages.courses.course_is_full');
        }

        session(['currentTab' => 'students']);
        return response()->json([
            'message' => $message,
            'code'    => $code
        ]);
    }

    public function postCancelInvite($courseId, Request $request)
    {
        $course = $this->courseRepository->find($courseId);
        $this->authorize('course-owner', $course);

        $data = $request->all();
        $student = $this->studentRepository->find($data['student_id']);

        $message = trans('common.messages.something_wrong');
        $code = 'false';

        if (!$student->isJoinedCourse($courseId)) {
            $courseInvitation = $this->courseInvitationRepository
                                     ->where('course_id', $courseId)
                                     ->where('student_id', $data['student_id'])
                                     ->firstOrFail();
            if ($data['action'] === 'cancel' && $courseInvitation){
                $this->courseInvitationRepository->delete();
                $message = trans('common.messages.invitations.cancel_success');
                $code = 'success';
            }
        }

        session(['currentTab' => 'students']);
        return response()->json([
            'message' => $message,
            'code'    => $code
        ]);
    }

    public function postMemo($id, Request $request)
    {
        $course = $this->courseRepository->find($id);
        $this->authorize('course-owner', $course);

        $input = $request->only('id', 'memo');
        $this->courseStudentRepository->find($input['id']);
        $return = $this->courseStudentRepository->update($input, $input['id']);

        if ($return) {
            return redirect(action('Teacher\CourseController@show', [$id, 'students']))->with([
                'message' => trans('teachers.courses.memo_save_success'),
                'result' => config('common.main_color_teacher'),
            ]);
        } else {
            return redirect(action('Teacher\CourseController@show', [$id, 'students']))->with([
                'message' => trans('teachers.courses.memo_save_success'),
            ]);
        }
    }

    public function courseAssistant()
    {
        $courses = $this->currentTeacher
                        ->courseAssistants()
                        ->orderBy('created_at', 'DESC')
                        ->paginate(config('teacher.course_per_page'));
        $courses->load(['lessonsCount', 'studentsCount', 'messagesCount']);

        return view('teachers.courses.index', [
            'courses' => $courses
        ]);
    }

    public function postInviteStudents($courseId, Request $request)
    {
        $course = $this->courseRepository->find($courseId);
        $this->authorize('course-owner', $course);

        $input = $request->all();
        $identityNumberList = $input['identity_number_list'];
        $identityNumbers = explode(',', $identityNumberList);

        $message = trans('common.messages.something_wrong');
        $code = 'false';
        $studentIds = Student::whereIn('identity_number', $identityNumbers)
                             ->lists('id')
                             ->toArray();
        $existedStudentIds = CourseStudent::where('course_id', $courseId)
                                          ->whereIn('student_id', $studentIds)
                                          ->lists('student_id')
                                          ->toArray();
        $newStudentIds = array_diff($studentIds, $existedStudentIds);
        if (!$newStudentIds) {
            $message = trans('common.messages.courses.students_not_added');
            $code = 'stop';
        } elseif ($newStudentIds && $course->hasFreeSlot()) {
            $result = $course->students()->attach($newStudentIds);
            $code  = 'success';
            $message = trans('common.messages.invitations.invite_success');
        } else {
            $message = trans('common.messages.courses.course_is_full');
        }

        session(['currentTab' => 'students']);
        return response()->json([
            'message' => $message,
            'code'    => $code
        ]);
    }

    public function courseStudentActive($courseId, Request $request)
    {
        $course = $this->courseRepository->find($courseId);
        $this->authorize('course-owner', $course);

        $data = $request->all();
        $message = trans('common.messages.something_wrong');
        $code = 'false';

        if ($this->courseStudentRepository->update($data, $data['id'])) {
            $code  = 'success';
            $message = trans('teachers.messages.course_student_not_active');
            if ($data['is_active']) {
                $message = trans('teachers.messages.course_student_is_active');
            }
        }

        session(['currentTab' => 'students']);
        return response()->json([
            'message' => $message,
            'code'    => $code
        ]);
    }
}
