<?php
namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use App\Repositories\ReportRepository;
use App\Repositories\ReportStudentRepository;
use App\Models\ReportStudent;

class ReportStudentController extends BaseController
{
    private $reportRepository;
    private $reportStudentRepository;

    public function __construct(ReportRepository $reportRepository, ReportStudentRepository $reportStudentRepository)
    {
        parent::__construct();

        $this->reportRepository = $reportRepository;
        $this->reportStudentRepository = $reportStudentRepository;
    }

    public function show($courseId, $lessonId, $reportId)
    {
        $report = $this->reportRepository->find($reportId);
        $reportStudents = $report->reportStudents()->paginate(ReportStudent::REPORT_PER_PAGE);
        $reportStudents->load('student');

        return view('teachers.reports.show', [
            'report'         => $report,
            'reportStudents' => $reportStudents,
            'courseId'       => $courseId,
            'lessonId'       => $lessonId,
        ]);
    }
}
