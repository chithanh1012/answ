<?php
namespace App\Http\Controllers\Teacher;

use Illuminate\Http\Request;
use App\Repositories\ReportRepository;

class ReportController extends BaseController
{
    private $reportRepository;

    public function __construct(ReportRepository $reportRepository)
    {
        parent::__construct();

        $this->reportRepository = $reportRepository;
    }

    public function ajaxStore($courseId, $lessonId, Request $request)
    {
        $report = $request->except('format_text');
        $report['lesson_id'] = $lessonId;
        $report = $this->reportRepository->create($report);
        return response()->json([
            'message' => trans('common.messages.reports.create_success'),
            'id'      => $report->id,
        ]);
    }

    public function ajaxUpdate($courseId, $lessonId, Request $request)
    {
        $report = $request->except('format_text');
        $this->reportRepository->update($report, $report['id']);
        return response()->json([
            'message' => trans('common.messages.reports.update_success'),
            'id'      => $report['id']
        ]);
    }

    public function ajaxDestroy($courseId, $lessonId, Request $request)
    {
        $id = $request->get("id");
        $report = $this->reportRepository->find($id);

        $message = trans('common.messages.reports.delete_success');
        if ($report->lesson_id == $lessonId) {
            $this->reportRepository->delete();
        } else {
            $message = trans('common.messages.something_wrong');
        }
        return response()->json($message);
    }
}
