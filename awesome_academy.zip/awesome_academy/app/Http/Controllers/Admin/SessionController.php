<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use Auth;
use App\Repositories\AdminRepository as Admin;

class SessionController extends BaseController
{
    private $adminRepository;

    public function __construct(Admin $adminRepository)
    {
        parent::__construct();
        $this->middleware('guest', ['except' => ['getLogout']]);

        $this->adminRepository = $adminRepository;
    }

    public function getLogin()
    {
        return view('admins/login');
    }

    public function postLogin(Request $request)
    {
        $this->validate($request, [
            'email'    => 'required|email',
            'password' => 'required',
        ]);

        $credentials = $request->only('email', 'password');

        if (Auth::admin()->attempt($credentials, $request->has('remember'))) {
            return redirect('');
        }

        return redirect('admin/login')
            ->withInput($request->only('email', 'remeber'))
            ->withErrors([
                'msg' => trans('common.messages.login_invalid'),
            ]
        );
    }

    public function getLogout()
    {
        Auth::admin()->logout();
        return redirect('admin/login');
    }
}
