<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Repositories\TeacherRepository;
use App\Events\NewTeacherCreated;

class TeacherController extends BaseController
{
    private $teacherRepository;

    public function __construct(TeacherRepository $teacherRepository)
    {
        parent::__construct();
        $this->middleware('auth.admin');

        $this->teacherRepository = $teacherRepository;
    }

    public function index()
    {
        $teachers = $this->teacherRepository
                    ->orderBy('full_name', 'ASC')
                    ->paginate(config('admin.record_per_page'));

        return view('admins.teachers.index', [
            'teachers'  => $teachers,
            'name'      => '',
            'action'    => 'Admin\TeacherController@index',
        ]);
    }

    public function postSearch(Request $request)
    {
        $input = $request->all();

        $validator = $this->teacherRepository->validatorSearch($input);
        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }

        $limit = config('common.teacher_per_page');
        $teachers = $this->teacherRepository->searchTeacherByConditions($input['input'], $limit);

        return view('admins.teachers.index',[
            'teachers'  => $teachers,
            'name'      => $input['input'],
            'action'    => 'Admin\TeacherController@getSearch',
        ]);

    }

    public function create(Request $request)
    {
        return view('admins.teachers.create', [
            'title'     => trans('common.labels.create_teacher'),
            'action'    => 'Admin\TeacherController@store',
            'method'    => 'post',
        ]);
    }

    public function store(Request $request)
    {
        $teacher = $request->all();
        $validator = $this->teacherRepository->validatorCreate($teacher);

        if ($validator->fails()) {
            $this->throwValidationException(
                $request, $validator
            );
        }
        $result = $this->teacherRepository->create($teacher);
        if ($result) {
            $data = [
                'email' => $teacher['email'],
            ];
            event(new NewTeacherCreated($data));

            return redirect(action('Admin\TeacherController@index'))->with([
                'message'   => trans('common.messages.teacher_create_success'),
                'result'    => 'success',
            ]);
        }

        return redirect(action('Admin\TeacherController@index'))->with([
            'message'   => trans('common.messages.teacher_create_failed'),
        ]);
    }

 }
