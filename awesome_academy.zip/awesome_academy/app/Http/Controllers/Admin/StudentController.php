<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Repositories\StudentRepository;

class StudentController extends BaseController
{
    private $studentRepository;

    public function __construct(StudentRepository $studentRepository)
    {
        parent::__construct();
        $this->middleware('auth.admin');

        $this->studentRepository = $studentRepository;
    }

    public function index()
    {
        $students = $this->studentRepository
                    ->orderBy('full_name', 'ASC')
                    ->paginate(config('admin.record_per_page'));
        $students->load(['courses']);

        return view('admins/students/index', [
            'students' => $students,
            'gender' => get_genders(),
        ]);
    }
 }
