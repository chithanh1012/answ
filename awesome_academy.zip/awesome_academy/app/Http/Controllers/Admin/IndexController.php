<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

class IndexController extends BaseController
{
    public function __construct()
    {
        parent::__construct();
        $this->middleware('auth.admin');
    }

    public function index()
    {
        return view('welcome');
    }
 }
