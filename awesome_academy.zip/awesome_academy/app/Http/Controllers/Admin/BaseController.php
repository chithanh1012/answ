<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;

class BaseController extends Controller
{
    public function __construct()
    {
        parent::__construct();

        view()->share([
            'moduleName' => 'admin',
            'modulePath' => '/admin/',
            'mainColor' => config('common.main_color_admin'),
            'menus' => [
                'courses' => ['name' => trans('common.menus.courses'), 'url' => '/admin/courses'],
                'teachers' => ['name' => trans('common.menus.teachers'), 'url' => '/admin/teachers'],
                'students' => ['name' => trans('common.menus.students'), 'url' => '/admin/students'],
            ],
        ]);
    }
}
