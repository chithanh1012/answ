<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Repositories\CourseRepository;

class CourseController extends BaseController
{
    private $courseRepository;

    public function __construct(CourseRepository $courseRepository)
    {
        parent::__construct();
        $this->middleware('auth.admin');

        $this->courseRepository = $courseRepository;
    }

    public function index()
    {
        $courses = $this->courseRepository
                        ->orderBy('created_at', 'DESC')
                        ->paginate(config('admin.record_per_page'));
        $courses->load(['lessons', 'students']);

        return view('admins/courses/index', [
            'courses' => $courses,
        ]);
    }
}
