<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| Here is where you can register all of the routes for an application.
| It's a breeze. Simply tell Laravel the URIs it should respond to
| and give it the controller to call when that URI is requested.
|
*/

Route::group(['prefix' => 'media'], function() {
    post('upload', 'MediaController@upload');
    get('download/{mediaId}', 'MediaController@download')->where('mediaId', '^[0-9]+$');
    delete('destroy/{mediaId}', 'MediaController@destroy')->where('mediaId', '^[0-9]+$');
    get('show/{mediaId}', 'MediaController@show')->where('mediaId', '^[0-9]+$');
});

Route::group(['namespace' => 'Admin', 'prefix' => 'admin'], function() {
    get('login', 'SessionController@getLogin');
    post('login', 'SessionController@postLogin');
    get('logout', 'SessionController@getLogout');

    get('/', 'IndexController@index');

    get('courses', 'CourseController@index');

    get('/teachers', 'TeacherController@index');
    post('/teachers', 'TeacherController@postSearch');

    get('/teachers/create', 'TeacherController@create');
    post('/teachers/store', 'TeacherController@store');

    get('students', 'StudentController@index');
    get('logs', ['middleware' => 'auth.admin', 'uses' => '\Rap2hpoutre\LaravelLogViewer\LogViewerController@index']);

});

Route::group(['namespace' => 'Teacher', 'prefix' => 'teacher'], function() {
    get('login', 'SessionController@getLogin');
    post('login', 'SessionController@postLogin');
    get('logout', 'SessionController@getLogout');

    get('signup', 'SessionController@getSignup');
    post('signup', 'SessionController@postSignup');

    get('/', 'CourseController@index');
    get('/courses/assistant', 'CourseController@courseAssistant');
    Route::resource('courses', 'CourseController');
    post('search', 'TeacherController@ajaxSearch');

    get('change-password', 'TeacherController@getChangePassword');
    post('change-password', 'TeacherController@postChangePassword');

    Route::get('update-profile', 'TeacherController@getUpdateProfile');
    Route::post('update-profile', 'TeacherController@postUpdateProfile');

    // Password reset link request routes
    get('password/email', 'PasswordController@getEmail');
    post('password/email', 'PasswordController@postEmail');

    // Password reset routes
    get('password/reset/{token}', 'PasswordController@getReset');
    post('password/reset', 'PasswordController@postReset');

    // User set password to login
    get('activate-account/{token}', 'PasswordController@getSetPassword');
    post('activate-account', 'PasswordController@postSetPassword');


    Route::group(['prefix' => 'courses/{course_id}', 'middleware' => 'auth.teacher'], function() {
        get('{tab}', 'CourseController@show')
            ->where('tab', '^(lessons|students|messages|assistants|sentmessages)$');

        post('search', 'CourseController@postSearch');
        post('invite', 'CourseController@postInvite');
        post('cancel', 'CourseController@postCancelInvite');
        post('invite_students', 'CourseController@postInviteStudents');
        post('memo', 'CourseController@postMemo');
        put('active', 'CourseController@courseStudentActive');

        Route::resource('lessons', 'LessonController');
        post('lessons/generate', 'LessonController@generate');

        Route::group(['prefix' => 'lessons/{lesson_id}'], function() {
            get('{tab}', 'LessonController@show')
                ->where('tab', '^(files|students|reports|messages)$');
            post('report/add', 'ReportController@ajaxStore');
            put('report/update', 'ReportController@ajaxUpdate');
            delete('report/delete', 'ReportController@ajaxDestroy');

            get('reports/{reportId}', 'ReportStudentController@show');
        });
    });
});

Route::group(['namespace' => 'Student'], function() {
    get('login', 'SessionController@getLogin');
    post('login', 'SessionController@postLogin');
    get('auto_login', 'SessionController@getAutoLogin');
    get('logout', 'SessionController@getLogout');

    get('signup', 'SessionController@getSignup');
    post('signup', 'SessionController@postSignup');

    get('/', 'DashboardController@index');
    get('reload', 'DashboardController@reload');

    Route::group(['prefix' => 'courses/{course_id}', 'middleware' => 'auth.student'], function() {
        get('/', 'CourseController@show');
        post('/', 'CourseStudentController@store');
        get('{tab}', 'CourseController@show')->where('tab', '^(lessons|students|messages|teachermessages)$');
        get('/join/{code}', 'CourseStudentController@join')->where(['code' => '^[0-9a-z]+$']);

        Route::group(['prefix' => 'lessons/{lesson_id}'], function() {
            get('/', 'LessonController@show')->where(['lessonId' => '^[0-9]+$']);
            get('{tab}', 'LessonController@show')->where('tab', '^(files|reports|messages)$');
            post('/store', 'LessonController@store')->where(['lessonId' => '^[0-9]+$']);

            Route::group(['prefix' => 'reports/{reportId}'], function() {
                get('submit', 'ReportStudentController@create')->where([
                    'lessonId' => '^[0-9]+$',
                    'reportId' => '^[0-9]+$'
                ]);
                post('submit', 'ReportStudentController@store')->where([
                    'lessonId' => '^[0-9]+$',
                    'reportId' => '^[0-9]+$'
                ]);
            });
        });
    });
});

post('courses/{courseId}/messages/{role?}', 'MessageController@course')->where([
    'courseId' => '^[0-9]+$',
    'role'     => 'teacher'
]);
post('courses/{courseId}/lesson/{lessonId}/messages', 'MessageController@lesson')->where([
    'courseId' => '^[0-9]+$',
    'lessonId' => '^[0-9]+$'
]);
