<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Contracts\Auth\Guard;
use Auth;

class RedirectIfAuthenticated
{
    /**
     * The Guard implementation.
     *
     * @var Guard
     */
    protected $admin;
    protected $teacher;
    protected $student;

    /**
     * Create a new filter instance.
     *
     * @param  Guard  $auth
     * @return void
     */
    public function __construct()
    {
        $this->admin = Auth::admin();
        $this->teacher = Auth::teacher();
        $this->student = Auth::student();
    }

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        // if user is not guest then redirect url '/'
        if ($this->admin->check() || $this->teacher->check() || $this->student->check()) {
            return redirect('/');
        }

        return $next($request);
    }
}
