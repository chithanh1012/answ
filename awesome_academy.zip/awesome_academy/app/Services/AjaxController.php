<?php

namespace App\Services;

trait AjaxController
{
    public function responseAjax($data, $status)
    {
        if (is_string($data)) {
            $data = [
                'message' => $data,
            ];
        }
        return response()->json($data, $status);
    }

    public function responseAjaxSuccess($data = '')
    {
        return $this->responseAjax($data, 200);
    }

    public function responseAjaxFailed($data = '')
    {
        return $this->responseAjax($data, 400);
    }
}
