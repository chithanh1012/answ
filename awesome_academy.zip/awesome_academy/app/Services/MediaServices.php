<?php
namespace App\Services;

use App\Models\Media;
use App\Repositories\MediaRepository;

class MediaServices
{
    public static function updateLessonMedia($input, $lessonId)
    {
        self::updateMedia($input, $lessonId, Media::OBJECT_TYPE_LESSON);
    }

    public static function updateReportStudentMedia($input, $reportId)
    {
        self::updateMedia($input, $reportId, Media::OBJECT_TYPE_REPORT_STUDENT);
    }

    public static function updateMedia($input, $objectId, $objectType)
    {
        $mediaIds = $input['media_id'];
        $mediaStatuses = $input['media_status'];
        $mediaExpiredDates = array_get($input, 'media_expired_date', []);

        for ($i = 0; $i < count($mediaIds); $i++) {
            $mediaRepository = new MediaRepository();
            $mediaId = $mediaIds[$i];
            $mediaStatus = $mediaStatuses[$i];
            $mediaExpiredDate = array_get($mediaExpiredDates, $i, '');

            if ($mediaStatus === 'removed') {
                $mediaRepository->delete($mediaId);
            } else {
                $mediaData['object_id'] = $objectId;
                $mediaData['object_type'] = $objectType;
                $mediaData['expired_date'] = $mediaExpiredDate;
                $mediaRepository->update($mediaData, $mediaId);
            }
        }
    }
}
