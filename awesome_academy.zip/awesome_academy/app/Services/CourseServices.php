<?php
namespace App\Services;

class CourseServices
{
    public static function getLessonList($lessons)
    {
        $listLessons = [];
        foreach ($lessons as $lesson) {
            $date = $lesson->start_date->format('Y-m-d');
            $listLessons[$date] = $lesson->id;
        }
        return $listLessons;
    }

    public static function getStudentArray($students, $attendedStudents)
    {
        $students = $students->toArray();
        $attendedStudents = $attendedStudents->toArray();
        $attendedListId = array_column($attendedStudents, 'student_id');

        foreach ($students as $key => $student) {
            if (in_array($student['id'], $attendedListId)) {
                $students[$key]['attendedInfo'] = $attendedStudents[array_search($student['id'], $attendedListId)];
            }
        }
        return $students;
    }
}
