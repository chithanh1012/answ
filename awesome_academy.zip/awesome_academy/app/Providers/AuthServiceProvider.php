<?php

namespace App\Providers;

use Illuminate\Contracts\Auth\Access\Gate as GateContract;
use Illuminate\Foundation\Support\Providers\AuthServiceProvider as ServiceProvider;

class AuthServiceProvider extends ServiceProvider
{
    /**
     * The policy mappings for the application.
     *
     * @var array
     */
    protected $policies = [
        'App\Model' => 'App\Policies\ModelPolicy',
    ];

    /**
     * Register any application authentication / authorization services.
     *
     * @param  \Illuminate\Contracts\Auth\Access\Gate  $gate
     * @return void
     */
    public function boot(GateContract $gate)
    {
        parent::registerPolicies($gate);

        $gate->define('course-owner', function($teacher, $course) {
            $assistants = $course->courseAssistants->lists('teacher_id')->toArray();
            return $teacher->id === $course->teacher_id || in_array($teacher->id, $assistants);
        });

        $gate->define('view-lesson', function($user, $courseId) {
            if ($user->isTeacher() && $user->isCourseOwner($courseId)) {
                return true;
            } elseif ($user->isStudent()) {
                return $user->isJoinedCourse($courseId);
            }
            return false;
        });

        $gate->define('check-attendance', function($user, $lesson) {
            if ($user->isStudent()) {
                return $lesson->canCheckAttendance($user->id);
            }
            return false;
        });

        $gate->define('submit-report', function($student, $report, $lesson) {
            return $lesson->isStarted() && !$report->isExpired();
        });

        $gate->define('view-lesson-student-message', function($user, $course) {
            $assistants = $course->courseAssistants->lists('teacher_id')->toArray();
            return ($user->isStudent() && $user->isJoinedCourse($course->id)) ||
                   ($user->isTeacher() && $user->isCourseOwner($course->id)) ||
                   in_array($user->id, $assistants);
        });

        $gate->define('student-view-course', function($user, $course, $joined, $viewable) {
            if ($course->register_type && !$joined) {
                return false;
            }

            return ($joined || $course->isInPublicTime()) && $viewable;
        });
    }
}
