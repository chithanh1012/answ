<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Auth;
use Validator;
use Hash;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {
        Validator::extend('password_compare', function($attribute, $values, $parameters, $input) {
            $input = $input->getData();
            if (!Hash::check($input['old_password'], Auth::user()->password)) {
                return false;
            }
            return true;
        });
    }

    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
