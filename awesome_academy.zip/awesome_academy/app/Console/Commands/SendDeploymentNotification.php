<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use Symfony\Component\Console\Input\InputOption;
use wataridori\ChatworkSDK\ChatworkRoom;
use wataridori\ChatworkSDK\ChatworkSDK;
use wataridori\ChatworkSDK\ChatworkUser;

class SendDeploymentNotification extends Command
{
    const MODE_UPDATE = 'Update';
    const MODE_DEPLOY = 'Deploy';

    const RECEIVER_NONE = 'None';
    const RECEIVER_ALL = 'All';

    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'notify:deployment {--mode=Update} {--status=Deploying} {--environment=Staging} {--receivers=}';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send Deployment Notification via Chatwork';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $mode = $this->option('mode');
        $status = $this->option('status');
        $environment = $this->option('environment');

        $members = [];
        $receivers = $this->option('receivers');
        if (!$receivers) {
            $receivers = env('CHATWORK_RECEIVER_ID');
        }
        if ($receivers && $receivers !== self::RECEIVER_ALL && $receivers !== self::RECEIVER_NONE) {
            $receivers = explode(',', $receivers);
            $members = array_map(function($m) {
                $m = trim($m);
                if (is_numeric($m)) {
                    return new ChatworkUser($m);
                }
            }, $receivers);
        }

        $roomId = env('CHATWORK_ROOM_ID');
        $apiKey = env('CHATWORK_API_KEY');
        ChatworkSDK::setApiKey($apiKey);
        $room = new ChatworkRoom($roomId);
        $message = "Mode: $mode\nEnvironment: $environment\nStatus: $status";
        $message = $room->buildInfo($message, 'Deployment Information');
        if ($receivers === self::RECEIVER_ALL) {
            $room->sendMessageToAll($message, false, false);
        } elseif ($receivers === self::RECEIVER_NONE) {
            $room->sendMessage($message);
        } else {
            $room->sendMessageToList($members, $message, false, false);
        }
    }
}
