<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Repositories\StudentRepository;
use App\Repositories\CourseStudentRepository;
use App\Repositories\CourseRepository;

class ImportStudentsToCourse extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:students-to-courses';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Student to Course from CSV file.';

    protected $studentRepository;

    protected $courseRepository;

    protected $courseStudentRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(
        StudentRepository $studentRepository,
        CourseStudentRepository $courseStudentRepository,
        CourseRepository $courseRepository
    ){
        parent::__construct();

        $this->studentRepository = $studentRepository;
        $this->courseStudentRepository = $courseStudentRepository;
        $this->courseRepository = $courseRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->comment(PHP_EOL . $this->importStudentsToCourse() . PHP_EOL);
    }

    public function importStudentsToCourse()
    {
        $path = storage_path('import_files/import_students_to_courses.csv');
        $students = $this->readCsvFile($path);

        foreach ($students as $key => $student) {
            if ($student[1]) {
                $courseId = $student[0];
                $this->studentRepository->makeModel(true);
                if ($this->studentRepository->findStudentIdByIdentityNumber($student[1])) {
                    if ($this->courseRepository->courseIsExits($courseId)) {
                        $this->courseStudentRepository->makeModel(true);
                        $studentId = $this->studentRepository->findStudentIdByIdentityNumber($student[1], true);
                        if (!$this->courseStudentRepository->findByCourseIdByStudentId($courseId, $studentId)) {
                            $data = [
                                'course_id' => $courseId,
                                'student_id' => $studentId,
                            ];
                            $this->courseStudentRepository->makeModel(true);
                            $this->courseStudentRepository->create($data);
                        }
                    }
                } else {
                    $this->info('Student Number = ' . $student[1] . ' not exits.');
                }
            }
        }
    }

    private function readCsvFile($filename = '', $delimiter = ',', $length = 1000)
    {
        if (!file_exists($filename) || !is_readable($filename)) {
            return false;
        }

        $header = null;
        $data = [];
        if (($handle = fopen($filename, 'r')) !== false) {
            while (($row = fgetcsv($handle, $length, $delimiter)) !== false)
            {
                $data[] = $row;
            }
            fclose($handle);
        }

        return $data;
    }
}
