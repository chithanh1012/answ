<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Carbon\Carbon;
use App\Services\SendGridService;

class TeacherSendEmailStudents extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'teacher:send-email
        {--subject=}
        {--email=}
        {--data=}
        {--template=}
    ';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Teacher sent email to Students.';

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->comment(PHP_EOL . $this->teacherSendEmailStudents() . PHP_EOL);
    }

    public function teacherSendEmailStudents()
    {

        $subject = $this->option('subject');
        $emails = json_decode($this->option('email'), true);
        $data = json_decode($this->option('data'), true);
        $template = $this->option('template');
        foreach ($emails as $emailStudent) {
            $this->sendEmail($subject, $emailStudent, $data, $template);
        }

        $this->info($this->description);
    }

    private function sendEmail($subject, $email, $data, $template)
    {
        $mail = new SendGridService();
        $mail->setTo($email)
             ->setSubject(trans($subject))
             ->setData(['data' => $data])
             ->setLayout($template);
        $mail->send();
    }
}
