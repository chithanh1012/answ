<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Repositories\LessonRepository;
use Carbon\Carbon;
use App\Services\SendGridService;

class SendReminderEmail extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'send-lesson-start-email';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Send lesson start email.';

    private $lessonRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(LessonRepository $lessonRepository)
    {
        parent::__construct();

        $this->lessonRepository = $lessonRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->comment(PHP_EOL . self::sendReminderEmailLessons() . PHP_EOL);
    }

    public function sendReminderEmailLessons()
    {
        $lessons = $this->lessonRepository->getTodayLessons();

        foreach ($lessons as $lesson) {
            $studentEmails = $lesson->course->students->fetch('email')->all();
            foreach ($studentEmails as $email) {
                $this->sendEmail($email, $lesson);
            }

            $teacherEmail = $lesson->course->teacher->email;
            $this->sendEmail($teacherEmail, $lesson, true);
        }
        $this->info($this->description);
    }

    private function sendEmail($emails, $lesson, $isTeacher = false)
    {
        $mail = new SendGridService();
        $mail->setTo($emails)
             ->setSubject(trans('common.labels.title_mail_lesson'))
             ->setData(['lesson' => $lesson, 'isTeacher' => $isTeacher])
             ->setLayout('layouts.emails.reminder');
        $mail->send();
    }
}
