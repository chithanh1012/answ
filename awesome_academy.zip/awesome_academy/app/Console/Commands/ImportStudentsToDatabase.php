<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Repositories\StudentRepository;

class ImportStudentsToDatabase extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'import:student';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Import Student to Database from CSV file.';

    protected $studentRepository;

    /**
     * Create a new command instance.
     *
     * @return void
     */
    public function __construct(StudentRepository $studentRepository)
    {
        parent::__construct();

        $this->studentRepository = $studentRepository;
    }

    /**
     * Execute the console command.
     *
     * @return mixed
     */
    public function handle()
    {
        $this->comment(PHP_EOL . $this->importStudentsToDatabase() . PHP_EOL);
    }

    public function importStudentsToDatabase()
    {
        $path = storage_path('import_files/import_students.csv');
        $students = $this->readCsvFile($path);
        $data = [
            0 => ['identity_nubmer', 'full_name', 'email', 'birthday', 'password'],
        ];

        foreach ($students as $key => $student) {
            $i = count($data);
            $this->studentRepository->makeModel(true);
            if (!$this->studentRepository->findStudentByEmail($student['email'])) {
                $this->studentRepository->makeModel(true);
                $password = str_random(8);
                $student['password'] = bcrypt($password);
                $result = $this->studentRepository->create($student);
                $student['password'] = $password;
                if ($result) {
                    $data[$key + 1] = $student;
                }
            }
        }

        if (count($data) > 1) {
            $pathResult = $path = storage_path('import_files/result_import_students.csv');
            $this->writeCsvFile($pathResult, $data);
            $this->info($this->description);
        } else {
            $this->info('Nothing import.');
        }
    }

    private function readCsvFile($filename = '', $delimiter = ',', $length = 1000)
    {
        if (!file_exists($filename) || !is_readable($filename)) {
            return false;
        }

        $header = null;
        $data = [];
        if (($handle = fopen($filename, 'r')) !== false) {
            while (($row = fgetcsv($handle, $length, $delimiter)) !== false)
            {
                if (!$header) {
                    $header = $row;
                } else {
                    $data[] = array_combine($header, $row);
                }
            }
            fclose($handle);
        }

        return $data;
    }

    private function writeCsvFile($filename, $data)
    {
        $filePut = fopen($filename, 'w');

        foreach ($data as $fields) {
            fputcsv($filePut, (array) $fields);
        }
        fclose($filePut);
    }
}
