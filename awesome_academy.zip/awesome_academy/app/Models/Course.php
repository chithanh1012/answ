<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Parsedown;

class Course extends Model
{
    protected $table = 'courses';
    protected $fillable = [
        'name', 'desc', 'content', 'location', 'max_students', 'register_type', 'teacher_id',
        'time_table', 'publish_started_at', 'publish_ended_at',
    ];
    protected $dates = ['publish_started_at', 'publish_ended_at'];

    const REGISTER_TYPE_OPEN = 0;
    const REGISTER_TYPE_INVITE = 1;

    const STATUS_WAITING        = 'waiting';
    const STATUS_IN_PROGRESS    = 'in_progress';
    const STATUS_FINISHED       = 'finished';

    public function lessons()
    {
        return $this->hasMany(Lesson::class)->orderBy('start_date');
    }

    public function lessonsCount()
    {
        return $this->lessons()->selectRaw('course_id, count(*) as count')->groupBy('course_id');
    }

    public function getLessonsCount()
    {
        return $this->lessonsCount->first() ? $this->lessonsCount->first()->count : 0;
    }

    public function students()
    {
        return $this->belongsToMany(Student::class, 'course_students');
    }

    public function courseStudents()
    {
        return $this->hasMany(CourseStudent::class);
    }

    public function studentsCount()
    {
        return $this->courseStudents()->selectRaw('course_id, count(*) as count')->groupBy('course_id');
    }

    public function getStudentsCount()
    {
        return $this->studentsCount->first() ? $this->studentsCount->first()->count : 0;
    }

    public function teacher()
    {
        return $this->belongsTo(Teacher::class);
    }

    public function assistantTeachers()
    {
        return $this->belongsToMany(Teacher::class, 'course_assistants');
    }

    public function courseAssistants()
    {
        return $this->hasMany(CourseAssistant::class);
    }

    public function invitationStudents()
    {
        return $this->belongsToMany(Student::class, 'course_invitations');
    }

    public function waitingJoinStudents()
    {
        return $this->invitationStudents()->where('used', false);
    }

    public function setTimeTableAttribute($value)
    {
        $this->attributes['time_table'] = json_encode($value);
    }

    public function getTimeTableAttribute($value)
    {
        return json_decode($value);
    }

    public function isOpenRegister()
    {
        return $this->register_type == self::REGISTER_TYPE_OPEN;
    }

    public function hasFreeSlot()
    {
        return !$this->max_students || $this->max_students > $this->students()->count();
    }

    public function getParsedContent()
    {
        $markdown = new Parsedown();
        return $markdown->text($this->content);
    }

    public function getTimeTable()
    {
        $timeTables = $this->time_table;
        $timeTableText = $timeTables[0]->start_time . ' - ' . $timeTables[0]->end_time .
            ' (' .trans('common.courses.every') . ' ' . get_day_options()[strtolower($timeTables[0]->day)] . ')';

        return $timeTableText;
    }

    public function messages()
    {
        return $this->hasMany(Message::class);
    }

    public function messagesCount()
    {
        return $this->messages()
                    ->selectRaw('course_id, count(*) as count')
                    ->where('reply_to', 0)
                    ->where('lesson_id', 0)
                    ->groupBy('course_id');
    }

    public function getMessagesCount()
    {
        return $this->messagesCount->first() ? $this->messagesCount->first()->count : 0;
    }

    public function reports()
    {
        return $this->hasManyThrough(Report::class, Lesson::class);
    }

    public function nextLesson()
    {
        return $this->hasOne(Lesson::class)
                    ->where(function($query) {
                        $query->where('lessons.start_date', '>', Carbon::today());
                        $query->orWhere(function ($query) {
                            $query->where('lessons.start_date', Carbon::today())
                                  ->where('lessons.start_time', '>', Carbon::now()->toTimeString());
                        });
                    })
                    ->orderBy('lessons.start_date')
                    ->orderBy('lessons.start_time');
    }

    public function getNextLessonLocation()
    {
        return $this->nextLesson ? ($this->nextLesson->location ?: $this->location) : '';
    }

    public function getNextLessonDay()
    {
        return $this->nextLesson ? get_day_options()[strtolower($this->nextLesson->start_date->format('D'))] : '';
    }

    public function getNextLessonTime()
    {
        if (!$this->nextLesson) {
            return '';
        }

        return $this->nextLesson->start_time->format('H:i') . ' - ' . $this->nextLesson->end_time->format('H:i');
    }

    public function currentLesson()
    {
        return $this->hasOne(Lesson::class)
                    ->where('lessons.start_date', '=', Carbon::today())
                    ->where('lessons.start_time', '<=', Carbon::now()->toTimeString())
                    ->where('lessons.end_time', '>=', Carbon::now()->toTimeString())
                    ->orderBy('lessons.start_date')
                    ->orderBy('lessons.start_time');
    }

    public function getCurrentLessonLocation()
    {
        return $this->currentLesson ? ($this->currentLesson->location ?: $this->location) : '';
    }

    public function getCurrentLessonDay()
    {
        return $this->currentLesson ? get_day_options()[strtolower($this->currentLesson->start_date->format('D'))] : '';
    }

    public function getCurrentLessonTime()
    {
        if (!$this->currentLesson) {
            return '';
        }

        return $this->currentLesson->start_time->format('H:i') . ' - ' . $this->currentLesson->end_time->format('H:i');
    }

    public function getStatus()
    {
        $today = Carbon::now();

        if ($today->lt($this->publish_started_at)) {
            return self::STATUS_WAITING;
        } elseif ($today->gte($this->publish_started_at) && $today->lte($this->publish_ended_at)) {
            return self::STATUS_IN_PROGRESS;
        } else {
            return self::STATUS_FINISHED;
        }
    }

    public function isInPublicTime()
    {
        $today = Carbon::now();

        return $today->gte($this->publish_started_at) && $today->lte($this->publish_ended_at);
    }
}
