<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Participant extends Model
{
    protected $table = 'participants';
    protected $fillable = ['lesson_id', 'student_id', 'user_agent', 'ip_address'];

    public function student()
    {
        return $this->belongsTo(Student::class);
    }

}
