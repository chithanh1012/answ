<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;

class Report extends Model
{
    protected $table = 'reports';
    protected $fillable = ['name', 'lesson_id', 'format', 'desc', 'due_date'];
    protected $dates = ['due_date'];

    const REPORT_FORMAT_TEXT = 1;
    const REPORT_FORMAT_FILE = 2;

    public function lesson()
    {
        return $this->belongsTo(Lesson::class);
    }

    public function reportStudents()
    {
        return $this->hasMany(ReportStudent::class);
    }

    public function isTextFormat()
    {
        return $this->format == $this::REPORT_FORMAT_TEXT;
    }

    public function getStudentSubmitedTime($studentId)
    {
        $submitedReport = $this->reportStudents()
                               ->where('report_students.student_id', $studentId)
                               ->first();
        return $submitedReport ? $submitedReport->updated_at->format('d/m/Y') : $this->updated_at;
    }

    public function isExpired()
    {
        return $this->due_date->endOfDay()->lt(Carbon::now());
    }
}
