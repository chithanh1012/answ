<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Kbwebs\MultiAuth\PasswordResets\CanResetPassword;
use Kbwebs\MultiAuth\PasswordResets\Contracts\CanResetPassword as CanResetPasswordContract;
use Carbon\Carbon;
use Illuminate\Foundation\Auth\Access\Authorizable;

class Student extends Model implements AuthenticatableContract, CanResetPasswordContract
{
    use Authenticatable, CanResetPassword, UserTrait, Authorizable;

    protected $table = 'students';

    protected $fillable = [
        'full_name', 'identity_number', 'email', 'password',
        'birthday', 'gender', 'admission_date', 'admission_date',
        'awesome_authentication_id',
    ];

    protected $hidden = ['password', 'remember_token'];

    public function courses()
    {
        return $this->belongsToMany(Course::class, 'course_students');
    }

    public function courseInvitations()
    {
        return $this->belongsToMany(Course::class, 'course_invitations')->orderBy('created_at', 'DESC');
    }

    public function participants()
    {
        return $this->hasMany(Participant::class);
    }

    public function invitations()
    {
        return $this->hasMany(CourseInvitation::class);
    }

    public function reports() {
        return $this->belongsToMany(Report::class, 'report_students');
    }

    public function reportStudents()
    {
        return $this->hasMany(ReportStudent::class);
    }

    public function getCourseStatus($courseId)
    {
        $status = $this->invitations()
                       ->where('course_invitations.course_id', $courseId)
                       ->where('course_invitations.used', false)
                       ->first();
        return $status ? 'Waiting' : 'Joined';
    }

    public function isJoinedCourse($courseId)
    {
        return $this->courses()->where('courses.id', $courseId)
            ->exists();
    }

    public function canViewCourse($courseId)
    {
        return $this->courses()->where('courses.id', $courseId)
            ->where('course_students.is_active', true)
            ->exists();
    }

    public function isInvited($courseId)
    {
        $course = $this->invitations()->where('course_invitations.course_id', $courseId)->first();
        return $course ? true : false;
    }

    public function getInviteWithCode($courseId, $code = '')
    {
        $invite = $this->invitations()
                       ->where('course_invitations.course_id', $courseId)
                       ->where('course_invitations.code', $code)
                       ->where('course_invitations.used', false)
                       ->first();
        return $invite;
    }

    public function getCurrentCourses()
    {
        $now = Carbon::today();
        return $this->courses()->where('courses.publish_started_at', '<=', $now)
            ->where('courses.publish_ended_at', '>=', $now)
            ->where('course_students.is_active', true)
            ->orderBy('courses.created_at', 'DESC')
            ->paginate(config('student.dashboard_per_page'));
    }

    public function isSubmitedReport($reportId)
    {
        return $this->reportStudents()
                    ->where('report_students.report_id', $reportId)
                    ->exists();
    }
}
