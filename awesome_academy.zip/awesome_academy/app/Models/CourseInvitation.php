<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class CourseInvitation extends Model
{
    protected $table = 'course_invitations';
    protected $fillable = ['course_id', 'student_id', 'code', 'used'];
}
