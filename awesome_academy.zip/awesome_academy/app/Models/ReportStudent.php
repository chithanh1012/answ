<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class ReportStudent extends Model
{
    protected $table = 'report_students';
    protected $fillable = ['student_id', 'report_id', 'content'];
    const REPORT_PER_PAGE = 12;

    public function media()
    {
        return $this->hasMany(Media::class, 'object_id')->where('object_type', Media::OBJECT_TYPE_REPORT_STUDENT);
    }

    public function student()
    {
        return $this->belongsTo(Student::class);
    }
}
