<?php

namespace App\Models;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Kbwebs\MultiAuth\PasswordResets\CanResetPassword;
use Kbwebs\MultiAuth\PasswordResets\Contracts\CanResetPassword as CanResetPasswordContract;
use Illuminate\Foundation\Auth\Access\Authorizable;

class Teacher extends Model implements AuthenticatableContract, CanResetPasswordContract
{
    use Authenticatable, CanResetPassword, UserTrait, Authorizable;

    protected $table = 'teachers';

    protected $fillable = ['full_name', 'email', 'password'];

    protected $hidden = ['password', 'remember_token'];

    public function courses()
    {
        return $this->hasMany(Course::class);
    }

    public function isCourseOwner($courseId)
    {
        return $this->courses()->where('courses.id', $courseId)->exists();
    }

    public function courseAssistants()
    {
        return $this->belongsToMany(Course::class, 'course_assistants');
    }
}
