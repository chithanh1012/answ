<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Carbon\Carbon;
use Parsedown;

class Lesson extends Model
{
    const STATUS_DONE       = 'done';
    const STATUS_PROGRESS   = 'progress';
    const STATUS_PENDING    = 'pending';

    protected $table = 'lessons';
    protected $fillable = ['course_id', 'desc', 'content', 'location', 'start_date', 'start_time', 'end_time', 'canceled'];
    protected $dates = ['start_date'];

    public function course()
    {
        return $this->belongsTo(Course::class);
    }

    public function students()
    {
        return $this->belongsToMany(Student::class, 'participants');
    }

    public function participants()
    {
        return $this->hasMany(Participant::class);
    }

    public function participantsCount()
    {
        return $this->participants()->selectRaw('lesson_id, count(*) as count')->groupBy('lesson_id');
    }

    public function getParticipantsCount()
    {
        return $this->participantsCount->first() ? $this->participantsCount->first()->count : 0;
    }

    public function reports()
    {
        return $this->hasMany(Report::class);
    }

    public function reportsCount()
    {
        return $this->reports()->selectRaw('lesson_id, count(*) as count')->groupBy('lesson_id');
    }

    public function getReportsCount()
    {
        return $this->reportsCount->first() ? $this->reportsCount->first()->count : 0;
    }

    public function messages()
    {
        return $this->hasMany(Message::class);
    }

    public function messagesCount()
    {
        return $this->messages()
                    ->selectRaw('lesson_id, count(*) as count')
                    ->where('reply_to', 0)
                    ->where('lesson_id', '<>', 0)
                    ->groupBy('lesson_id');
    }

    public function getMessagesCount()
    {
        return $this->messagesCount->first() ? $this->messagesCount->first()->count : 0;
    }

    public function media()
    {
        return $this->hasMany(Media::class, 'object_id')->where('object_type', Media::OBJECT_TYPE_LESSON);
    }

    public function notExpiredMedia()
    {
        return $this->media()
                    ->where('object_type', Media::OBJECT_TYPE_LESSON)
                    ->where(function ($query) {
                        $query->where('expired_date', '>=', Carbon::today()->toDateString())
                              ->orWhere('expired_date', '=', '0000-00-00');
                    });
    }

    public function getStartTimeAttribute($value)
    {
        if (!$value || $value === '00:00:00') {
            return null;
        }
        return Carbon::createFromFormat('H:i:s', $value);
    }

    public function getEndTimeAttribute($value)
    {
        if (!$value || $value === '00:00:00') {
            return null;
        }
        return Carbon::createFromFormat('H:i:s', $value);
    }

    public function getParsedDescription()
    {
        $markdown = new Parsedown();
        return $markdown->text($this->desc);
    }

    public function getParsedContent()
    {
        $markdown = new Parsedown();
        return $markdown->text($this->content);
    }

    public function canCheckAttendance($studentId)
    {
        $now = Carbon::now();
        return     $now->isSameDay($this->start_date)
                && $now->between($this->end_time, $this->start_time)
                && !$this->participants()
                         ->where('participants.student_id', $studentId)
                         ->exists();
    }

    public function getStatus()
    {
        $now = Carbon::now();
        $startTime = $this->getStartDateTime();
        $endTime = $this->getEndDateTime();

        if ($now->gt($endTime)) {
            return self::STATUS_DONE;
        } elseif ($now->gte($startTime) && $now->lte($endTime)) {
            return self::STATUS_PROGRESS;
        } else {
            return self::STATUS_PENDING;
        }
    }

    public function isStarted()
    {
        return $this->getStartDateTime()->lte(Carbon::now());
    }

    public function getStartDateTime()
    {
        return Carbon::parse($this->start_date->toDateString() . ' ' . $this->start_time->toTimeString());
    }

    public function getEndDateTime()
    {
        return Carbon::parse($this->start_date->toDateString() . ' ' . $this->end_time->toTimeString());
    }

    public function getLocation()
    {
        return $this->location ?: $this->course->location;
    }
}
