<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Media extends Model
{
    const OBJECT_TYPE_TEMPORARY = 'TEMPORARY';
    const OBJECT_TYPE_LESSON    = 'LESSON';
    const OBJECT_TYPE_REPORT_STUDENT = 'REPORT_STUDENT';

    protected $table = 'media';
    protected $fillable = ['file_name', 'url', 'object_id', 'object_type', 'expired_date'];
    protected $dates = ['expired_date'];
}
