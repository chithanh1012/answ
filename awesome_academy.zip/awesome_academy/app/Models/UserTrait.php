<?php

namespace App\Models;

trait UserTrait
{
    public function isStudent()
    {
        return $this instanceof Student;
    }

    public function isTeacher()
    {
        return $this instanceof Teacher;
    }

    public function isAdmin()
    {
        return $this instanceof Admin;
    }

    public function getModulePath()
    {
        return $this->isAdmin() ? '/admin/' : ($this->isTeacher() ? '/teacher/' : '/');
    }
}
