<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Validator;

class ParticipantRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\Participant::class;
    }


    public function findByStudentIdLessonId($studentId, $lessonId)
    {
        $participant = $this->where('student_id', $studentId)
                    ->where('lesson_id', $lessonId)
                    ->first();
        return !is_null($participant);
    }
}
