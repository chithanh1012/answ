<?php
namespace App\Repositories;

use App\Repositories\Repository;

class ReportRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\Report::class;
    }

    function validationRules()
    {
        $rules = [
            'name'      => 'required|max:255',
            'lesson_id' => 'required',
            'format'    => 'required',
            'desc'      => 'required',
            'due_date'  => 'required|date_format:"Y-m-d"',
        ];

        return [
            'create' => $rules,
            'update' => array_except($rules, 'lesson_id'),
        ];
    }

    public function createMutilpleReport($data, $lesson_id)
    {
        for ($i = 0; $i < count($data['name']); $i++) {
            $report = [];
            $report['lesson_id'] = $lesson_id;
            $report['name']      = $data['name'][$i];
            $report['desc']      = $data['desc'][$i];
            $report['format']    = $data['format'][$i];
            $report['due_date']  = $data['due_date'][$i];
            $this->create($report);
        }
    }
}
