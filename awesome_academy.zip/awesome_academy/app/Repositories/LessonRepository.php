<?php
namespace App\Repositories;

use App\Repositories\Repository;
use App\Repositories\MediaRepository;
use App\Models\Media;
use Carbon\Carbon;

class LessonRepository extends Repository
{
    private $mediaRepository;

    public function __construct(MediaRepository $mediaRepository)
    {
        parent::__construct();

        $this->mediaRepository = $mediaRepository;
    }

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\Lesson::class;
    }

    function validationRules()
    {
        $rules = [
            'desc'                  => 'max:255',
            'location'              => 'max:255',
            'start_date'            => 'required|date_format:"Y-m-d"',
            'start_time'            => 'required|date_format:"H:i"',
            'end_time'              => 'required|date_format:"H:i"|after:start_time',
        ];

        return [
            'create' => $rules,
            'update' => $rules,
        ];
    }

    function getLastLesson($courseId)
    {
        return $this->where('course_id', $courseId)
                    ->orderBy('start_date', 'DESC')
                    ->first();
    }

    function getNextStartDate($timeTableDay, $lastStartDate)
    {
        $dayOfWeek = Carbon::parse($timeTableDay)->dayOfWeek;
        return Carbon::parse($lastStartDate)->next($dayOfWeek);
    }

    function generateLessons($course, $startDate, $generateTimes)
    {
        $lessonStartDate = Carbon::parse($startDate);
        for ($i = 0; $i < $generateTimes; $i++) {
            $lesson = [
                'course_id'     => $course->id,
                'desc'          => '',
                'location'      => '',
                'start_date'    => $lessonStartDate->format('Y-m-d'),
                'start_time'    => $course->time_table[0]->start_time,
                'end_time'      => $course->time_table[0]->end_time,
            ];
            $this->create($lesson);

            $lessonStartDate = $this->getNextStartDate($course->time_table[0]->day, $lessonStartDate);
        }
    }

    function getTodayLessons()
    {
        $lessons = $this->where('start_date', Carbon::today())
            ->where('start_time', '>', Carbon::now()->toTimeString())
            ->orderBy('start_date')
            ->orderBy('start_time')->all();
        $lessons->load('course.students', 'course.teacher');

        return $lessons;
    }
}
