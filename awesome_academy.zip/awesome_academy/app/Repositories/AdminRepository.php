<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Validator;

class AdminRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\Admin::class;
    }
}
