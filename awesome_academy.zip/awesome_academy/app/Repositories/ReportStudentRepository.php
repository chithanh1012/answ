<?php
namespace App\Repositories;

use App\Repositories\Repository;

class ReportStudentRepository extends Repository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\ReportStudent::class;
    }

    function validationRules()
    {
        $rules = [
            'student_id' => 'required',
            'report_id'  => 'required',
        ];

        return [
            'create' => $rules,
        ];
    }
}
