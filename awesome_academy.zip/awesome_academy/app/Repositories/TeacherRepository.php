<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Validator;
use App\Models\Teacher;
use wataridori\SFS\SimpleFuzzySearch;
use App\Events\NewTeacherCreated;

class TeacherRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\Teacher::class;
    }

    function validatorSignup(array $data)
    {
        $validator = Validator::make($data, [
            'full_name'             => 'required|max:255',
            'email'                 => 'required|email|max:255|unique:teachers',
            'password'              => 'required|min:8|confirmed',
            'password_confirmation' => 'required'
        ]);

        return $validator;
    }

    public function searchTeacherByName($name, $currentTeacherId, $ownerTeacherId = '')
    {
        $teacherData = $this->all(['id', 'full_name'])->toArray();
        $sfs = new SimpleFuzzySearch($teacherData, ['full_name'], $name);
        $results = $sfs->search();
        if (!$results) {
            return [];
        }
        $ids = array_pluck($results, '0.id');

        $pos = array_search($currentTeacherId, $ids);
        if ($pos !== false) {
            unset($ids[$pos]);
        }

        $pos = array_search($ownerTeacherId, $ids);
        if ($ownerTeacherId && $pos !== false) {
            unset($ids[$pos]);
        }
        return Teacher::whereIn('id', $ids)->get();
    }

    function validatorChangePassword(array $data)
    {
        $messages = [
            'old_password.password_compare' => trans('teachers.messages.old_password_invalid')
        ];
        $validator = Validator::make(
            $data,
            [
                'old_password'          => 'required|password_compare',
                'password'              => 'required|min:8|confirmed',
                'password_confirmation' => 'required',
            ],
            $messages
        );

        return $validator;
    }

    function validatorUpdateProfile(array $data)
    {
        $this->makeModel(true);
        $validator = Validator::make($data, [
            'full_name' => 'required|max:255',
        ]);

        return $validator;
    }

    public function getTeachers($limit = 12)
    {
        return $this->orderBy('created_at', 'DESC')
                    ->paginate($limit);
    }

    function validatorSearch(array $data)
    {
        $validator = Validator::make($data, [
            'input' => 'required|max:255',
        ]);

        return $validator;
    }

    public function searchTeacherByConditions($name, $limit = 12)
    {
        return Teacher::where('full_name', 'like', '%' . $name . '%')
                    ->orWhere('email', 'like', '%' . $name . '%')
                    ->orderBy('full_name')
                    ->paginate($limit);
    }

    function validatorCreate(array $data)
    {
        $validator = Validator::make($data, [
            'full_name'         => 'required|max:255',
            'email'             => 'required|email|max:255|unique:teachers',
        ]);

        return $validator;
    }

    public function checkEmailExists($email)
    {
        return Teacher::where('email', $email)->exists();
    }
}
