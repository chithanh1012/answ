<?php
namespace App\Repositories;

use App\Repositories\Repository;

class CourseRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return \App\Models\Course::class;
    }

    public function updateValidationRules($minStudentNumber)
    {
        $this->validationRules = $this->validationRules($minStudentNumber);
    }

    public function validationRules($minStudentNumber = 1)
    {
        $rules = [
            'name'                  => 'required|max:255',
            'desc'                  => 'required|max:255',
            'max_students'          => "integer|min:$minStudentNumber|max:255",
            'location'              => 'required|max:255',
            'day'                   => 'required',
            'start_time'            => 'required|date_format:"H:i"',
            'end_time'              => 'required|date_format:"H:i"|after:start_time',
            'publish_started_at'    => 'required|date_format:"Y-m-d"',
            'publish_ended_at'      => 'required|date_format:"Y-m-d"|after:publish_started_at',
        ];

        return [
            'create' => $rules,
            'update' => $rules,
        ];
    }

    public function isRegisterable($id)
    {
        $course = $this->find($id);
        return $course->isOpenRegister();
    }

    public function courseIsExits($id)
    {
        return !is_null($this->find($id));
    }
}
