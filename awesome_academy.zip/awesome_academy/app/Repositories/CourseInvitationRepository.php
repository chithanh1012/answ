<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Validator;

class CourseInvitationRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\CourseInvitation::class;
    }
}
