<?php
namespace App\Repositories;

use App\Repositories\Repository;

class MediaRepository extends Repository
{
    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\Media::class;
    }
}
