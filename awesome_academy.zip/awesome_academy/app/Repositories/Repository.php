<?php

namespace App\Repositories;

use App\Repositories\Contracts\RepositoryInterface;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Collection;
use Illuminate\Container\Container as App;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Request;
use Event;
use Validator;

abstract class Repository implements RepositoryInterface
{
    use ValidatesRequests;

    /**
     *
     * @var $app
     */
    private $app;

    /**
     *
     * @var $model
     */
    protected $model;

    /**
     *
     * @var $withTrashed
     */
    private $withTrashed;

    /**
     *
     * @var $onlyTrashed
     */
    private $onlyTrashed;

    /**
     *
     * @var $where
     */
    private $where;

    /**
     *
     * @var $orWhere
     */
    private $orWhere;

    private $whereIn;

    /**
     *
     * @var $skip
     */
    private $skip;

    /**
     *
     * @var $take
     */
    private $take;

    /**
     *
     * @var $orderBy
     */
    private $orderBy;

    /**
     *
     * @var $groupBy
     */
    private $groupBy;

    /**
     *
     * @var $validationRules
     */
    protected $validationRules;

    /**
     *
     * @var $validationMessages
     */
    protected $validationMessages;

    /**
     *
     * @param App $app
     * @param Collection $collection
     */
    public function __construct()
    {
        $this->app = new App();
        $this->makeModel();
        $this->validationRules = [];
        $this->validationMessages = [];

        if (method_exists($this, 'validationMessages')) {
            $this->validationMessages = $this->validationMessages();
        }

        if (method_exists($this, 'validationRules')) {
            $this->validationRules = $this->validationRules();
        }
    }

    /**
     * Specify Model class name
     *
     * @return mixed
     */
    public abstract function model();

    /**
     *
     * @param array $columns
     * @return mixed
     */
    public function all($columns = ['*'])
    {
        $this->newQuery()
             ->eagerLoadTrashed()
             ->eagerLoadWhere()
             ->eagerTakeAndSkip()
             ->eagerGroupBy()
             ->eagerOrderBy();

        return $this->model->get($columns);
    }


    /**
     *
     * @param int $perPage
     * @param array $columns
     * @return mixed
     */
    public function paginate($perPage = 20, $columns = ['*'])
    {
        $this->newQuery()
             ->eagerLoadTrashed()
             ->eagerLoadWhere()
             ->eagerOrderBy();

        return $this->model->paginate($perPage, $columns);
    }

    /**
     *
     * @param array $data
     * @return mixed
     */
    public function create(array $data)
    {
        if (isset($this->validationRules['create'])) {
            $this->validateOrFail($data, $this->validationRules['create']);
        }

        return $this->model->create($data);
    }


    /**
     *
     * @param array $data
     * @param string $exist_field
     * @return bool
     */
    public function save(array $data, $exist_field = 'id')
    {
        $this->model->unguard();
        $model = $this->model->fill($data);
        $model->exists = $data[$exist_field];
        $this->model->reguard();

        return $model->save();
    }

    /**
     *
     * @param array $data
     * @param string|int $id
     * @param string $attribute
     * @param bool $withSoftDel
     * @return mixed
     */
    public function update(array $data, $id, $attribute = 'id', $withSoftDel = false)
    {
        if (isset($this->validationRules['update'])) {
            $this->validateOrFail($data, $this->validationRules['update']);
        }

        if ($withSoftDel) {
            $this->newQuery()->eagerLoadTrashed();
        }

        $fillable = $this->model->getModel()->getFillable();
        $data = array_only($data, $fillable);
        return $this->model->where($attribute, '=', $id)->update($data);
    }

    /**
     *
     * @param string|int $id
     * @return mixed
     */
    public function delete($id = '')
    {
        if ($id) {
            return $this->model->destroy($id);
        } else {
            return $this->model->delete();
        }
    }

    /**
     * Truly remove a model from database
     * @return mixed
     */
    public function forceDelete($id)
    {
        return $this->find($id)->forceDelete();
    }

    /**
     *
     * @param string|int $id
     * @param array $columns
     * @return mixed
     */
    public function find($id, $columns = ['*'])
    {
        $this->makeModel();

        $this->newQuery()->eagerLoadTrashed();

        return $this->model->findOrFail($id, $columns);
    }

    /**
     *
     * @param string $field
     * @param string $value
     * @param array $columns
     * @return mixed
     */
    public function findBy($field, $value, $columns = ['*'])
    {
        $this->newQuery()->eagerLoadTrashed();

        return $this->model->where($field, '=', $value)->firstOrFail($columns);
    }

    /**
     *
     * @param string $field
     * @param string $value
     * @param array $columns
     * @return mixed
     */
    public function findAllBy($field, $value, $columns = ['*'])
    {
        $this->newQuery()
             ->eagerLoadTrashed()
             ->eagerOrderBy();

        return $this->model->where($field, '=', $value)->get($columns);
    }

    /**
     *
     * @param array $columns
     * @return mixed
     */
    public function first($columns = ['*'])
    {
        $this->newQuery()->eagerLoadTrashed()->eagerLoadWhere()->eagerOrderBy();

        return $this->model->first();
    }

    /**
     *
     * @param array $columns
     * @return mixed
     */
    public function firstOrFail($columns = ['*'])
    {
        $this->newQuery()->eagerLoadTrashed()->eagerLoadWhere();

        return $this->model->firstOrFail();
    }

    /**
     *
     * @return \Illuminate\Database\Eloquent\Builder
     * @throws Exception
     */
    public function makeModel($reset = false)
    {
        if ($reset) {
            $this->resetConditions();
        }
        $model = $this->app->make($this->model());

        if (!$model instanceof Model) {
            throw new Exception("Class {$this->model()} must be an instance of Illuminate\\Database\\Eloquent\\Model");
        }

        return $this->model = $model;
    }

    /**
     * Load result with soft delete
     *
     * @return $this
     */
    public function withTrashed()
    {
        $this->withTrashed = func_get_args();
        return $this;
    }

    /**
     * Load result only deleted with soft delete
     *
     * @return $this
     */
    public function onlyTrashed()
    {
        $this->onlyTrashed = func_get_args();

        return $this;
    }

    /**
     * And where
     *
     * @param mixed $condition Array of conditions or string field name
     * @param mixed $value Value of field (if condition is field name string)
     * @param string $operator Condition operator (ie: =, <=, >=, <>, ...)
     * @return $this
     */
    public function where($conditions, $operator = '=', $value = '1')
    {
        $this->where[] = func_get_args();

        return $this;
    }

    /**
     * Or where
     *
     * @param mixed $condition Array of conditions or string field name
     * @param mixed $value Value of field (if condition is field name string)
     * @param string $operator Condition operator (ie: =, <=, >=, <>, ...)
     * @return $this
     */
    public function orWhere($conditions, $operator = '=', $value = '1')
    {
        $this->orWhere[] = func_get_args();

        return $this;
    }

    public function whereIn($field, $values)
    {
        $this->whereIn[] = func_get_args();

        return $this;
    }

    /**
     * Offset of cursor in result set
     *
     * @param int $offset Offset number
     * @return $this
     */
    public function skip($offset = 0)
    {
        $this->skip = $offset;

        return $this;
    }

    /**
     * Limit records of result set
     *
     * @param int $limit Limit number
     * @return $this
     */
    public function take($limit = 20)
    {
        $this->take = $limit;

        return $this;
    }

    /**
     * Sort result set
     *
     * @param string $field Field name
     * @param string $direction Sort direction (ASC and DESC)
     * @return $this
     */
    public function orderBy($field, $direction = 'ASC')
    {
        $this->orderBy[] = func_get_args();

        return $this;
    }

    public function groupBy($field)
    {
        $this->groupBy = $field;

        return $this;
    }

    /**
     * Create new query for model
     *
     * @return $this
     */
    private function newQuery()
    {
        $this->model = $this->model->newQuery();

        return $this;
    }

    /**
     * Eager loading trashed
     *
     * @return $this
     */
    private function eagerLoadTrashed()
    {
        if (!is_null($this->withTrashed)) {
            $this->model->withTrashed();
        } elseif (!is_null($this->onlyTrashed)) {
            $this->model->onlyTrashed();
        }

        return $this;
    }

    /**
     * Eager loading for and where & or where
     *
     * @return $this
     */
    private function eagerLoadWhere()
    {
        if (count($this->where) > 0) {
            foreach ($this->where as $where) {
                if (is_array($where[0])) {
                    $this->model->where($where[0]);
                } else {
                    if (count($where) == 3) {
                        $this->model->where($where[0], $where[1], $where[2]);
                    } else {
                        $this->model->where($where[0], '=', $where[1]);
                    }
                }
            }
        }

        if (count($this->whereIn) > 0) {
            foreach ($this->whereIn as $where) {
                $this->model->whereIn($where[0], $where[1]);
            }
        }

        if (count($this->orWhere) > 0) {
            foreach ($this->orWhere as $orWhere) {
                if (is_array($orWhere[0])) {
                    $this->model->orWhere($orWhere[0]);
                } else {
                    if (count($where) == 3) {
                        $this->model->orWhere($where[0], $where[1], $where[2]);
                    } else {
                        $this->model->orWhere($where[0], '=', $where[1]);
                    }
                }
            }

            if (!is_null($this->withTrashed)) {
                $this->model->where(function($query) {
                    return $query->whereNull('deleted_at')->orWhereNotNull('deleted_at');
                });
            }

            if (!is_null($this->onlyTrashed)) {
                $this->model->whereNotNull('deleted_at');
            }
        }

        return $this;
    }

    /**
     * Eager loading for take and skip
     *
     * @return $this
     */
    private function eagerTakeAndSkip()
    {
        if (!is_null($this->skip)) {
            $this->model->skip($this->skip);
        }

        if (!is_null($this->take)) {
            $this->model->take($this->take);
        }

        return $this;
    }

    /**
     * Eager loading for order by
     *
     * @return $this
     */
    private function eagerOrderBy()
    {
        if (count($this->orderBy) > 0) {
            foreach ($this->orderBy as $orderBy) {
                $direction = (isset($orderBy[1]) ? $orderBy[1] : 'ASC');
                $this->model->orderBy($orderBy[0], $direction);
            }
        }

        return $this;
    }

    private function eagerGroupBy()
    {
        if (count($this->groupBy) > 0) {
            $this->model->groupBy($this->groupBy);
        }

        return $this;
    }

    /**
     * Validate or fail
     *
     * @param  array $rules Validation rules
     * @return mixed Validation exeption
     */
    private function validateOrFail($data, $rules)
    {
        $validator = Validator::make($data, $rules, $this->validationMessages);

        if ($validator->fails()) {
            $request = Request::instance();
            $this->throwValidationException($request, $validator);
        }
    }

    protected function resetConditions()
    {
        $this->where = [];
        $this->orWhere = [];
        $this->whereIn = [];
        $this->take = null;
        $this->skip = null;
        $this->orderBy = [];
        $this->groupBy = [];
        $this->validationRules = [];
        $this->validationMessages = [];
    }

    public function updateOrCreate(array $data, $column = 'id')
    {
        $columnValue = isset($data[$column]) ? $data[$column] : null;
        $dataExisted = $this->model->where($column, '=', $columnValue)->first();
        $result = $dataExisted ? $this->update($data, $data[$column], $column) :
            $this->create($data);

        return $result;
    }
}
