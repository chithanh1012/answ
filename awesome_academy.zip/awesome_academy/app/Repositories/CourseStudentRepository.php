<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Validator;

class CourseStudentRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\CourseStudent::class;
    }

    public function findByCourseIdByStudentId($courseId, $studentId)
    {
        $courseStudent = $this->where('course_id', $courseId)
                              ->where('student_id', $studentId)
                              ->first();
        return !is_null($courseStudent);
    }
}
