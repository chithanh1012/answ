<?php
namespace App\Repositories;

use App\Repositories\Repository;
use App\Repositories\CourseRepository;
use App\Repositories\StudentRepository;
use Validator;
use App\Events\CreatedMessage;
use App\Listeners\CreatedMessageListener;

class MessageRepository extends Repository
{
    private $courseRepository;

    public function __construct(CourseRepository $courseRepository)
    {
        parent::__construct();

        $this->courseRepository = $courseRepository;
    }

    /**
     * Specify Model class name
     *
     * @return string
     */
    public function model()
    {
        return \App\Models\Message::class;
    }

    public function validationRules($isTeacher = false)
    {
        $rules = [
            'content' => 'required|min:3',
        ];
        if ($isTeacher) {
            $rules = [
                'title' => 'required|min:3|max:255',
                'content' => 'required|min:3',
            ];
        }
        return [
            'create' => $rules,
            'update' => $rules,
        ];
    }

    public function teacherSendValidationRules()
    {
        $this->validationRules = $this->validationRules(true);
    }

    public function getMessagesReceivedByTeacher($courseId, $lessonId = 0)
    {
        $this->makeModel(true);
        $messages = $this->where(['course_id' => $courseId, 'reply_to' => 0, 'lesson_id' => $lessonId])->orderBy('created_at')->all();
        $messages->load('repliedMessage', 'student');

        return $messages;
    }

    public function getMessagesSentByStudent($courseId, $studentId, $lessonId = 0)
    {
        $this->makeModel(true);
        $messages = $this->where(['course_id' => $courseId, 'reply_to' => 0, 'student_id' => $studentId, 'lesson_id' => $lessonId])->orderBy('created_at')->all();
        $messages->load('repliedMessage', 'student');

        return $messages;
    }

    public function getMessagesSentAllStudents($currentUserId, $courseId, $isTeacher = false)
    {
        $this->makeModel(true);
        $messages = $this->where('course_id', $courseId)
                         ->where('reply_to', '<', -1)
                         ->where('lesson_id', 0);

        if ($isTeacher) {
            $course = $this->courseRepository->find($courseId);
            $assistants = $course->courseAssistants->lists('teacher_id')->toArray();
            $assistants[count($assistants) + 1] = $course->teacher_id;
            $messages->whereIn('teacher_id', $assistants)
                     ->groupBy('reply_to');
        } else {
            $messages->where('student_id', $currentUserId);
        }
        $messages->orderBy('created_at', 'DESC');

        return $messages->all();
    }

    public function sendMessage($request, $currentUser, $courseId, $role = '', $lessonId = 0)
    {
        if (!$currentUser || ($currentUser->isStudent() && !$currentUser->isJoinedCourse($courseId))) {
            return false;
        }

        $course = $this->courseRepository->find($courseId);
        $input = $request->except('created_at', 'updated_at', '_token', '_method');
        $input['course_id'] = $courseId;
        $input['teacher_id'] = $course->teacher_id;
        $input['student_id'] = $currentUser->id;
        $input['lesson_id'] = $lessonId;

        if ($currentUser->isTeacher()) {
            if ($role) {
                $this->teacherSendValidationRules();
                $input['teacher_id'] = $currentUser->id;
                $input['reply_to'] = (int) ('-' . time());
                $students = $course->students->toArray();
                $studentIds = array_pluck($students, 'id');
                foreach ($studentIds as $studentId) {
                    $input['student_id'] = $studentId;
                    $this->create($input);
                }
                $data = [
                    'course'    => $course,
                    'title'     => $input['title'],
                    'content'   => $input['content'],
                    'type'      => CreatedMessageListener::TYPE_MESSAGE_TO_STUDENTS,
                ];
            } else {
                if (!isset($input['reply_to'])) {
                    return false;
                }
                $message = $this->find($input['reply_to']);
                $input['teacher_id'] = $currentUser->id;
                $input['student_id'] = $message->student_id;
                if ($message->lesson_id != $lessonId) {
                    return false;
                }
                $input['lesson_id'] = $message->lesson_id;
                $this->makeModel(true);
                if ($this->create($input)) {
                    $data = [
                        'course'    => $course,
                        'studentId' => $message->student_id,
                        'messageId' => $message->id,
                        'lessonId'  => $lessonId,
                        'content'   => $input['content'],
                        'type'      => CreatedMessageListener::TYPE_MESSAGE_TEACHER_REPLY,
                    ];
                }
            }
            event(new CreatedMessage($data));
            return true;
        }
        if ($this->create($input)) {
            $data = [
                'course'    => $course,
                'courseId'  => $courseId,
                'lessonId'  => $lessonId,
                'content'   => $input['content'],
                'type'      => '',
            ];
            event(new CreatedMessage($data));
            return true;
        }
    }
}
