<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Validator;
use App\Models\Student;
use wataridori\SFS\SimpleFuzzySearch;

class StudentRepository extends Repository {

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\Student::class;
    }

    /**
     * Validate login post data
     */
    function validatorLogin(array $data)
    {
        $validator = Validator::make($data, [
            'email'       => 'required|email',
            'password'    => 'required',
        ]);

        return $validator;
    }

    function validatorSignup(array $data)
    {
        $validator = Validator::make($data, [
            'full_name'         => 'required|max:255',
            'identity_number'   => 'required|max:20|unique:students',
            'email'             => 'required|email|max:255|unique:students',
            'password'          => 'required|min:8|confirmed',
            'password_confirmation' =>'required'
        ]);

        return $validator;
    }

    public function searchStudentByName($name)
    {
        $studentData = Student::get(['id', 'full_name'])->toArray();
        $sfs = new SimpleFuzzySearch($studentData, ['full_name'], $name);
        $results = $sfs->search();
        if (!$results) {
            $idsViaName = [];
        }
        $idsViaName = array_pluck($results, '0.id');

        $students = Student::where('identity_number', 'like', '%' . $name . '%')
                        ->get(['id'])->toArray();
        if (!$students) {
            $idsViaIdentityNumber = [];
        }

        $idsViaIdentityNumber = array_pluck($students, 'id');

        if (!$idsViaName && !$idsViaIdentityNumber) {
            return [];
        }

        $ids = array_merge($idsViaName, $idsViaIdentityNumber);

        return Student::whereIn('id', $ids)->get();
    }

    public function findStudentByEmail($email, $getData = false)
    {
        $student = $this->where('email', $email)->first();
        if ($getData && !is_null($student)) {
            return $student;
        }
        return !is_null($student);
    }

    public function findStudentByAwesomeAuthenticationId($awesomeAuthenticationId, $getData = false)
    {
        $student = $this->where('awesome_authentication_id', $awesomeAuthenticationId)->first();
        if ($getData && !is_null($student)) {
            return $student;
        }
        return !is_null($student);
    }

    public function findStudentIdByIdentityNumber($identityNumber, $isExits = false)
    {
        $student = $this->where('identity_number', $identityNumber)
                        ->first();
        if ($isExits) {
            return $student->id;
        }
        return !is_null($student);
    }
}
