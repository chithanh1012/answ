<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Validator;
use App\Models\PasswordReset;
use App\Listeners\NewTeacherCreatedListener;

class PasswordResetRepository extends Repository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\PasswordReset::class;
    }

    public function findByEmail($email)
    {
        return !$this->where('email')->exists();
    }

    function validatorForgotPassword(array $data)
    {
        $validator = Validator::make($data, [
            'email' => 'required|email',
        ]);

        return $validator;
    }

    function validatorResetPassword(array $data)
    {
        $validator = Validator::make($data, [
            'token' => 'required',
            'email' => 'required|email',
            'password' => 'required|confirmed|min:8',
        ]);

        return $validator;
    }

    function validatorSetPassword(array $data)
    {
        $validator = Validator::make($data, [
            'token' => 'required',
            'password' => 'required|confirmed|min:8',
        ]);

        return $validator;
    }

    public function findByToken($token, $getData = false)
    {
        if ($getData) {
            return $this->where('token', $token)
                ->where('type', NewTeacherCreatedListener::TYPE_TEACHER_RESET_PASSWORD)
                ->first();
        }
        return PasswordReset::where('token', $token)
            ->where('type', NewTeacherCreatedListener::TYPE_TEACHER_RESET_PASSWORD)
            ->exists();
    }
}
