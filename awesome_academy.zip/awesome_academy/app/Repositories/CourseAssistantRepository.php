<?php
namespace App\Repositories;

use App\Repositories\Repository;
use Carbon\Carbon;

class CourseAssistantRepository extends Repository
{

    /**
     * Specify Model class name
     *
     * @return string
     */
    function model()
    {
        return \App\Models\CourseAssistant::class;
    }

    function validationRules()
    {
        $rules = [
            'teacher_id' => 'required',
            'course_id'  => 'required',
        ];

        return [
            'create' => $rules,
        ];
    }

    public function updateData($data, $courseId)
    {
        $insert = [];
        $delete = [];
        if (isset($data['teacher_ids']) && $data['teacher_ids']) {
            $now = Carbon::now();
            for ($i = 0; $i < count($data['teacher_ids']); $i++) {
                if ($data['status'][$i] == 'new') {
                    $courseAssistant = [];
                    $courseAssistant['teacher_id'] = $data['teacher_ids'][$i];
                    $courseAssistant['course_id']  = $courseId;
                    $courseAssistant['created_at'] = $now;
                    $courseAssistant['updated_at'] = $now;
                    $insert[] = $courseAssistant;
                } elseif ($data['status'][$i] == 'remove') {
                    $delete[] = $data['ids'][$i];
                }
            }
            $this->model->insert($insert);
            $this->delete($delete);
        }
    }
}
