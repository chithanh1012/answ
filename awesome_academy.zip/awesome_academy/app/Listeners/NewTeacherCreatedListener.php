<?php

namespace App\Listeners;

use App\Events\NewTeacherCreated;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Services\SendGridService;
use App\Repositories\PasswordResetRepository;

class NewTeacherCreatedListener
{
    private $passwordResetRepository;
    private $mailService;

    const TYPE_TEACHER_RESET_PASSWORD = 'teacher';

    /**
     * Create the event handler.
     *
     * @return void
     */
    public function __construct(
        PasswordResetRepository $passwordResetRepository,
        SendGridService $mailService
    ) {
        $this->passwordResetRepository = $passwordResetRepository;
        $this->mailService = $mailService;
    }

    /**
     * Handle the event.
     *
     * @param  NewTeacherCreated  $event
     * @return void
     */
    public function handle(NewTeacherCreated $event)
    {
        $token = str_random(50);
        $this->passwordResetRepository->updateOrCreate(
            [
                'email' => $event->data['email'],
                'token' => $token,
                'type'  => self::TYPE_TEACHER_RESET_PASSWORD,
            ],
            'email'
        );
        $event->data['token'] = $token;

        $this->sendEmail($event->data);
    }

    private function sendEmail($data)
    {
        $layout = 'emails.set_password';
        $subject = trans('common.emails.set_password_subject');

        $this->mailService->setTo($data['email'])
             ->setSubject($subject)
             ->setData($data)
             ->setLayout($layout);

        $this->mailService->send();
    }
}
