<?php

namespace App\Listeners;

use App\Events\ResetPassword;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Password;
use Auth;

class ResetPasswordListener
{
    private $passwordResetRepository;
    private $mailService;

    protected $credentials;

    /**
     * Create the event handler.
     *
     * @return void
     */
    public function __construct() {
        //
    }

    /**
     * Handle the event.
     *
     * @param  ForgotPassword  $event
     * @return void
     */
    public function handle(ResetPassword $event)
    {
        $this->credentials = $event->credentials;

        $response = Password::teacher()->reset($this->credentials, function ($user, $password) {
            $this->resetPassword($user, $password);
        });

        if ($response === Password::PASSWORD_RESET) {
            return true;
        }
        return false;
    }

    private function resetPassword($teacher, $password)
    {
        $teacher->password = bcrypt($password);

        $teacher->save();

        Auth::teacher()->login($teacher);
    }
}
