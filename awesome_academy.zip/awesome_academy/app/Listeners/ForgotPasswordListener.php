<?php

namespace App\Listeners;

use App\Events\ForgotPassword;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Services\SendGridService;
use App\Repositories\PasswordResetRepository;

class ForgotPasswordListener
{
    private $passwordResetRepository;
    private $mailService;

    protected $data;
    const TYPE_TEACHER_RESET_PASSWORD = 'teacher';

    /**
     * Create the event handler.
     *
     * @return void
     */
    public function __construct(
        PasswordResetRepository $passwordResetRepository,
        SendGridService $mailService
    ) {
        $this->passwordResetRepository = $passwordResetRepository;
        $this->mailService = $mailService;
    }

    /**
     * Handle the event.
     *
     * @param  ForgotPassword  $event
     * @return void
     */
    public function handle(ForgotPassword $event)
    {
        $token = str_random(50);
        $this->passwordResetRepository->updateOrCreate(
            [
                'email' => $event->data['email'],
                'token' => $token,
                'type'  => self::TYPE_TEACHER_RESET_PASSWORD,
            ],
            'email'
        );
        $event->data['token'] = $token;

        $this->sendEmail($event->data);
    }

    private function sendEmail($data)
    {
        $layout = 'emails.password';
        $subject = trans('common.emails.reset_password_subject');

        $this->mailService->setTo($data['email'])
             ->setSubject($subject)
             ->setData($data)
             ->setLayout($layout);

        $this->mailService->send();
    }

}
