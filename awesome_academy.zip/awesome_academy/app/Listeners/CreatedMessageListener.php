<?php

namespace App\Listeners;

use App\Events\CreatedMessage;
use Illuminate\Queue\InteractsWithQueue;
use Illuminate\Contracts\Queue\ShouldQueue;
use App\Services\SendGridService;
use Artisan;

class CreatedMessageListener
{
    private $mailService;

    const TYPE_MESSAGE_TO_STUDENTS = 1;
    const TYPE_MESSAGE_TEACHER_REPLY = 2;

    /**
     * Create the event listener.
     *
     * @return void
     */
    public function __construct()
    {
        //
    }

    /**
     * Handle the event.
     *
     * @param  SendMail  $event
     * @return void
     */
    public function handle(CreatedMessage $event)
    {
        $emails = [];
        if ($event->data['type'] === self::TYPE_MESSAGE_TO_STUDENTS) {
            $students = $event->data['course']->students->toArray();
            $email = array_pluck($students, 'email');
            $subject = 'teachers.subject_teacher_send_students';
            $template = 'layouts.emails.teacher_to_students';
        } elseif ($event->data['type'] === self::TYPE_MESSAGE_TEACHER_REPLY) {
            $email = $event->data['course']->students->find($event->data['studentId'])->email;
            $subject = 'teachers.subject_teacher_reply_message';
            $template = 'layouts.emails.teacher_reply_message';
        } else {
            $email = $event->data['course']->teacher->email;
            $subject = 'students.subject_student_send_message';
            $template = 'layouts.emails.student_send_message';
        }
        if ($emails) {
            run_command_background('teacher:send-email', [
                '--subject' => $subject,
                '--email' => json_encode($emails),
                '--data' => json_encode($event->data),
                '--template' => $template,
            ]);
        } else {
            $this->sendEmail($subject, $email, $event->data, $template);
        }
    }

    private function sendEmail($subject, $email, $data, $template)
    {
        $mail = new SendGridService();
        $mail->setTo($email)
             ->setSubject(trans($subject))
             ->setData(['data' => $data])
             ->setLayout($template);
        $mail->send();
    }
}
